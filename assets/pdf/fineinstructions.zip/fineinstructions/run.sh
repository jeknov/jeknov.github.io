#!/bin/bash

# Change directory to script location
cd "$(dirname "$0")" || exit

# Set environment variables
export PROJECT_VENV=.venv/prod

# Load user-specified project environment variables
source project.env

# Ensure direct environment variables are provided
source .cluster/direct/_direct_env.sh

# Load user-specified project environment variables
source project.env

# Set environment variables
export PROJECT_CACHE_DIR=$PROJECT_DATA/.cache

# Set scratch variables and clear old scratch data
export PROJECT_SCRATCH_DATA_VERSION="${PROJECT_SCRATCH_DATA_VERSION:=1}"
if [ -n "$PROJECT_SCRATCH_DATA" ]; then
    # Compute available scratch space in GB
    export SCRATCH_GB_REMAINING=$(folder="$PROJECT_SCRATCH_DATA"; while [ ! -d "$folder" ] && [ "$folder" != / ]; do folder=$(dirname "$folder"); done; df --block-size=1G "$folder" | awk 'NR==2 {gsub("G",""); print $4}')
    echo "Using scratch data version: $PROJECT_SCRATCH_DATA_VERSION" >&2
    echo "Clearing old outdated scratch data if it exists..." >&2
    find "$PROJECT_SCRATCH_DATA" -mindepth 1 -maxdepth 1 ! -name "$PROJECT_SCRATCH_DATA_VERSION" -exec sh -c 'echo "Deleting $1" >&2; rm -rf "$1"' _ {} \;
    echo "Done." >&2
    # Check if there is enough scratch space
    if [ "$SCRATCH_GB_REMAINING" -lt 120 ]; then
        echo "Cannot continue: Not enough scratch space ($SCRATCH_GB_REMAINING GB available)." >&2
        echo "[Instructions from Ajay:] Consider clearing old scratch data to clear up space by incrementing PROJECT_SCRATCH_DATA_VERSION by adding this in your sbatch run script to bump the version number up by 1:" >&2
        echo "export PROJECT_SCRATCH_DATA_VERSION=\"$((PROJECT_SCRATCH_DATA_VERSION + 1))\"" >&2
        exit 1
    else
        echo "Scratch space available: $SCRATCH_GB_REMAINING GB" >&2
    fi
fi


# Retry config
MAX_RETRIES=3
RETRY_DELAY=1

# Retry loop
attempt=1
while true; do
    export FINEINSTRUCTION_INFERENCE_ATTEMPT=$attempt
    echo "Attempt $attempt of $MAX_RETRIES..."
    .cluster/_boot.sh "$@"
    exit_code=$?

    if [[ $exit_code -ne 95 ]]; then
        exit $exit_code
    fi

    if [[ $attempt -ge $MAX_RETRIES ]]; then
        echo "Command exited with OOM after $MAX_RETRIES attempts. Giving up."
        exit 95
    fi

    echo "Command exited with OOM. Retrying in $RETRY_DELAY seconds..."
    sleep "$RETRY_DELAY"
    attempt=$((attempt + 1))
done