from random import Random

DESCRIPTION_PROMPT = """
Given a document, I would like you to write a "specification" description for the document in the exact same style / length / tone as the 3 examples provided below.

Here are some requirements:
1. Detailed Specification Description: The description should have all neccessary details to create a "spec" of the document (what information the document provides).
2. Granular Deatails: The description should be very detailed and granular, and should include all the precise information that the document provides.
3. Style: The specification should be written in an abstract style, and begin with "A document that...". Very closely follow the style of the 3 examples. Sometimes you should use the tone "*should*" or "*would*" in the description like "The document should..." or "The document would..." or "Additionally, the document would...", etc.
4. Length & Detail: The length and detail should be similar to the 3 examples.
5. Return Format: Return the entire specification description as a single paragraph, no lists, bullets, or other structures. Return your specification description after "Description: ". Return nothing else at all in your output.

Example #1: {example_1}

Example #2: {example_2}

Example #3: {example_3}

Document: {document}
""".strip()


def create_description_prompts(compatible_document_descriptions, row):
    r = Random(len(row["document"]))
    three_examples = r.sample(compatible_document_descriptions, 3)
    return {
        "prompt": DESCRIPTION_PROMPT.format(
            example_1=three_examples[0],
            example_2=three_examples[1],
            example_3=three_examples[2],
            document=row["document"],
        )
    }


def post_process_description(x):
    divider = "Description:"
    return (x.rsplit(divider, 1)[1] if divider in x else x).strip()


JUDGE_PROMPT = """
Given a instruction-tuning prompt template (that is representative of a real world query or task a user might ask an LLM) and a specification of what information a document provides, please judge whether such a document would have enough information to both instantiate both the query template and instantiate a grounded response to create a high-quality training example grounded in the document.

Requirements:
1. The document must have enough information to be able to instantiate the template and provide a response (i.e. create both sides of the query-response pair for the purposes of creating a high-quality training example).
2. Document must have enough information to instantiate every single variable (<fi></fi>) in the query template.
3. Document must have enough information to instantiate a strong grounded response.

Return Format: Write a short explanation of your judgement and why the document does or does not meet the requirements, then return your judgement as "yes" or "no" after "Answer: ". Return nothing else at all in your output.

Document Specification: {description}

Instruction-Tuning Prompt Template: {template}
""".strip()


def create_judge_prompts(row):
    return {
        "prompt": JUDGE_PROMPT.format(
            description=row["description"], template=row["template"]
        )
    }


JUDGE_PROMPT_V2 = """
Given a instruction-tuning prompt template (that is representative of a real world query or task a user might ask an LLM) and a document, please judge whether the document has enough information to both instantiate both the query template and instantiate a grounded response to create a high-quality training example grounded in the document.

Requirements:
1. The document must have enough information to be able to instantiate the template and provide a response (i.e. create both sides of the query-response pair for the purposes of creating a high-quality training example).
2. Document must have enough information to instantiate every single variable (<fi></fi>) in the query template.
3. Document must have enough information to instantiate a strong grounded response.

Return Format: Write a short explanation of your judgement and why the document does or does not meet the requirements, then return your judgement as "yes" or "no" after "Answer: ". Return nothing else at all in your output.

Instruction-Tuning Prompt Template: {template}

Document: {document}
""".strip()


def create_judge_prompts_v2(row):
    return {
        "prompt": JUDGE_PROMPT_V2.format(
            document=row["document"], template=row["template"]
        )
    }


def post_process_judgement(x):
    divider = "Answer:"
    return "yes" in ((x.rsplit(divider, 1)[1] if divider in x else x).strip().lower())
