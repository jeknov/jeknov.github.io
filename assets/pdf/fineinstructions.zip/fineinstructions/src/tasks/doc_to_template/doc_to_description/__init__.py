import itertools
import os
from functools import partial
from random import Random

import torch
from datadreamer import DataDreamer
from datadreamer.embedders import SentenceTransformersEmbedder
from datadreamer.retrievers import EmbeddingRetriever
from datadreamer.steps import (
    CosineSimilarity,
    DataSource,
    HFHubDataSource,
    Prompt,
    Retrieve,
    zipped,
)

from ....datadreamer_ext.openrouter import OpenRouter
from ...train_query_genericizer.train_query_genericizer.preprocessing import (
    template_quality_filter,
)
from .description_prompts import (
    create_description_prompts,
    create_judge_prompts,
    post_process_description,
    post_process_judgement,
)


def doc_to_description(ctx):
    from ....project import get_persistent_dir, reporter

    # Flag to control whether to force re-run the pipeline without caching
    FORCE = False

    reporter.set(
        "doc_to_description.datadreamer_output", "doc_to_description_datadreamer_output"
    )
    datadreamer_output_dir = get_persistent_dir(
        "doc_to_description_datadreamer_output",
        "doc_to_description.doc_to_description_datadreamer_output",
    )

    with DataDreamer(datadreamer_output_dir):
        llm_70 = OpenRouter(
            model_name="meta-llama/llama-3.3-70b-instruct",
            api_key=os.environ["OPENROUTER_API_KEY"],
            base_url="https://openrouter.ai/api/v1",
        )

        # Get all compatible document description examples
        compatible_document_descriptions = list(
            HFHubDataSource(
                "Get Compatible Document Description Examples",
                "fineinstructions/templates_raw_subsample",
                split="full",
            )
            .select_columns(["compatible_document_description"])
            .filter(
                lambda row: len(row["compatible_document_description"]) > 700
                and len(row["compatible_document_description"]) < 2000,
                lazy=False,
                name="Filter out Low-Quality Descriptions",
            )
            .shuffle(seed=42, lazy=False)
            .output.dataset["compatible_document_description"]
        )

        # Load FineWeb documents
        documents = (
            HFHubDataSource(
                "Get FineWeb Documents",
                "HuggingFaceFW/fineweb",
                split="train",
                config_name="sample-10BT",
            )
            .shuffle(seed=42, lazy=False)
            .take(200000, lazy=False)
            .select_columns(["text"])
            .rename_column("text", "document")
        )
        documents = documents.filter(
            lambda row: llm_70.count_tokens(row["document"]) < 12000,
            lazy=False,
            name="Filter Out Documents Too Long",
        )

        # Genericize queries
        description_prompts = documents.map(
            partial(create_description_prompts, compatible_document_descriptions),
            lazy=False,
            name="Create Description Prompts",
            force=FORCE,
        )
        descriptions = Prompt(
            name="Generate Descriptions",
            inputs={"prompts": description_prompts.output["prompt"]},
            args={
                "llm": llm_70,
                "batch_size": 120,
                "temperature": 1.0,
                "top_p": 0.0,
                "max_new_tokens": 1000,
                "post_process": post_process_description,
            },
            outputs={"generations": "description"},
            force=FORCE,
        ).select_columns(["description"], name="Get Descriptions")
        documents_and_descriptions = zipped(
            documents, descriptions, name="Combine documents + descriptions"
        )
        documents_and_descriptions.export_to_hf_dataset(
            os.path.join(
                datadreamer_output_dir, "exports", "documents_and_descriptions"
            )
        )
        documents_and_descriptions_rows = list(
            documents_and_descriptions.output.dataset
        )

        # Get all templates
        templates_dataset = HFHubDataSource(
            "Get Templates Dataset",
            "fineinstructions/templates_raw_subsample",
            split="full",
        ).filter(
            template_quality_filter, lazy=False, name="Filter out Low-Quality Templates"
        )
        templates_dataset_rows = list(templates_dataset.output.dataset)

        # Create a retriever
        K = 5
        embedder = SentenceTransformersEmbedder("BAAI/bge-m3", device=0)
        retriever = EmbeddingRetriever(
            texts=templates_dataset.output["compatible_document_description"],
            embedder=embedder,
            device=torch.device(0),
        )
        most_similar_descriptions = Retrieve(  # noqa: F841
            "Retrieve most relevant template descriptions",
            args={
                "retriever": retriever,
                "k": K,
                "index_batch_size": 4,
                "batch_size": 4,
                "lazy": False,
            },
            inputs={"queries": documents_and_descriptions.output["description"]},
        )
        sim_pairs = []
        for row_idx, row in enumerate(most_similar_descriptions.output["results"]):
            for sim_idx, sim in zip(row["indices"], row["scores"]):
                sim_row = templates_dataset_rows[sim_idx]
                sim_pairs.append(
                    {
                        "row_idx": row_idx,
                        "document": documents_and_descriptions_rows[row_idx][
                            "document"
                        ],
                        "description": documents_and_descriptions_rows[row_idx][
                            "description"
                        ],
                        "template": sim_row["template"],
                        "compatible_document_description": sim_row[
                            "compatible_document_description"
                        ],
                        "sim": sim,
                    }
                )
        sim_pairs = DataSource("Get Similar Pairs", data=sim_pairs)

        # Judge similar pairs
        judge_prompts = sim_pairs.map(
            create_judge_prompts, lazy=False, name="Create Judge Prompts", force=FORCE
        )
        judgements = Prompt(
            name="Generate Judgements",
            inputs={"prompts": judge_prompts.output["prompt"]},
            args={
                "llm": llm_70,
                "batch_size": 120,
                "temperature": 1.0,
                "top_p": 0.0,
                "max_new_tokens": 3000,
                "post_process": post_process_judgement,
            },
            outputs={"generations": "judgement"},
            force=FORCE,
        ).select_columns(["judgement"], name="Get Judgements")
        sim_pairs_and_judgements = list(
            zipped(sim_pairs, judgements, name="Combine sim_pairs + judgements")
            .map(
                lambda row: {
                    **{k: v for k, v in row.items() if k != "sim"},
                    "sim": row["sim"],
                },
                lazy=False,
                name="Adjust similarities based on judgements",
                force=FORCE,
            )
            .output.dataset
        )
        sim_pairs_and_judgements = [
            sim_pairs_and_judgements[i : i + K]
            for i in range(0, len(sim_pairs_and_judgements), K)
        ]

        # Get K random template descriptions for each document
        r = Random(42)
        template_compatible_document_descriptions = [
            row["compatible_document_description"] for row in templates_dataset_rows
        ]
        random_descriptions = [
            r.sample(template_compatible_document_descriptions, K)
            for _ in documents_and_descriptions_rows
        ]
        random_descriptions_flattened = list(
            itertools.chain.from_iterable(random_descriptions)
        )

        # Repeat the document descriptions K times
        document_descriptions = [
            [row["description"]] * K for row in documents_and_descriptions_rows
        ]
        document_descriptions_flattened = list(
            itertools.chain.from_iterable(document_descriptions)
        )

        # Create dataset and compute cosine similarities between document and each random template
        assert len(document_descriptions_flattened) == len(
            random_descriptions_flattened
        )
        assert isinstance(document_descriptions_flattened[0], str)
        assert isinstance(random_descriptions_flattened[0], str)
        document_and_random_descriptions_dataset = DataSource(
            "Document and Random Template Descriptions Dataset",
            data={
                "a": document_descriptions_flattened,
                "b": random_descriptions_flattened,
            },
        )
        random_similarities = CosineSimilarity(
            "Compute cosine similarities between documents and random descriptions",
            args={"embedder": embedder, "device": 0, "batch_size": 4, "lazy": False},
            inputs={
                "a": document_and_random_descriptions_dataset.output["a"],
                "b": document_and_random_descriptions_dataset.output["b"],
            },
        )
        random_similarities = list(random_similarities.output["similarities"])
        random_similarities = [
            random_similarities[i : i + K]
            for i in range(0, len(random_similarities), K)
        ]

        # # Create final embedding training dataset for embeddings with documents_and_descriptions_rows, sim_pairs_and_judgements, random_descriptions, random_similaritie
        # r = Random(42)
        # idxs = list(range(len(documents_and_descriptions_rows)))
        # r.shuffle(idxs)
        # final_rows = []
        # pos_examples = 0
        # neg_examples = 0
        # for idx in idxs:
        #     final_rows.append(
        #         {
        #             "a": documents_and_descriptions_rows[idx]["document"],
        #             "b": documents_and_descriptions_rows[idx]["description"],
        #             "sim": 1.0,
        #             "type": "document_to_description",
        #         }
        #     )
        #     sim_pairs_and_judgement = sim_pairs_and_judgements[idx].copy()
        #     if neg_examples > pos_examples:
        #         sim_pairs_and_judgement = sorted(
        #             sim_pairs_and_judgement,
        #             key=lambda x: int(x["judgement"]),
        #             reverse=True,
        #         )
        #     else:
        #         sim_pairs_and_judgement = sorted(
        #             sim_pairs_and_judgement, key=lambda x: int(x["judgement"])
        #         )
        #     if sim_pairs_and_judgement[0]["judgement"] is True:
        #         pos_examples += 1
        #     else:
        #         neg_examples += 1
        #     final_rows.append(
        #         {
        #             "a": sim_pairs_and_judgement[0]["document"],
        #             "b": sim_pairs_and_judgement[0]["compatible_document_description"],
        #             "sim": sim_pairs_and_judgement[0]["sim"],
        #             "type": ("document_")
        #             + (
        #                 "hard_positive"
        #                 if sim_pairs_and_judgement[0]["judgement"] is True
        #                 else "hard_negative"
        #             ),
        #         }
        #     )
        #     final_rows.append(
        #         {
        #             "a": documents_and_descriptions_rows[idx]["document"],
        #             "b": random_descriptions[idx][0],
        #             "sim": random_similarities[idx][0],
        #             "type": "document_random",
        #         }
        #     )

        # final_dataset = DataSource("Final Dataset", data=final_rows)
        # final_dataset.publish_to_hf_hub(
        #     "fineinstructions/matching_calibration", split="full"
        # )

        # Create final embedding training dataset for embeddings with documents_and_descriptions_rows, sim_pairs_and_judgements, random_descriptions, random_similaritie
        r = Random(42)
        idxs = list(range(len(documents_and_descriptions_rows)))
        r.shuffle(idxs)
        final_rows = []
        pos_examples = 0
        neg_examples = 0
        for idx in idxs:
            sim_pairs_and_judgement = sim_pairs_and_judgements[idx].copy()
            for subidx, row in enumerate(sim_pairs_and_judgement):
                if (row["judgement"] is True and pos_examples - neg_examples < K) or (
                    row["judgement"] is False and neg_examples - pos_examples < K
                ):
                    randchoice = r.choice([True, False])
                    final_rows.append(
                        {
                            "a": row["document"],
                            "b": random_descriptions[idx][subidx]
                            if (randchoice and row["judgement"] is False)
                            else row["compatible_document_description"],
                            "judgement": row["judgement"],
                        }
                    )
                    if row["judgement"] is True:
                        pos_examples += 1
                    else:
                        neg_examples += 1

        final_dataset = DataSource("Final Dataset Classifier", data=final_rows)
        final_dataset.publish_to_hf_hub(
            "fineinstructions/compatibility_classifier_dataset", split="full"
        )


__all__ = ["doc_to_description"]
