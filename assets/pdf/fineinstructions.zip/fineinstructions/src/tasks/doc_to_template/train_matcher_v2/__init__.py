import socket
from functools import partial

import torch
from datadreamer import DataDreamer
from datadreamer.steps import HFHubDataSource
from peft import LoraConfig

from .custom_datadreamer_modules import CoverageTrainSentenceTransformer, custom_loss

MARGIN = 0.05
NUMBER_OF_CHUNKS = 10


def map_rows_to_training_format(row):
    label = (
        {
            "document_to_description": 1,
            "random": 0,
            "document_random": 0,
            "document_hard_positive": 1,
            "document_hard_negative": 0,
            "hard_positive": 1,
            "hard_negative": 0,
        }
    ).get(row["type"], 0)
    return {
        "a": row["a"],
        "b": row["b"],
        "label": row["chunk_idx"] + ((NUMBER_OF_CHUNKS + 1) if label == 1 else 0),
    }


def train_matcher_v2(ctx):
    from ....project import (
        get_persistent_dir,
        get_torch_cpu_device,
        get_torch_devices,
        reporter,
    )

    reporter.set("doc_to_template.train_matcher_v2", "train_matcher_v2")
    datadreamer_output_dir = get_persistent_dir(
        "train_matcher_v2", "doc_to_template.train_matcher_v2"
    )

    with DataDreamer(datadreamer_output_dir, log_date=True):
        MODEL_NAME = "BAAI/bge-m3"
        PEFT_CONFIG = LoraConfig(r=64)
        EPOCHS = 5
        LEARNING_RATE = 1e-4
        BATCH_SIZE = 1
        DTYPE = torch.bfloat16 if len(get_torch_devices()) > 0 else torch.float32
        TRAIN_DEVICE = (
            get_torch_devices()
            if len(get_torch_devices()) > 0
            else get_torch_cpu_device()
        )
        GRADIENT_ACCUMULATION_STEPS = 64 // len(get_torch_devices())
        INFERENCE_DEVICE = TRAIN_DEVICE
        VALIDATION_SIZE = 6400

        print("----------------------------------------")
        print("HOSTNAME:", socket.gethostname())
        print("EPOCHS:", EPOCHS)
        print("TRAIN_DEVICE:", TRAIN_DEVICE)
        print("INFERENCE_DEVICE:", INFERENCE_DEVICE)
        print("DTYPE:", DTYPE)
        print("BATCH_SIZE:", BATCH_SIZE)
        print("GRADIENT_ACCUMULATION_STEPS:", GRADIENT_ACCUMULATION_STEPS)
        print("----------------------------------------")

        # Load matching calibration dataset
        dataset = HFHubDataSource(
            "Get Matching Calibration v2",
            "fineinstructions/matching_calibration_v2",
            revision="f3aa6658e57e89410e91e37ffcb441b81fee96cc",
            split="full",
        )

        # Modify dataset to adjust sims
        dataset = dataset.map(
            map_rows_to_training_format, lazy=False, name="Create labels"
        )
        dataset = dataset.filter(
            lambda x: len(x["a"]) <= 10000 and len(x["b"]) <= 10000,
            lazy=False,
            name="Filter out the too long rows",
        )

        # Create split for training
        splits = dataset.splits(
            train_size=len(dataset.output) - VALIDATION_SIZE,
            validation_size=VALIDATION_SIZE,
        )
        train_split, validation_split = splits["train"], splits["validation"]

        # Train End-to-End model
        trainer = CoverageTrainSentenceTransformer(
            "Train Matching Embedding",
            model_name=MODEL_NAME,
            trust_remote_code=True,
            peft_config=PEFT_CONFIG,
            device=TRAIN_DEVICE,
            dtype=DTYPE,
            fsdp=False,
        )
        TRAIN_MARGIN = 0.45
        trainer.train_with_labeled_pairs(
            train_anchors=train_split.output["a"],
            train_others=train_split.output["b"],
            train_labels=train_split.output["label"],
            validation_anchors=validation_split.output["a"],
            validation_others=validation_split.output["b"],
            validation_labels=validation_split.output["label"],
            margin=TRAIN_MARGIN,
            loss=partial(custom_loss, margin=TRAIN_MARGIN),
            epochs=EPOCHS,
            early_stopping_patience=5,
            batch_size=BATCH_SIZE,
            learning_rate=LEARNING_RATE,
            lr_scheduler_type="constant",
            gradient_accumulation_steps=GRADIENT_ACCUMULATION_STEPS,
            gradient_checkpointing=True,
            batch_eval_metrics=True,
            eval_strategy="steps",
            save_strategy="steps",
            eval_steps=600,
            save_steps=600,
            save_total_limit=None,
        )
        trainer.publish_to_hf_hub(
            "fineinstructions/instruction_template_retrieval_embedding",
            adapter_only=False,
        )


__all__ = ["train_matcher_v2"]
