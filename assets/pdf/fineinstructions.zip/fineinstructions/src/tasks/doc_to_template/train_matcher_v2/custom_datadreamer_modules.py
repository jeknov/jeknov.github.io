from functools import cache, partial

import torch
from datadreamer.embedders.sentence_transformers_embedder import _normalize_model_name
from datadreamer.trainers import TrainSentenceTransformer
from datadreamer.utils.arg_utils import DEFAULT, default_to
from datadreamer.utils.background_utils import RunIfTimeout
from datadreamer.utils.hf_model_utils import (
    filter_model_warnings,
    get_model_max_context_length,
    get_tokenizer,
    validate_peft_config,
)
from datadreamer.utils.import_utils import ignore_transformers_warnings
from torch.nn import functional as F

from .pooling_coverage import use_gaussian_coverage_pooling

with ignore_transformers_warnings():
    from sentence_transformers import SentenceTransformer, losses
    from transformers import Trainer

coverage_chunks = 10
sigma = 0.05
alpha = 1.0


@cache
def patch_trainer():
    old_prediction_step = Trainer.prediction_step

    def custom_prediction_step(self, *args, **kwargs):
        rval = old_prediction_step(self, *args, **kwargs)
        orig_labels = rval[2]
        labels = (orig_labels > coverage_chunks).to(orig_labels.dtype)
        rval = (rval[0], rval[1], labels)
        return rval

    Trainer.prediction_step = custom_prediction_step


class CustomSentenceTransformer(SentenceTransformer):
    def forward(self, input, **kwargs):
        chunk_indicators = kwargs.pop("chunk_indicators")
        for module_name, module in self.named_children():
            module_kwarg_keys = {}.get(module_name, [])
            module_kwargs = {
                key: value for key, value in kwargs.items() if key in module_kwarg_keys
            }
            if module_name == "1":
                input = module(
                    input, **module_kwargs, chunk_indicators=chunk_indicators
                )
            else:
                input = module(input, **module_kwargs)
        return input


class CoverageTrainSentenceTransformer(TrainSentenceTransformer):
    def _create_model(self, *args, **kwargs) -> SentenceTransformer:
        patch_trainer()
        device = DEFAULT
        # Seed
        if self.seed:
            torch.manual_seed(self.seed)
            if torch.cuda.is_available():  # pragma: no cover
                torch.cuda.manual_seed_all(self.seed)

        # Load model
        log_if_timeout = RunIfTimeout(
            partial(lambda self: self.logger.info("Loading model..."), self),
            timeout=10.0,
        )
        model_device = default_to(device, self.device)
        model = CustomSentenceTransformer(
            self.model_name,
            trust_remote_code=self.trust_remote_code,
            device="cpu" if isinstance(model_device, list) else model_device,  # type:ignore[arg-type]
            **self.kwargs,
        )
        model = use_gaussian_coverage_pooling(
            model, coverage_chunks=coverage_chunks, sigma=sigma, alpha=alpha
        )
        model._modules["1"].pooling_mode_mean_tokens = True  # Enable mean pooling
        model._modules["1"].pooling_mode_cls_token = False  # Disable CLS pooling
        model._modules["1"].pooling_mode_max_tokens = False  # Disable max pooling
        model[0].tokenizer = get_tokenizer(
            _normalize_model_name(self.model_name),
            revision=None,
            trust_remote_code=self.trust_remote_code,
        )
        model.max_seq_length = (
            get_model_max_context_length(
                model_name=self.model_name, config=model[0].auto_model.config
            )
            if model.max_seq_length is None
            else model.max_seq_length
        )
        self.max_seq_length = model.max_seq_length

        # Set model dtype
        model = model.to(self.dtype)

        # Create PeftModel if peft_config
        if self.peft_config:
            # Two warnings we can't silence are thrown by peft at import-time so
            # we import this library only when needed
            with ignore_transformers_warnings():
                from peft import get_peft_model, prepare_model_for_kbit_training

            if self.quantization_config:  # pragma: no cover
                model = prepare_model_for_kbit_training(
                    model, use_gradient_checkpointing=True
                )
            model = get_peft_model(model, validate_peft_config(model, self.peft_config))

        # Switch model to train mode
        model.train()

        # Filter any warnings from the model
        filter_model_warnings()

        # Finished loading
        log_if_timeout.stop(
            partial(lambda self: self.logger.info("Finished loading."), self)
        )

        return model


class CustomContrastiveLoss(losses.ContrastiveLoss):
    def forward(self, sentence_features, labels):
        orig_labels = labels
        labels = (labels > coverage_chunks).to(orig_labels.dtype)
        chunk_indicators = torch.remainder(orig_labels, coverage_chunks + 1).to(
            orig_labels.dtype
        )
        zero_chunk_indicators = torch.zeros_like(chunk_indicators)
        reps = [
            self.model(
                sentence_feature,
                chunk_indicators=(
                    chunk_indicators if rep_idx == 0 else zero_chunk_indicators
                ),
            )["sentence_embedding"]
            for rep_idx, sentence_feature in enumerate(sentence_features)
        ]
        assert len(reps) == 2
        rep_anchor, rep_other = reps
        distances = self.distance_metric(rep_anchor, rep_other)
        losses = 0.5 * (
            labels.float() * distances.pow(2)
            + (1 - labels).float() * F.relu(self.margin - distances).pow(2)
        )
        return (
            (losses.mean() + 0.0 * sum(p.sum() for p in self.model.model.parameters()))
            if self.size_average
            else (
                losses.sum() + 0.0 * sum(p.sum() for p in self.model.model.parameters())
            )
        )


def custom_loss(model, margin):
    return CustomContrastiveLoss(
        model,
        distance_metric=losses.SiameseDistanceMetric.COSINE_DISTANCE,
        margin=default_to(margin, 0.2),
    )
