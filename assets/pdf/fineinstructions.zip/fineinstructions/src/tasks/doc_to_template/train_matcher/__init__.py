import socket

import torch
from datadreamer import DataDreamer
from datadreamer.steps import HFHubDataSource
from datadreamer.trainers import TrainSentenceTransformer
from peft import LoraConfig


def train_matcher(ctx):
    from ....project import (
        get_persistent_dir,
        get_torch_cpu_device,
        get_torch_devices,
        reporter,
    )

    reporter.set("doc_to_template.train_matcher", "train_matcher")
    datadreamer_output_dir = get_persistent_dir(
        "train_matcher", "doc_to_template.train_matcher"
    )

    with DataDreamer(datadreamer_output_dir, log_date=True):
        MODEL_NAME = "BAAI/bge-m3"
        PEFT_CONFIG = LoraConfig(r=8)
        EPOCHS = 2
        LEARNING_RATE = 1e-4
        BATCH_SIZE = 1
        DTYPE = torch.bfloat16 if len(get_torch_devices()) > 0 else torch.float32
        TRAIN_DEVICE = (
            get_torch_devices()
            if len(get_torch_devices()) > 0
            else get_torch_cpu_device()
        )
        GRADIENT_ACCUMULATION_STEPS = 64 // len(get_torch_devices())
        INFERENCE_DEVICE = TRAIN_DEVICE
        VALIDATION_SIZE = 6400

        print("----------------------------------------")
        print("HOSTNAME:", socket.gethostname())
        print("EPOCHS:", EPOCHS)
        print("TRAIN_DEVICE:", TRAIN_DEVICE)
        print("INFERENCE_DEVICE:", INFERENCE_DEVICE)
        print("DTYPE:", DTYPE)
        print("BATCH_SIZE:", BATCH_SIZE)
        print("GRADIENT_ACCUMULATION_STEPS:", GRADIENT_ACCUMULATION_STEPS)
        print("----------------------------------------")

        # Load matching calibration dataset
        dataset = HFHubDataSource(
            "Get Matching Calibration",
            "fineinstructions/matching_calibration",
            revision="381df5316797c29898ad541ca0b137da3a657ead",
            split="full",
        )

        # Modify dataset to adjust sims
        MARGIN = 0.05
        dataset = dataset.map(
            lambda x: {
                "a": x["a"],
                "b": x["b"],
                "sim": (
                    x["sim"] + MARGIN
                    if "hard_positive" in x["type"]
                    else x["sim"] - MARGIN
                )
                if x["type"]
                in [
                    "document_hard_positive",
                    "document_hard_negative",
                    "hard_positive",
                    "hard_negative",
                ]
                else x["sim"],
                "label": (
                    {
                        "document_to_description": 1,
                        "random": 0,
                        "document_random": 0,
                        "document_hard_positive": 1,
                        "document_hard_negative": 0,
                        "hard_positive": 1,
                        "hard_negative": 0,
                    }
                ).get(x["type"], 0),
            },
            lazy=False,
            name="Create labels",
        )
        dataset = dataset.filter(
            lambda x: len(x["a"]) <= 10000 and len(x["b"]) <= 10000,
            lazy=False,
            name="Filter out the too long rows",
        )

        # Create split for training
        splits = dataset.splits(
            train_size=len(dataset.output) - VALIDATION_SIZE,
            validation_size=VALIDATION_SIZE,
        )
        train_split, validation_split = splits["train"], splits["validation"]

        # Train End-to-End model
        trainer = TrainSentenceTransformer(
            "Train Matching Embedding",
            model_name=MODEL_NAME,
            peft_config=PEFT_CONFIG,
            device=TRAIN_DEVICE,
            dtype=DTYPE,
            fsdp=False,
        )
        trainer.train_with_labeled_pairs(
            train_anchors=train_split.output["a"],
            train_others=train_split.output["b"],
            train_labels=train_split.output["label"],
            validation_anchors=validation_split.output["a"],
            validation_others=validation_split.output["b"],
            validation_labels=validation_split.output["label"],
            margin=0.46,
            epochs=EPOCHS,
            early_stopping_patience=5,
            batch_size=BATCH_SIZE,
            learning_rate=LEARNING_RATE,
            lr_scheduler_type="constant",
            gradient_accumulation_steps=GRADIENT_ACCUMULATION_STEPS,
            gradient_checkpointing=True,
            batch_eval_metrics=True,
            eval_strategy="steps",
            save_strategy="steps",
            eval_steps=600,
            save_steps=600,
            save_total_limit=None,
        )
        trainer.publish_to_hf_hub(
            "fineinstructions/instruction_template_retrieval_embedding",
            adapter_only=False,
        )


__all__ = ["train_matcher"]
