import os
import sys
from functools import cached_property

import numpy as np
import torch
from datadreamer.embedders import SentenceTransformersEmbedder
from datadreamer.retrievers import EmbeddingRetriever
from datadreamer.utils.background_utils import (
    dill_serializer,
    proxy_resource_in_background,
)
from datadreamer.utils.import_utils import (
    ignore_faiss_warnings,
    ignore_transformers_warnings,
)
from huggingface_hub import hf_hub_download
from sqlitedict import SqliteDict

from .input_coverage import use_gaussian_input_embeddings

with ignore_transformers_warnings():
    from sentence_transformers import SentenceTransformer

with ignore_faiss_warnings():
    import faiss

coverage_chunks = 10
sigma = 0.05
alpha = 0.9


class CoverageSentenceTransformersEmbedder(SentenceTransformersEmbedder):
    @cached_property
    def model(self) -> SentenceTransformer:
        return use_gaussian_input_embeddings(
            SentenceTransformersEmbedder.model.func(self),
            coverage_chunks=coverage_chunks,
            sigma=sigma,
            alpha=alpha,
        )

    @cached_property
    def dims(self) -> int:
        return SentenceTransformersEmbedder.dims.func(self) * coverage_chunks

    @torch.no_grad()
    def _run_batch(self, *args, **kwargs) -> list[np.ndarray]:
        kwargs["normalize_embeddings"] = False
        return SentenceTransformersEmbedder._run_batch(self, *args, **kwargs)


class CoverageEmbeddingRetriever(EmbeddingRetriever):
    @cached_property
    def index(self):  # noqa: C901
        class FAISSIndexResource:
            def __init__(self_resource) -> None:
                faiss_index_path = hf_hub_download(
                    "fineinstructions/finetemplates",
                    "faiss_index/finetemplates.index",
                    revision="7b7638debc46cc9ee6bec17ce9006e7838dbf10c",
                    repo_type="dataset",
                )
                index = faiss.read_index(
                    faiss_index_path, faiss.IO_FLAG_MMAP | faiss.IO_FLAG_READ_ONLY
                )
                index.nprobe = 150
                if self.device is not None:  # pragma: no cover
                    index = faiss.index_cpu_to_gpus_list(index=index, gpus=self.device)
                index_lookup = SqliteDict(
                    ":memory:", tablename="lookup", journal_mode="WAL", autocommit=False
                )
                self_resource.index = index
                self_resource.index_lookup = index_lookup

            @dill_serializer
            def search(self_resource, vecs, *args, **kwargs) -> None:
                returned_coverage_chunks = coverage_chunks + 1
                vecs = vecs.reshape(-1, vecs.shape[1] // (returned_coverage_chunks))
                vecs = np.vstack(vecs)
                scores_batch, indices_batch = self_resource.index.search(
                    vecs, *args, **kwargs
                )
                scores_per_input, indices_per_input = (
                    [
                        scores_batch[i : i + returned_coverage_chunks]
                        for i in range(0, len(scores_batch), returned_coverage_chunks)
                    ],
                    [
                        indices_batch[i : i + returned_coverage_chunks]
                        for i in range(0, len(indices_batch), returned_coverage_chunks)
                    ],
                )
                return scores_per_input, indices_per_input

            def decode(self_resource, *args, **kwargs):
                return self_resource.index_lookup.decode(*args, **kwargs)

            def select(self_resource, *args, **kwargs):
                return self_resource.index_lookup.conn.select(*args, **kwargs)

        env = os.environ.copy()
        faiss_resource = proxy_resource_in_background(
            FAISSIndexResource, env=env, run_in_background=(sys.platform == "darwin")
        )
        return (faiss_resource, faiss_resource)

    def _run_batch(self, max_length_func, inputs, k: int = 5, batch_size=4, **kwargs):
        queries = inputs
        final_kwargs = self.kwargs.copy()
        final_kwargs.update(kwargs)
        queries_embedded = np.vstack(
            self.embedder.run(
                texts=queries,
                truncate=self.truncate,
                instruction=self.query_instruction,
                batch_size=len(queries),
                **final_kwargs,
            )
        )
        index, _ = self.index
        scores, results = index.proxy.search(queries_embedded, k=k)
        return [
            {
                "indices": query_result,
                "texts": ["" for _ in query_result],
                "scores": query_result_scores,
            }
            for query_result_scores, query_result in zip(scores, results)
        ]
