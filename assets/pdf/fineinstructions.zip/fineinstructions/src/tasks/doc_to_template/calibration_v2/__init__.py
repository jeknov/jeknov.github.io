import itertools
import os
import sys
from collections import defaultdict
from random import Random

import torch
from datadreamer import DataDreamer
from datadreamer.embedders import ParallelEmbedder
from datadreamer.steps import (
    DataSource,
    HFDatasetDataSource,
    HFHubDataSource,
    Prompt,
    Retrieve,
    zipped,
)

from ....datadreamer_ext.openrouter import OpenRouter
from ..doc_to_description.description_prompts import (
    create_judge_prompts_v2,
    post_process_judgement,
)
from .custom_datadreamer_modules import (
    CoverageEmbeddingRetriever,
    CoverageSentenceTransformersEmbedder,
    coverage_chunks,
)


def calibration_v2(ctx):  # noqa: C901
    from ....project import get_persistent_dir, get_torch_devices, reporter

    # Flag to control whether to force re-run the pipeline without caching
    FORCE = False

    reporter.set(
        "doc_to_description.datadreamer_output", "doc_to_description_datadreamer_output"
    )
    datadreamer_output_dir = get_persistent_dir(
        "doc_to_description_datadreamer_output",
        "doc_to_description.doc_to_description_datadreamer_output",
    )

    with DataDreamer(datadreamer_output_dir, log_date=True):
        llm_70 = OpenRouter(
            model_name="meta-llama/llama-3.3-70b-instruct",
            api_key=os.environ["OPENROUTER_API_KEY"],
            base_url="https://openrouter.ai/api/v1",
        )

        # Load FineWeb documents and descriptions
        documents_and_descriptions = HFDatasetDataSource(
            "Get Documents and Descriptions",
            os.path.realpath(
                os.path.join(
                    datadreamer_output_dir, "exports", "documents_and_descriptions"
                )
            ),
        )
        documents_and_descriptions_rows = (
            documents_and_descriptions.output.dataset.to_list()
        )

        # Get all templates
        templates_dataset = HFHubDataSource(
            "Get Templates Dataset",
            "fineinstructions/finetemplates",
            revision="7b7638debc46cc9ee6bec17ce9006e7838dbf10c",
            split="full",
        )
        templates_dataset_rows = templates_dataset.output.dataset.to_list()

        # Create a retriever
        K = 10
        r = Random(42)
        embedder = ParallelEmbedder(
            *[
                CoverageSentenceTransformersEmbedder(
                    "fineinstructions/instruction_template_retrieval_embedding",
                    revision="7da433f0385af9e0e4b79a0669298356e2e1cbcf",
                    device=d,
                )
                for d in get_torch_devices()[1:]
            ]
        )
        retriever = CoverageEmbeddingRetriever(
            texts=templates_dataset.take(1).output["compatible_document_description"],
            embedder=embedder,
            truncate=True,
            device=torch.device(0),
        )
        queries = documents_and_descriptions.output["document"]
        most_compatible_templates = Retrieve(  # noqa: F841
            "Retrieve most compatible template descriptions",
            args={
                "retriever": retriever,
                "k": coverage_chunks * K,
                "index_batch_size": 1,
                "batch_size": 1,
                "lazy": False,
            },
            inputs={"queries": queries},
        )
        sim_pairs = []
        for row_idx, row in enumerate(most_compatible_templates.output["results"]):
            if row_idx % 1000 == 0:
                print(
                    f"Sampling most compatible templates for row #{row_idx} of {len(documents_and_descriptions_rows)}",
                    file=sys.stderr,
                )
            qa_sim_pairs_for_row = defaultdict(list)
            tasky_sim_pairs_for_row = defaultdict(list)
            seen = set()
            for chunk_idx, (indices_per_chunk, sim_per_chunk) in enumerate(
                zip(row["indices"], row["scores"])
            ):
                for sim_idx, sim in zip(indices_per_chunk, sim_per_chunk):
                    sim_row = templates_dataset_rows[sim_idx]
                    if sim_idx not in seen:
                        seen.add(sim_idx)
                        if sim_row["qa_or_tasky"] == "tasky":
                            append_to = tasky_sim_pairs_for_row[chunk_idx]
                        else:
                            append_to = qa_sim_pairs_for_row[chunk_idx]
                        append_to.append(
                            {
                                "chunk_idx": chunk_idx,
                                "row_idx": row_idx,
                                "sim_idx": sim_idx,
                                "document": documents_and_descriptions_rows[row_idx][
                                    "document"
                                ],
                                "description": documents_and_descriptions_rows[row_idx][
                                    "description"
                                ],
                                "template": sim_row["template"],
                                "tasky": sim_row["qa_or_tasky"] == "tasky",
                                "compatible_document_description": sim_row[
                                    "compatible_document_description"
                                ],
                                "sim": sim,
                            }
                        )

            seen_samples = set()
            for _ in range(K):
                random_chunk_idxs = list(range(coverage_chunks + 1))
                rotate_at = r.randint(0, len(random_chunk_idxs) - 1)
                random_chunk_idxs = (
                    random_chunk_idxs[rotate_at:] + random_chunk_idxs[:rotate_at]
                )
                tasky = r.choice([True, False])
                found = False
                for random_chunk_idx in random_chunk_idxs:
                    sim_pairs_for_row = (
                        (
                            tasky_sim_pairs_for_row[random_chunk_idx]
                            + qa_sim_pairs_for_row[random_chunk_idx]
                        )
                        if tasky
                        else (
                            qa_sim_pairs_for_row[random_chunk_idx]
                            + tasky_sim_pairs_for_row[random_chunk_idx]
                        )
                    )
                    for sim_pair_idx in range(len(sim_pairs_for_row)):
                        if (
                            sim_pairs_for_row[sim_pair_idx]["sim_idx"]
                            not in seen_samples
                        ):
                            seen_samples.add(sim_pairs_for_row[sim_pair_idx]["sim_idx"])
                            sim_pairs.append(sim_pairs_for_row[sim_pair_idx])
                            found = True
                            break
                        else:
                            continue
                    if found:
                        break
        assert len(sim_pairs) == queries.num_rows * K
        sim_pairs = DataSource("Get Similar Pairs v2", data=sim_pairs)

        # Judge similar pairs
        judge_prompts = sim_pairs.map(
            create_judge_prompts_v2,
            lazy=False,
            name="Create Judge Prompts v2",
            force=FORCE,
        )
        judgements = Prompt(
            name="Generate Judgements v2",
            inputs={"prompts": judge_prompts.output["prompt"]},
            args={
                "llm": llm_70,
                "batch_size": 120,
                "temperature": 1.0,
                "top_p": 0.0,
                "max_new_tokens": 3000,
                "post_process": post_process_judgement,
            },
            outputs={"generations": "judgement"},
            force=FORCE,
        ).select_columns(["judgement"], name="Get Judgements v2")
        sim_pairs_and_judgements = list(
            zipped(
                sim_pairs,
                judgements,
                name="Combine sim_pairs + judgements v2",
                lazy=False,
            ).output.dataset
        )
        sim_pairs_and_judgements = [
            sim_pairs_and_judgements[i : i + K]
            for i in range(0, len(sim_pairs_and_judgements), K)
        ]

        # Get K random template descriptions for each document
        r = Random(42)
        template_compatible_document_descriptions = [
            row["compatible_document_description"] for row in templates_dataset_rows
        ]
        random_descriptions = [
            r.sample(template_compatible_document_descriptions, K)
            for _ in documents_and_descriptions_rows
        ]
        random_descriptions_flattened = list(
            itertools.chain.from_iterable(random_descriptions)
        )

        # Repeat the document descriptions K times
        document_descriptions = [
            [row["description"]] * K for row in documents_and_descriptions_rows
        ]
        document_descriptions_flattened = list(
            itertools.chain.from_iterable(document_descriptions)
        )

        # Create dataset and compute cosine similarities between document and each random template
        assert len(document_descriptions_flattened) == len(
            random_descriptions_flattened
        )
        assert isinstance(document_descriptions_flattened[0], str)
        assert isinstance(random_descriptions_flattened[0], str)
        assert len(documents_and_descriptions_rows) == len(sim_pairs_and_judgements)
        assert len(documents_and_descriptions_rows) == len(random_descriptions)

        # Create final embedding training dataset for embeddings with documents_and_descriptions_rows, sim_pairs_and_judgements, random_descriptions, random_similaritie
        r = Random(42)
        idxs = list(range(len(documents_and_descriptions_rows)))
        r.shuffle(idxs)
        final_rows = []
        pos_examples = 0
        neg_examples = 0
        for idx in idxs:
            current_rows = []
            # current_rows.append(
            #     {
            #         "a": documents_and_descriptions_rows[idx]["document"],
            #         "b": documents_and_descriptions_rows[idx]["description"],
            #         "chunk_idx": 0,
            #         "type": "document_to_description",
            #     }
            # )
            # pos_examples += 1

            sim_pairs_and_judgement = sim_pairs_and_judgements[idx].copy()
            for subidx, row in enumerate(sim_pairs_and_judgement):
                sim_pairs_and_judgement_other = list(
                    filter(
                        lambda other_row: abs(other_row["chunk_idx"] - row["chunk_idx"])
                        >= 6,
                        [
                            row
                            for row in sim_pairs_and_judgement
                            if row["judgement"] is True
                        ],
                    )
                )
                r.shuffle(sim_pairs_and_judgement_other)
                sim_pairs_and_judgement_other = (
                    sim_pairs_and_judgement_other
                    + [
                        row
                        for row in sim_pairs_and_judgement
                        if row["judgement"] is True
                    ]
                    + list(
                        filter(
                            lambda other_row: abs(
                                other_row["chunk_idx"] - row["chunk_idx"]
                            )
                            >= 6,
                            [
                                row
                                for row in sim_pairs_and_judgement
                                if row["judgement"] is False
                            ],
                        )
                    )
                    + sim_pairs_and_judgement
                )
                if (
                    row["judgement"] is True and pos_examples - neg_examples < (K // 2)
                ) or (
                    row["judgement"] is False and neg_examples - pos_examples < (K // 2)
                ):
                    if row["judgement"] is True:
                        current_rows.append(
                            {
                                "a": row["document"],
                                "b": row["compatible_document_description"],
                                "chunk_idx": row["chunk_idx"],
                                "type": ("document_") + "hard_positive",
                            }
                        )
                    else:
                        randchoice = r.choice([0, 1, 2])
                        if randchoice == 0:
                            current_rows.append(
                                {
                                    "a": row["document"],
                                    "b": row["compatible_document_description"],
                                    "chunk_idx": row["chunk_idx"],
                                    "type": "document_hard_negative",
                                }
                            )
                        elif randchoice == 1:
                            current_rows.append(
                                {
                                    "a": row["document"],
                                    "b": random_descriptions[idx][subidx],
                                    "chunk_idx": row["chunk_idx"],
                                    "type": "document_random",
                                }
                            )
                        elif randchoice == 2:
                            current_rows.append(
                                {
                                    "a": row["document"],
                                    "b": sim_pairs_and_judgement_other[0][
                                        "compatible_document_description"
                                    ],
                                    "chunk_idx": row["chunk_idx"],
                                    "type": "document_hard_negative",
                                }
                            )
                    if row["judgement"] is True:
                        pos_examples += 1
                    else:
                        neg_examples += 1
            r.shuffle(current_rows)
            final_rows.extend(current_rows)

        final_dataset = DataSource("Final Dataset v2", data=final_rows)
        final_dataset.publish_to_hf_hub(
            "fineinstructions/matching_calibration_v2", split="full"
        )


__all__ = ["calibration_v2"]
