import torch
from sentence_transformers import SentenceTransformer


def attention_mask_to_coverage(attention_mask, coverage_chunks, sigma):
    batch_size, seq_len = attention_mask.shape
    device = attention_mask.device

    # Compute actual sequence lengths (ignoring padding)
    seq_lengths = attention_mask.squeeze(-1).sum(dim=1, keepdim=True)  # (batch_size, 1)
    max_seq_length = int(torch.max(seq_lengths).item())

    # Compute chunk centers dynamically based on sequence length
    chunk_positions = torch.linspace(0, 1, coverage_chunks + 2, device=device)[
        1:-1
    ]  # Excludes 0 and 1
    chunk_centers = chunk_positions * seq_lengths  # (batch_size, N)

    # Token positions per sequence (batch_size, seq_len)
    token_positions = (
        torch.arange(seq_len, device=device).float().unsqueeze(0)
    )  # (1, seq_len)

    # Compute Gaussian weights (batch_size, N, seq_len)
    seq_lengths = seq_lengths.view(seq_lengths.shape[0], 1, 1).repeat(
        1, coverage_chunks, max_seq_length
    )
    gaussians = torch.exp(
        -0.5
        * (
            (token_positions.unsqueeze(1) - chunk_centers.unsqueeze(2))
            / (sigma * seq_lengths)
        )
        ** 2
    )
    ones_row = torch.ones(
        gaussians.shape[0],
        1,
        gaussians.shape[2],
        dtype=gaussians.dtype,
        device=gaussians.device,
    )
    gaussians = torch.cat((ones_row, gaussians), dim=1)

    # Weighted attention mask
    weighted_attention_mask = torch.einsum("ij,ikj->ikj", attention_mask, gaussians)
    new_mask = (weighted_attention_mask > 0.5).long()

    return new_mask


class GaussianCoverageInputEmbedding(torch.nn.Module):
    def __init__(self, pad_token_id, original_layer, coverage_chunks, sigma, alpha):
        """
        Custom input embedding layer that covers the document using Gaussian-based weights.

        Args:
            coverage_chunks (int): Number of embeddings (N).
            sigma (float): Standard deviation for Gaussian weighting.
            alpha (float): Weighting factor for standard mean pooling.
        """
        super().__init__()
        self.pad_token_id = pad_token_id
        self.embedding = original_layer  # Start with the original embeddings
        self.coverage_chunks = coverage_chunks
        self.sigma = sigma
        self.alpha = alpha

    def forward(self, input_ids, *args, **kwargs):
        attention_mask = (input_ids != self.pad_token_id).long()
        attention_mask = attention_mask_to_coverage(
            attention_mask=attention_mask,
            coverage_chunks=self.coverage_chunks,
            sigma=self.sigma,
        )
        expanded_input_ids = input_ids.unsqueeze(1).expand(
            -1, self.coverage_chunks + 1, -1
        )
        new_input_ids = torch.where(
            attention_mask == 1, expanded_input_ids, self.pad_token_id
        )
        new_input_ids = new_input_ids.view(
            (self.coverage_chunks + 1) * input_ids.shape[0], new_input_ids.shape[2]
        )
        kwargs["token_type_ids"] = torch.repeat_interleave(
            kwargs["token_type_ids"], self.coverage_chunks + 1, dim=0
        )
        new_embeddings = self.embedding(new_input_ids, *args, **kwargs)
        return new_embeddings


class GaussianCoverageInputEmbeddingPooling(torch.nn.Module):
    def __init__(self, coverage_chunks, sigma, alpha):
        """
        Custom pooling layer that computes weighted mean pooling using Gaussian-based weights.

        Args:
            coverage_chunks (int): Number of input embeddings (N).
            sigma (float): Standard deviation for Gaussian weighting.
            alpha (float): Weighting factor for standard mean pooling.
        """
        super().__init__()
        self.coverage_chunks = coverage_chunks
        self.sigma = sigma
        self.alpha = alpha

    def forward(self, features):
        token_embeddings = features[
            "token_embeddings"
        ]  # (batch_size, seq_len, hidden_dim)
        batch_size = token_embeddings.shape[0] // (self.coverage_chunks + 1)
        attention_mask = attention_mask_to_coverage(
            attention_mask=features["attention_mask"],
            coverage_chunks=self.coverage_chunks,
            sigma=self.sigma,
        )
        attention_mask = attention_mask.view(
            (self.coverage_chunks + 1) * attention_mask.shape[0],
            attention_mask.shape[2],
        )
        attention_mask = attention_mask.float().unsqueeze(
            -1
        )  # (batch_size, seq_len, 1)

        # CLS pooling
        pooled = token_embeddings[:, 0, :]  # (batch_size, hidden_dim)

        # Merge and weight
        pooled = pooled.view(batch_size, pooled.shape[0] // batch_size, pooled.shape[1])
        pooled_entire_seq = pooled[:, 0:1, :]
        pooled_chunks = pooled[:, :, :]
        pooled = ((1 - self.alpha) * pooled_entire_seq) + ((self.alpha) * pooled_chunks)
        pooled[
            :, 0:1, :
        ] = pooled_entire_seq  # Leave the entire document embedding in-tact
        pooled = pooled.view((self.coverage_chunks + 1) * batch_size, pooled.shape[2])

        # Normalize and reshape
        normalized = torch.nn.functional.normalize(pooled, p=2, dim=1)
        reshaped = normalized.view(
            normalized.shape[0] // (self.coverage_chunks + 1),
            normalized.shape[1] * (self.coverage_chunks + 1),
        )

        features["sentence_embedding"] = reshaped
        return features


def use_gaussian_input_embeddings(m, coverage_chunks=10, sigma=0.2, alpha=0.5):
    """
    Custom input embedding layer that covers the document using Gaussian-based weights.

    Args:
        coverage_chunks (int): Number of embeddings (N).
        sigma (float): Standard deviation for Gaussian weighting.
        alpha (float): Weighting factor for standard pooling.
    """
    old_forward = m[0].auto_model.forward

    def update_attention_mask(*args, **kwargs):
        kwargs["attention_mask"] = attention_mask_to_coverage(
            attention_mask=kwargs["attention_mask"],
            coverage_chunks=coverage_chunks,
            sigma=sigma,
        ).view(
            (coverage_chunks + 1) * kwargs["attention_mask"].shape[0],
            kwargs["attention_mask"].shape[1],
        )
        return old_forward(*args, **kwargs)

    m[0].auto_model.old_forward = old_forward
    m[0].auto_model.forward = update_attention_mask
    original_embedding_layer = m[0].auto_model.embeddings
    custom_embedding_layer = GaussianCoverageInputEmbedding(
        m[0].tokenizer.pad_token_id,
        original_embedding_layer,
        coverage_chunks=coverage_chunks,
        sigma=sigma,
        alpha=alpha,
    )
    m[0].auto_model.old_embeddings = m[0].auto_model.embeddings
    m[0].auto_model.embeddings = custom_embedding_layer
    word_embedding_model = m[0]
    old_pooling = m[1]
    custom_pooling = GaussianCoverageInputEmbeddingPooling(
        coverage_chunks=coverage_chunks, sigma=sigma, alpha=alpha
    )
    new_m = SentenceTransformer(modules=[word_embedding_model, custom_pooling])
    new_m.old_pooling = {"old_pooling": old_pooling}
    return new_m


def unuse_gaussian_input_embeddings(m):
    if isinstance(m[1], GaussianCoverageInputEmbeddingPooling):
        new_m = SentenceTransformer(modules=[m[0], m.old_pooling["old_pooling"]])
        new_m[0].auto_model.forward = new_m[0].auto_model.old_forward
        new_m[0].auto_model.embeddings = new_m[0].auto_model.old_embeddings
        return new_m
    else:
        return m
