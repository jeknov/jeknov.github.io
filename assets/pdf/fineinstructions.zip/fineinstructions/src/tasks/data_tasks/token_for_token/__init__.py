import gc
import io
import json
import os
import random
import re
from functools import cache, partial
from time import sleep

import click
from datasets import Dataset, load_dataset
from datasets.exceptions import DatasetNotFoundError
from filelock import FileLock, Timeout
from huggingface_hub import create_repo, hf_hub_download, list_repo_files, upload_file
from huggingface_hub.errors import RepositoryNotFoundError
from transformers import AutoTokenizer


@cache
def get_shard_token_counts(source_dataset):
    while True:
        try:
            with open(
                hf_hub_download(
                    source_dataset, "shard_token_counts.json", repo_type="dataset"
                ),
                "r",
            ) as fp:
                shard_token_counts = json.load(fp)
            shard_token_counts = {k: v for k, v in shard_token_counts.items()}
            break
        except Exception as e:
            print(f"Error loading shard_token_counts.json: {e}")
            print("Retrying in 3 seconds...")
            sleep(3)
            continue
    return shard_token_counts


def get_dataset_config_names(repo_id, repo_type="dataset", retry=False):
    if not retry:
        return sorted(
            {
                p.split("/")[0]
                for p in list_repo_files(repo_id, repo_type=repo_type)
                if re.fullmatch(r"\d+", p.split("/")[0])
            }
        )
    else:
        while True:
            try:
                return sorted(
                    {
                        p.split("/")[0]
                        for p in list_repo_files(repo_id, repo_type=repo_type)
                        if re.fullmatch(r"\d+", p.split("/")[0])
                    }
                )
            except Exception as e:
                print(f"Error getting shards. Retrying...{e}")
                sleep(3)
                continue


def get_existing_shard_indices(repo_id, repo_type="dataset", retry=False):
    def extract_indices():
        shard_nums = set()
        for path in list_repo_files(repo_id, repo_type=repo_type):
            if path.startswith("data/train-") and path.endswith(".parquet"):
                # Example filename: data/train-00005-of-00010.parquet
                parts = path.split("/")[-1].split(
                    "-"
                )  # ['train', '00005', 'of', '00010.parquet']
                if len(parts) >= 3:
                    shard_str = parts[1]  # '00005'
                    if shard_str.isdigit():
                        shard_nums.add(str(int(shard_str)))
        return sorted(shard_nums)

    if not retry:
        return extract_indices()
    else:
        while True:
            try:
                return extract_indices()
            except Exception as e:
                print(f"Error getting existing shard indices. Retrying... {e}")
                sleep(3)


def get_all_raw_shards(RAW_TARGET_DATASET, TOTAL_NUM_BINS):
    config_names = []
    for bin_idx in range(TOTAL_NUM_BINS + 1):
        try:
            config_names += get_dataset_config_names(
                RAW_TARGET_DATASET.replace("_bin", f"_{bin_idx}")
            )
        except (DatasetNotFoundError, RepositoryNotFoundError):
            config_names += []
    return config_names


def get_all_target_shards(target_dataset):
    existing_shard_indices = []
    while True:
        try:
            existing_shard_indices += get_existing_shard_indices(target_dataset)
            break
        except (DatasetNotFoundError, RepositoryNotFoundError):
            existing_shard_indices = []
            break
        except Exception as e:
            print(f"Error getting existing shard indices. Retrying... {e}")
            sleep(3)
    return existing_shard_indices


def upload_shard(ds, i, total_shards, repo_id, repo_type="dataset"):
    while True:
        try:
            try:
                create_repo(repo_id=repo_id, repo_type=repo_type, exist_ok=True)
            except Exception:
                pass

            buffer = io.BytesIO()
            ds.to_parquet(buffer)
            buffer.seek(0)

            upload_file(
                path_or_fileobj=buffer,
                path_in_repo=f"data/train-{i:05d}-of-{total_shards:05d}.parquet",
                repo_id=repo_id,
                repo_type=repo_type,
            )
            break
        except Exception as e:
            print(f"Error uploading file {i}: {str(e)}")
            sleep(3)


def count_tokens(row, tokenizer):
    current_text = (
        f"Instruction: {row['instantiated_instruction']}\n\nAnswer: {row['answer']}"
    )
    token_count = len(tokenizer.encode(current_text)) - 1
    return {"synthetic_token_count": token_count}


def filter_to_be_token_for_token(dataset, shard_idx, source_dataset):  # noqa: C901
    shard_token_counts = get_shard_token_counts(source_dataset)
    actual_doc_count = 0
    prev_key = None

    def get_token_count(row):
        nonlocal prev_key, actual_doc_count
        key = (row["text"], row["token_count"])
        if key == prev_key:
            return 0
        else:
            prev_key = key
            actual_doc_count += 1
            return row["token_count"]

    dataset_token_count = sum(map(get_token_count, dataset))
    extra_tokens_from_docs_with_no_instructions = (
        shard_token_counts[shard_idx] - dataset_token_count
    )
    extra_tokens_from_docs_with_no_instructions_per_row = (
        extra_tokens_from_docs_with_no_instructions // actual_doc_count
    )
    extra_tokens_from_docs_with_no_instructions_per_row = max(
        extra_tokens_from_docs_with_no_instructions_per_row, 0
    )
    print(
        f"Extra tokens from docs with no instructions (calculation): {shard_token_counts[shard_idx]} - {dataset_token_count} = {extra_tokens_from_docs_with_no_instructions}"
    )
    print(
        f"Extra tokens from docs with no instructions per row (calculation): {extra_tokens_from_docs_with_no_instructions} // {actual_doc_count} = {extra_tokens_from_docs_with_no_instructions_per_row}"
    )

    def generator():
        buffer = []
        prev_key = None
        count = 0
        leftover = {
            "tokens": 0,
            "actual_token_count": 0,
            "synthetic_token_count": 0,
            "total_docs": 0,
            "skipped_docs": 0,
        }  # mutable container to track leftover tokens

        try:
            total = len(dataset)
        except TypeError:
            total = None

        for row in dataset:
            key = (row["text"], row["token_count"])

            if prev_key is None or key == prev_key:
                buffer.append(row)
            else:
                yield from trim_and_yield(
                    buffer,
                    leftover,
                    extra_tokens_per_row=extra_tokens_from_docs_with_no_instructions_per_row,
                )
                buffer = [row]

            prev_key = key
            count += 1
            if count % 10_000 == 0:
                if total:
                    print(f"Processed {count:,} / {total:,} rows")
                else:
                    print(f"Processed {count:,} rows...")

        if buffer:
            yield from trim_and_yield(
                buffer,
                leftover,
                extra_tokens_per_row=extra_tokens_from_docs_with_no_instructions_per_row,
            )
            print("Total Docs:", leftover["total_docs"])
            print("Skipped Docs:", leftover["skipped_docs"])
            print(
                f"Total synthetic tokens for {shard_idx}:",
                leftover["synthetic_token_count"],
            )
            print(
                f"Total actual tokens for {shard_idx}:", leftover["actual_token_count"]
            )
            assert (
                leftover["synthetic_token_count"] <= leftover["actual_token_count"]
            ), "Exceeded token-for-token"
            print(f"Processed {count:,} rows (final)")

    def trim_and_yield(group, leftover_tokens, extra_tokens_per_row=0):
        random.shuffle(group)
        max_total = (
            group[0]["token_count"] + extra_tokens_per_row + leftover_tokens["tokens"]
        )
        total = 0
        selected = []
        used_leftover = 0
        for row in group:
            if total + row["synthetic_token_count"] <= (
                group[0]["token_count"] + extra_tokens_per_row
            ):
                selected.append(row)
                total += row["synthetic_token_count"]
            elif (
                total + row["synthetic_token_count"] <= max_total and used_leftover <= 1
            ):
                used_leftover += 1
                selected.append(row)
                total += row["synthetic_token_count"]
            else:
                continue

        leftover_tokens["tokens"] = max(0, max_total - total)
        leftover_tokens["actual_token_count"] += (
            group[0]["token_count"] + extra_tokens_per_row
        )
        leftover_tokens["synthetic_token_count"] += total
        leftover_tokens["total_docs"] += 1
        if len(selected) == 0:
            leftover_tokens["skipped_docs"] += 1

        for i, row in enumerate(selected):
            if i > 0:
                row = row.copy()
                row["text"] = None
                row["token_count"] = 0
                yield row
            else:
                yield row

    return Dataset.from_generator(generator)


@click.option(
    "--dataset-name", "-d", type=str, required=True, help="The dataset to process."
)
def process_token_for_token(ctx, dataset_name):  # noqa: C901
    # Initialize
    from ....project import get_persistent_dir, reporter

    reporter.set(
        "data_tasks.process_token_for_token_datasets_cache",
        "data_tasks.process_token_for_token_datasets_cache",
    )
    tt_ds_cache_output_dir = get_persistent_dir(
        "process_token_for_token_datasets_cache",
        "data_tasks.process_token_for_token_datasets_cache",
    )
    print("CACHE DIR:", tt_ds_cache_output_dir)
    print("CPU Count:", os.cpu_count())
    tokenizer = AutoTokenizer.from_pretrained("meta-llama/Llama-3.2-1B-Instruct")

    # Initialize
    random.seed()
    os.makedirs("/scratch/users/ajayp/", exist_ok=True)
    compute_lock = FileLock(
        os.path.join("/scratch/users/ajayp/", "fi_token_for_token.flock")
    )

    # Source dataset_name
    source_dataset = dataset_name
    RAW_TARGET_DATASET = (
        source_dataset.replace("_actual", "_fineinstructions") + "_raw_bin"
    )
    target_dataset = source_dataset.replace("_actual", "_fineinstructions")
    all_shards = get_dataset_config_names(source_dataset, retry=True)
    TOTAL_NUM_SHARDS = max([int(s) for s in all_shards]) + 1
    BIN_SIZE = 500
    TOTAL_NUM_BINS = (TOTAL_NUM_SHARDS + 1) // BIN_SIZE
    shards_done = get_all_target_shards(target_dataset)
    shards_to_run = list(
        set(get_all_raw_shards(RAW_TARGET_DATASET, TOTAL_NUM_BINS)).difference(
            set(shards_done)
        )
    )
    print("Total Number of Bins:", TOTAL_NUM_BINS)
    print("Remaining shards:", shards_to_run)
    random.shuffle(shards_to_run)
    iterations_without_rechecking_shards = 0
    recheck_after_n_iterations = random.randint(3, 10)

    while True:
        if (
            len(shards_to_run) == 0
            or iterations_without_rechecking_shards > recheck_after_n_iterations
        ):
            iterations_without_rechecking_shards = 0
            recheck_after_n_iterations = random.randint(3, 10)
            sleep(30)
            shards_done = get_all_target_shards(target_dataset)
            shards_to_run = list(
                set(get_all_raw_shards(RAW_TARGET_DATASET, TOTAL_NUM_BINS)).difference(
                    set(shards_done)
                )
            )
            print("Remaining shards:", shards_to_run)
            random.shuffle(shards_to_run)
            continue
        iterations_without_rechecking_shards += 1
        shard_idx = shards_to_run.pop(0)
        bin_idx = int(shard_idx) // BIN_SIZE
        shard_lock = FileLock(
            os.path.join(
                tt_ds_cache_output_dir, f"fi_token_for_token_shard_{shard_idx}.flock"
            )
        )
        try:
            with shard_lock.acquire(blocking=False):
                print(f"Processing shard {shard_idx}....")
                # Load shard
                while True:
                    try:
                        dataset = load_dataset(
                            RAW_TARGET_DATASET.replace("_bin", f"_{bin_idx}"),
                            data_files=f"{shard_idx}/train-*.parquet",
                            split="train",
                            cache_dir=tt_ds_cache_output_dir,
                            num_proc=os.cpu_count(),
                        )
                        break
                    except Exception as e:
                        print(f"Exception getting  on shard_idx {shard_idx}: {str(e)}")
                        sleep(3)

                # Map the dataset
                print(
                    "Waiting for other job to take control all CPU cores for tokenizing..."
                )
                with compute_lock:  # This is a heavy operation, so ensure only one process can enter this per node
                    print("Begin: Using all CPU cores.")
                    print(f"Mapping {shard_idx} to count tokens...")
                    dataset = dataset.map(
                        partial(count_tokens, tokenizer=tokenizer),
                        num_proc=os.cpu_count(),
                    )
                print("Done: Using all CPU cores.")

                # Filter to be token_for_token
                print(f"Pulling into memory...{shard_idx}")
                d_in_mem = dataset.to_list()
                print(f"Done pulling into memory...{shard_idx}")
                dataset = filter_to_be_token_for_token(
                    d_in_mem, shard_idx, source_dataset
                )
                del d_in_mem
                gc.collect()

                # Remove the synthetic token_count
                # dataset.remove_columns(["synthetic_token_count"])

                # Upload
                upload_shard(
                    dataset,
                    int(shard_idx),
                    int(TOTAL_NUM_SHARDS),
                    target_dataset,
                    repo_type="dataset",
                )
                gc.collect()
                print(f"Uploaded shard: {shard_idx}")
        except Timeout:
            print("Picked shard a shard that is already being processed...retrying...")
            continue

    # Exit
    print("All uploads done.")
    sleep(99999)


__all__ = ["process_token_for_token"]
