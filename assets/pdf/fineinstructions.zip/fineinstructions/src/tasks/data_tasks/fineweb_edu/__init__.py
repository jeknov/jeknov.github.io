import json
import os
import random
import re
import tempfile
import threading
from random import shuffle
from time import sleep

import click
from datadreamer.utils.fs_utils import rm_dir
from datasets import load_dataset
from filelock import FileLock, Timeout
from huggingface_hub import HfApi, list_repo_files, snapshot_download
from huggingface_hub.errors import RepositoryNotFoundError
from transformers import AutoTokenizer

created_repo = False
upload_queue = []


def get_dataset_config_names(repo_id, repo_type="dataset", retry=False):
    if not retry:
        try:
            return sorted(
                {
                    p.split("/")[0]
                    for p in list_repo_files(repo_id, repo_type=repo_type)
                    if re.fullmatch(r"\d+", p.split("/")[0])
                }
            )
        except RepositoryNotFoundError:
            return []
    else:
        while True:
            try:
                return sorted(
                    {
                        p.split("/")[0]
                        for p in list_repo_files(repo_id, repo_type=repo_type)
                        if re.fullmatch(r"\d+", p.split("/")[0])
                    }
                )
            except RepositoryNotFoundError:
                return []
            except Exception as e:
                print(f"Error getting shards. Retrying...{e}")
                sleep(3)
                continue


def upload_queue_handler():
    print("Launching upload queue handler...")
    global upload_queue, created_repo
    while True:
        while len(upload_queue) == 0:
            sleep(1)
        try:
            parquet_path, dataset_key, shard_idx, shard_token_count = upload_queue.pop(
                0
            )
        except Exception:
            print("Exiting upload queue handler...")
            break
        while True:
            try:
                api = HfApi()
                if not created_repo:
                    api.create_repo(
                        repo_id=f"fineinstructions-pretraining/{dataset_key}_actual_all",
                        repo_type="dataset",
                        exist_ok=True,
                    )
                    created_repo = True
                api.upload_file(
                    path_or_fileobj=parquet_path,
                    path_in_repo=f"{shard_idx}/train-00000-of-00001.parquet",
                    repo_id=f"fineinstructions-pretraining/{dataset_key}_actual_all",
                    repo_type="dataset",
                )
                upload_file(
                    f"fineinstructions-pretraining/{dataset_key}_actual_all",
                    dataset_key,
                    json.dumps(shard_token_count, indent=2),
                    f"{shard_idx}/shard_token_count.json",
                )
                print(f"Uploaded: {shard_idx}")
                try:
                    rm_dir(os.path.dirname(parquet_path))
                    print(f"Cache directory deleted for shard {shard_idx}.")
                except Exception as e:
                    print(
                        f"Error deleting cache directory (don't worry we'll just ignore this) {os.path.dirname(parquet_path)}: {str(e)}"
                    )
                break
            except Exception as e:
                print(f"Error uploading {shard_idx}: {str(e)}")
                if "Too Many Requests" in str(e):
                    random_jitter_wait = int(random.uniform(15, 50))
                    print(f"Rate limit hit. Waiting {random_jitter_wait} seconds...")
                    sleep(random_jitter_wait)
                continue


def upload_file(dataset, dataset_key, contents, filename):
    global created_repo
    while True:
        try:
            api = HfApi()
            with tempfile.NamedTemporaryFile(delete=False) as tmp:
                tmp.write(contents.encode("utf-8"))
                tmp_path = tmp.name
            if not created_repo:
                api.create_repo(
                    repo_id=f"fineinstructions-pretraining/{dataset_key}_actual_all",
                    repo_type="dataset",
                    exist_ok=True,
                )
                created_repo = True
            api.upload_file(
                path_or_fileobj=tmp_path,
                path_in_repo=filename,
                repo_id=dataset,
                repo_type="dataset",
            )
            print(f"Uploaded {filename}")
            break
        except Exception as e:
            print(f"Error uploading file {filename}: {str(e)}")
            if "Too Many Requests" in str(e):
                random_jitter_wait = int(random.uniform(15, 50))
                print(f"Rate limit hit. Waiting {random_jitter_wait} seconds...")
                sleep(random_jitter_wait)


def process_dataset(
    dataset_name, dataset_key, fineweb_edu_ds_cache_output_dir, tokenizer
):
    global upload_queue
    upload_repo = f"fineinstructions-pretraining/{dataset_key}_actual_all"
    NUM_SHARDS = 5134
    dataset = load_dataset(dataset_name, split="train", num_proc=os.cpu_count())
    dataset = dataset.remove_columns(list(set(dataset.column_names) - {"text", "id"}))
    finished_shards = set(
        get_dataset_config_names(upload_repo, repo_type="dataset", retry=True)
    )
    all_shards = set([str(i) for i in range(NUM_SHARDS)])
    remaining_shards = list(all_shards - finished_shards)
    shuffle(remaining_shards)
    check_every_n_shards = 5
    iterations = 0
    print(f"Remaining shards: {len(remaining_shards)}")
    while True:
        if iterations % check_every_n_shards == 0 or len(remaining_shards) == 0:
            iterations = 0
            print(f"Processed {iterations} shards, checking remaining shards...")
            remaining_shards = list(
                all_shards
                - set(
                    get_dataset_config_names(
                        upload_repo, repo_type="dataset", retry=True
                    )
                )
            )
            shuffle(remaining_shards)
            print(f"Remaining shards: {len(remaining_shards)}")
            sleep(10)
            iterations += 1
            continue
        iterations += 1
        current_shard_idx = int(remaining_shards.pop())
        shard_lock = FileLock(
            os.path.join(
                fineweb_edu_ds_cache_output_dir,
                f"fi_process_{dataset_key}_shard_{current_shard_idx}.flock",
            )
        )
        try:
            print(f"Processing shard {current_shard_idx}...")
            with shard_lock.acquire(blocking=False):
                dataset_shard = dataset.shard(
                    num_shards=NUM_SHARDS, index=current_shard_idx
                )
                print("Mapping shard:", current_shard_idx)
                tokens_counted = dataset_shard.map(
                    lambda row: {"token_count": len(tokenizer.encode(row["text"])) - 1},
                    num_proc=os.cpu_count(),
                    cache_file_name=os.path.join(
                        fineweb_edu_ds_cache_output_dir,
                        str(current_shard_idx),
                        "token_counted.arrow",
                    ),
                )
                shard_token_count = sum(tokens_counted["token_count"])
                parquet_path = os.path.join(
                    fineweb_edu_ds_cache_output_dir,
                    str(current_shard_idx),
                    "train-00000-of-00001.parquet",
                )
                tokens_counted.to_parquet(parquet_path)
                del tokens_counted
                print("Done mapping shard:", current_shard_idx)

                # Add shard to upload queue
                upload_queue.append(
                    (parquet_path, dataset_key, current_shard_idx, shard_token_count)
                )
                print(f"Added shard {current_shard_idx} to upload queue.")
        except Timeout:
            print("Picked shard a shard that is already being processed...retrying...")
            continue


@click.option(
    "--dataset-name", "-d", type=str, required=True, help="The dataset to process."
)
def process_fineweb_edu(ctx, dataset_name):  # noqa: C901
    upload_thread = threading.Thread(target=upload_queue_handler)
    upload_thread.start()

    from ....project import get_persistent_dir, reporter

    reporter.set(
        "data_tasks.process_fineweb_edu_datasets_cache",
        "data_tasks.process_fineweb_edu_datasets_cache",
    )
    fineweb_edu_ds_cache_output_dir = get_persistent_dir(
        "process_fineweb_edu_datasets_cache",
        "data_tasks.process_fineweb_edu_datasets_cache",
    )

    # Process selected dataset
    tokenizer = AutoTokenizer.from_pretrained("meta-llama/Llama-3.2-1B-Instruct")
    print("Pre-snapshot download:")
    snapshot_download(
        repo_id=dataset_name, max_workers=os.cpu_count(), repo_type="dataset"
    )
    print("Done downloading snapshot.")
    while True:
        try:
            process_dataset(
                dataset_name=dataset_name,
                dataset_key=dataset_name.split("/")[-1].replace("-", "_"),
                fineweb_edu_ds_cache_output_dir=fineweb_edu_ds_cache_output_dir,
                tokenizer=tokenizer,
            )
        except Exception as e:
            print(f"Error processing dataset {dataset_name}: {str(e)}")
            import traceback

            traceback.print_exc()
            print("Retrying...")
            sleep(5)
            continue

    # Exit the upload queue
    upload_queue.append(None)
    while upload_thread.is_alive():
        print("Waiting for uploads...")
        sleep(1)
    print("All uploads done.")
    sleep(999999999)


__all__ = ["process_fineweb_edu"]
