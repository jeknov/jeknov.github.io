import hashlib
import os
import sys
from collections import Counter
from functools import partial

import click
from datadreamer import DataDreamer
from datadreamer.llms import VLLM, ParallelLLM
from datadreamer.steps import (
    HFDatasetDataSource,
    HFHubDataSource,
    Prompt,
    concat,
    zipped,
)

from ....datadreamer_ext.openrouter import OpenRouter
from .score_prompts import (
    create_judge_instruction_prompts,
    create_judge_match_prompts,
    create_judge_pair_2_prompts,
    create_judge_pair_prompts,
    final_train_format_mapper,
    make_batched_filter,
    make_code_filter,
    make_long_context_filter,
    make_math_filter,
    make_score_filter,
    make_template_match_judgement_filter,
    post_process_judge_instruction,
    post_process_judge_match,
    post_process_judge_pair,
)


@click.option(
    "--dataset-name", "-d", type=str, required=True, help="The dataset to process."
)
def find_gold_examples(ctx, dataset_name):  # noqa: C901
    sys.setrecursionlimit(9999)
    from ....project import get_persistent_dir, get_torch_devices, reporter

    # Flag to control whether to force re-run the pipeline without caching
    FORCE = False

    reporter.set(
        "doc_to_instruction.find_gold_examples_datadreamer_output",
        "find_gold_examples_datadreamer_output",
    )
    datadreamer_output_dir = get_persistent_dir(
        "find_gold_examples_datadreamer_output",
        "doc_to_instruction.find_gold_examples_datadreamer_output",
    )

    with DataDreamer(datadreamer_output_dir, log_date=True):
        # Get all templates
        templates_dataset = HFHubDataSource(
            "Get Templates Dataset",
            "fineinstructions/finetemplates",
            revision="7b7638debc46cc9ee6bec17ce9006e7838dbf10c",
            split="full",
        )
        templates_dataset_rows = templates_dataset.output.dataset

        # Get all expanded dataset
        expanded_dataset = HFHubDataSource(  # noqa: F841
            "Get expanded dataset",
            dataset_name,
            revision="8990d5f4066daccc90f2f64859100c99d111bc17",
            split="train",
            num_proc=10,
        )

        # Stratify by length
        GET_STRATS_LAZILY = False
        LIMIT = 0.50
        PER_STRAT_DICT = {
            1: 944632,
            2: 1055765,
            3: 1495625,
            4: 1196500,
            5: 340500,
            6: 36497,
            7: 10874,
            8: 330250,
        }
        LIMIT = 1.0
        PER_STRAT_DICT = {
            1: 10000,
            2: 10000,
            3: 10000,
            4: 50000,
            5: 50000,
            6: 30000,
            7: 30000,
            8: 50000,
        }
        UPSAMPLE_STRAT = {1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 1}
        max_multiplier = {
            k: max(min(int(1.000 / LIMIT), v), 1) for k, v in UPSAMPLE_STRAT.items()
        }
        PER_STRAT_DICT = {
            k: int(v * LIMIT * max_multiplier[k]) for k, v in PER_STRAT_DICT.items()
        }
        UPSAMPLE_STRAT = {
            k: v
            if v == 1 or max_multiplier[k] == 1
            else max(int(v / max_multiplier[k]), 1)
            for k, v in UPSAMPLE_STRAT.items()
        }
        print("Limit:", LIMIT)
        print("Max Multiplier:", max_multiplier)
        print("UPSAMPLE_STRAT:", UPSAMPLE_STRAT)
        PER_STRAT = max(PER_STRAT_DICT.values())

        seen_template_ids = Counter()
        stratification_6 = expanded_dataset.map(
            make_code_filter(
                score=25, min=0, max=2000, seen_template_ids=seen_template_ids
            ),
            lazy=GET_STRATS_LAZILY,
            batched=True,
            batch_size=400000,
            total_num_rows=len(expanded_dataset.output),
            name="Stratification_6",
        ).take(PER_STRAT_DICT[6], lazy=False)
        # stratification_6 = HFDatasetDataSource(
        #     "Stratification_6_direct",
        #     os.path.realpath(
        #         os.path.join(datadreamer_output_dir, "stratification_6", "_dataset")
        #     ),
        # ).take(PER_STRAT_DICT[6], lazy=False)
        seen_template_ids.update(
            Counter(stratification_6.output.dataset["template_id"])
        )
        print("Strat 6", len(stratification_6.output))
        stratification_7 = expanded_dataset.map(
            make_math_filter(
                score=6, min=0, max=2000, seen_template_ids=seen_template_ids
            ),
            lazy=GET_STRATS_LAZILY,
            batched=True,
            batch_size=400000,
            total_num_rows=len(expanded_dataset.output),
            name="Stratification_7",
        ).take(PER_STRAT_DICT[7], lazy=False)
        # stratification_7 = HFDatasetDataSource(
        #     "Stratification_7_direct",
        #     os.path.realpath(
        #         os.path.join(datadreamer_output_dir, "stratification_7", "_dataset")
        #     ),
        # ).take(PER_STRAT_DICT[7], lazy=False)
        seen_template_ids.update(
            Counter(stratification_7.output.dataset["template_id"])
        )
        print("Strat 7", len(stratification_7.output))
        stratification_8 = expanded_dataset.map(
            make_long_context_filter(
                score_len=150,
                score_prop=0.30,
                max=6000,
                seen_template_ids=seen_template_ids,
            ),
            lazy=GET_STRATS_LAZILY,
            batched=True,
            batch_size=400000,
            total_num_rows=len(expanded_dataset.output),
            name="Stratification_8",
        ).take(PER_STRAT_DICT[8], lazy=False)
        # stratification_8 = HFDatasetDataSource(
        #     "Stratification_8_direct",
        #     os.path.realpath(
        #         os.path.join(datadreamer_output_dir, "stratification_8", "_dataset")
        #     ),
        #     force=True,
        # ).take(PER_STRAT_DICT[8], lazy=False)
        seen_template_ids.update(
            Counter(stratification_8.output.dataset["template_id"])
        )
        print("Strat 8", len(stratification_8.output))
        stratification_1 = expanded_dataset.map(
            make_batched_filter(0, 300),
            lazy=True,
            batched=True,
            batch_size=400000,
            total_num_rows=len(expanded_dataset.output),
            name="Stratification_1",
        ).take(PER_STRAT_DICT[1], lazy=False)
        # stratification_1 = HFDatasetDataSource(
        #     "Stratification_1_direct",
        #     os.path.realpath(
        #         os.path.join(
        #             datadreamer_output_dir, "stratification_1-take", "_dataset"
        #         )
        #     ),
        # ).take(PER_STRAT_DICT[1], lazy=False)
        seen_template_ids.update(
            Counter(stratification_1.output.dataset["template_id"])
        )
        print("Strat 1", len(stratification_1.output))
        stratification_2 = expanded_dataset.map(
            make_batched_filter(300, 600, seen_template_ids=seen_template_ids),
            lazy=True,
            batched=True,
            batch_size=400000,
            total_num_rows=len(expanded_dataset.output),
            name="Stratification_2",
        ).take(PER_STRAT_DICT[2], lazy=False)
        # stratification_2 = HFDatasetDataSource(
        #     "Stratification_2_direct",
        #     os.path.realpath(
        #         os.path.join(
        #             datadreamer_output_dir, "stratification_2-take", "_dataset"
        #         )
        #     ),
        # ).take(PER_STRAT_DICT[2], lazy=False)
        seen_template_ids.update(
            Counter(stratification_2.output.dataset["template_id"])
        )
        print("Strat 2", len(stratification_2.output))
        stratification_3 = expanded_dataset.map(
            make_batched_filter(600, 900, seen_template_ids=seen_template_ids),
            lazy=GET_STRATS_LAZILY,
            batched=True,
            batch_size=400000,
            total_num_rows=len(expanded_dataset.output),
            name="Stratification_3",
        ).take(PER_STRAT_DICT[3], lazy=False)
        # stratification_3 = HFDatasetDataSource(
        #     "Stratification_3_direct",
        #     os.path.realpath(
        #         os.path.join(datadreamer_output_dir, "stratification_3", "_dataset")
        #     ),
        # ).take(PER_STRAT_DICT[3], lazy=False)
        seen_template_ids.update(
            Counter(stratification_3.output.dataset["template_id"])
        )
        print("Strat 3", len(stratification_3.output))
        stratification_4 = expanded_dataset.map(
            make_batched_filter(900, 1100, seen_template_ids=seen_template_ids),
            lazy=GET_STRATS_LAZILY,
            batched=True,
            batch_size=400000,
            total_num_rows=len(expanded_dataset.output),
            save_num_proc=64,
            name="Stratification_4",
        ).take(PER_STRAT_DICT[4], lazy=False)
        # stratification_4 = HFDatasetDataSource(
        #     "Stratification_4_direct",
        #     os.path.realpath(
        #         os.path.join(datadreamer_output_dir, "stratification_4", "_dataset")
        #     ),
        # ).take(PER_STRAT_DICT[4], lazy=False)
        seen_template_ids.update(
            Counter(stratification_4.output.dataset["template_id"])
        )
        print("Strat 4", len(stratification_4.output))
        stratification_5 = expanded_dataset.map(
            make_batched_filter(1100, 2000, seen_template_ids=seen_template_ids),
            lazy=GET_STRATS_LAZILY,
            batched=True,
            batch_size=400000,
            total_num_rows=len(expanded_dataset.output),
            save_num_proc=64,
            name="Stratification_5",
        ).take(PER_STRAT_DICT[5], lazy=False)
        # stratification_5 = HFDatasetDataSource(
        #     "Stratification_5_direct",
        #     os.path.realpath(
        #         os.path.join(datadreamer_output_dir, "stratification_5", "_dataset")
        #     ),
        # ).take(PER_STRAT_DICT[5], lazy=False)
        seen_template_ids.update(
            Counter(stratification_5.output.dataset["template_id"])
        )
        print("Strat 5", len(stratification_5.output))

        llm_70 = ParallelLLM(
            *(
                [
                    OpenRouter(  # noqa: F841
                        model_name="meta-llama/llama-3.3-70b-instruct",
                        api_key=os.environ["OPENROUTER_API_KEY"],
                        base_url="https://openrouter.ai/api/v1",
                        cache_folder_path=os.path.join(
                            datadreamer_output_dir, ".cache"
                        ),
                    )
                    for i in range(64)
                ]
            )
        )
        os.environ["VLLM_DO_NOT_TRACK"] = "1"
        os.environ["DO_NOT_TRACK"] = "1"
        os.environ["VLLM_NO_USAGE_STATS"] = "1"
        os.environ["HF_HUB_DOWNLOAD_TIMEOUT"] = "120"
        os.environ["TORCHINDUCTOR_CACHE_DIR"] = os.path.realpath(
            os.path.join(datadreamer_output_dir, ".inductorcache")
        )
        if len(get_torch_devices()) > 0:
            local_llm_70 = VLLM(  # noqa: F841
                cache_folder_path=os.path.join(datadreamer_output_dir, ".cache"),
                model_name="RedHatAI/Llama-3.3-70B-Instruct-quantized.w8a8",
                device=get_torch_devices(),
                tensor_parallel_size=len(get_torch_devices()),
                disable_log_stats=True,
                enable_chunked_prefill=False,
                enable_prefix_caching=True,
                enforce_eager=False,
                disable_custom_all_reduce=False,
                gpu_memory_utilization=0.90,
                max_model_len=11500,
                max_num_seqs=64,
                max_num_batched_tokens=11504,
            )
        # Get highest quality in each stratification
        final_strats = []
        for strat_idx, strat in [
            (8, stratification_8),
            (5, stratification_5),
            (4, stratification_4),
            (7, stratification_7),
            (6, stratification_6),
            (1, stratification_1),
            (2, stratification_2),
            (3, stratification_3),
        ]:
            done_path = os.path.realpath(
                os.path.join(
                    datadreamer_output_dir,
                    f"add-strat_idx-and-upsample-{UPSAMPLE_STRAT[strat_idx]}-{strat_idx}-take",
                    "_dataset",
                )
            )
            if os.path.isdir(done_path):
                final_take = HFDatasetDataSource(
                    f"Final_Filtered_Strat_Take_{strat_idx}_direct", done_path
                )
            else:
                # Judge instruction
                judge_instruction_prompts = strat.map(
                    create_judge_instruction_prompts,
                    lazy=False,
                    name=f"Judge Instruction Prompt (({strat_idx}))",
                    force=FORCE,
                )
                judge_instruction_scores = Prompt(
                    name=f"Judge Instructions (({strat_idx}))",
                    inputs={"prompts": judge_instruction_prompts.output["prompt"]},
                    args={
                        "llm": llm_70,
                        "batch_size": 120,
                        "temperature": 1.0,
                        "top_p": 0.0,
                        "max_new_tokens": 5000,
                        "post_process": post_process_judge_instruction,
                        "lazy": False,
                    },
                    outputs={"generations": "score"},
                    force=FORCE,
                ).select_columns(["score"])

                # Filter
                strat = zipped(
                    strat,
                    judge_instruction_scores,
                    lazy=True,
                    name=f"Combine Strat (({strat_idx})) + Instruction Scores",
                )
                strat = strat.filter(
                    make_score_filter(
                        28, instruction_score=20, pair_score=15, pair2_score=2
                    ),
                    lazy=True,
                    total_num_rows=PER_STRAT,
                ).rename_column("score", "instruction_score", lazy=False)

                # Judge pair
                judge_pair_prompts = strat.map(
                    create_judge_pair_prompts,
                    lazy=False,
                    name=f"Judge Pair Prompt (({strat_idx}))",
                    force=FORCE,
                )
                judge_pair_scores = Prompt(
                    name=f"Judge Pairs (({strat_idx}))",
                    inputs={"prompts": judge_pair_prompts.output["prompt"]},
                    args={
                        "llm": llm_70,
                        "batch_size": 120,
                        "temperature": 1.0,
                        "top_p": 0.0,
                        "max_new_tokens": 5000,
                        "post_process": post_process_judge_pair,
                        "lazy": False,
                    },
                    outputs={"generations": "score"},
                    force=FORCE,
                ).select_columns(["score"])

                # Filter
                strat = zipped(
                    strat,
                    judge_pair_scores,
                    lazy=True,
                    name=f"Combine Strat (({strat_idx})) + Pair Scores",
                )
                strat = strat.filter(
                    make_score_filter(
                        23, instruction_score=20, pair_score=15, pair2_score=2
                    ),
                    lazy=False,
                    total_num_rows=PER_STRAT,
                ).rename_column("score", "pair_score", lazy=False)

                # Judge pair 2
                judge_pair_prompts = strat.map(
                    create_judge_pair_2_prompts,
                    lazy=False,
                    name=f"Judge Pair 2 Prompt (({strat_idx}))",
                    force=FORCE,
                )
                judge_pair_scores = Prompt(
                    name=f"Judge Pairs (({strat_idx})) 2",
                    inputs={"prompts": judge_pair_prompts.output["prompt"]},
                    args={
                        "llm": llm_70,
                        "batch_size": 120,
                        "temperature": 1.0,
                        "top_p": 0.0,
                        "max_new_tokens": 5000,
                        "post_process": post_process_judge_pair,
                        "lazy": False,
                    },
                    outputs={"generations": "score"},
                    force=FORCE,
                ).select_columns(["score"])

                # Filter
                strat = zipped(
                    strat,
                    judge_pair_scores,
                    lazy=True,
                    name=f"Combine Strat (({strat_idx})) + Pair Scores 2",
                )
                strat = strat.filter(
                    make_score_filter(
                        3, instruction_score=20, pair_score=15, pair2_score=2
                    ),
                    lazy=False,
                    total_num_rows=PER_STRAT,
                ).rename_column("score", "pair2_score", lazy=False)

                # Judge Match
                judge_match_prompts = strat.map(
                    partial(
                        create_judge_match_prompts,
                        templates_dataset_rows=templates_dataset_rows["template"],
                    ),
                    lazy=False,
                    name=f"Judge Template Match Prompt (({strat_idx}))",
                    force=FORCE,
                )
                match_judgements = Prompt(
                    name=f"Judge Template Matches (({strat_idx}))",
                    inputs={"prompts": judge_match_prompts.output["prompt"]},
                    args={
                        "llm": llm_70,
                        "batch_size": 120,
                        "temperature": 1.0,
                        "top_p": 0.0,
                        "max_new_tokens": 5000,
                        "post_process": post_process_judge_match,
                        "lazy": False,
                    },
                    outputs={"generations": "template_match_judgement"},
                    force=FORCE,
                ).select_columns(["template_match_judgement"])

                strat = zipped(
                    strat,
                    match_judgements,
                    lazy=False,
                    name=f"Combine Strat (({strat_idx})) + Match Judgements",
                )

                strat = strat.filter(
                    make_template_match_judgement_filter(
                        instruction_score=20, pair_score=15, pair2_score=2
                    ),
                    lazy=False,
                    total_num_rows=PER_STRAT,
                )

                # Add strat index and upsample
                strat = strat.map(
                    lambda batch, indices, strat_idx=strat_idx: {
                        "strat": [strat_idx] * UPSAMPLE_STRAT[strat_idx],
                        "uid": [
                            hashlib.blake2b(
                                str((batch["text"], batch["template_id"])).encode()
                            ).hexdigest()
                        ]
                        * UPSAMPLE_STRAT[strat_idx],
                        **{
                            key: batch[key] * UPSAMPLE_STRAT[strat_idx]
                            for key in batch
                            if key not in {"uid", "strat"}
                        },
                    },
                    batched=True,
                    batch_size=1,
                    with_indices=True,
                    lazy=False,
                    total_num_rows=PER_STRAT,
                    name=f"Add strat_idx and upsample (×{UPSAMPLE_STRAT[strat_idx]}) (({strat_idx}))",
                    force=FORCE,
                )

                final_take = strat.take(50000, lazy=False)
            print("Final Take", strat_idx, len(final_take.output))
            final_strats.append(final_take)

        # Convert to training format
        all_strats = concat(*final_strats, name="Combine all strats").shuffle(
            lazy=False, seed=42
        )
        all_strats = all_strats.map(
            partial(
                final_train_format_mapper,
                templates_dataset_rows=templates_dataset_rows["template"],
            ),
            lazy=False,
            name="Final Map",
            force=FORCE,
            remove_columns=["instantiated_instruction", "text"],
        )
        all_strats = zipped(
            *[
                all_strats.select_columns([cn], lazy=True)
                for cn in [
                    "strat",
                    "document",
                    "instruction",
                    "answer",
                    "template",
                    "shortened_instruction",
                    "shortened_answer",
                    "token_count",
                    "synthetic_token_count",
                    "instruction_score",
                    "pair_score",
                    "pair2_score",
                    "template_match_judgement",
                    "template_id",
                    "uid",
                ]
            ],
            name="Combine all strats and rearrange columns",
        )

        all_strats.publish_to_hf_hub(
            dataset_name.replace(
                "fineinstructions_all", "fineinstructions_scored"
            ).replace("fineinstructions_1T", "fineinstructions_scored"),
            split="full",
        )
        from time import sleep

        sleep(99999999)


__all__ = ["find_gold_examples"]
