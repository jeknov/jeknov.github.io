import concurrent.futures
import json
import os
import re
from collections import Counter
from functools import lru_cache
from random import Random

from ...doc_to_instruction.instantiation_subsample.heuristic_scores import (
    compute_code_score,
    compute_math_score,
)
from ...doc_to_instruction.instantiation_subsample.instantiation_prompts import shorten

JUDGE_INSTRUCTION_PROMPT = """
Here is an instruction for an LLM. Can you please score it on a scale of 1-5 on different dimensions for how useful this would be for instruction-tuning an LLM?

Here are some dimensions to not consider at all in your scoring:
- Factuality: These instructions are grounded in source documents and do not need to be evaluated for factuality.
- Verbosity: Extra verbose is fine.
- Bad or Messy Grammar, Typos, Fluency, Style: As long as the instruction are reasonably understandable, we don't care at all about the style or presentation.


Here are dimensions to rate it on (5 points each, total of 30):
- Task (5 points): Identify the broader category of task that is being asked (with this being a specific instance of that broader category of task). Consider what a successful output might look like for a different instance of that broader task. Come up with an example of instances of this broader category of task that might be challenging and not trivial as well as ones that are not challenging. Finally, consider whether this specific instance is a good instance representative of the complexity of the broader task category.
- Specificity (5 points): The instruction is specified enough to be answered without vagueness of what is being asked, asking for subjective opinions is totally okay, but the question should not contain unresolvable or highly vague anaphors or references or lack significant context.
- Triviality (5 points): The instruction is not a "degenerate example" of the task that is trivial or too easy. Degenerate cases of tasks often look like cases where nothing challenging needs to be done to perform the task ("Convert X to format Y" where X is already in the format Y or "Give me a summary of X" where X is already a reasonably short summary). 
- Answer Provided (5 points): The instruction text should absolutely not provide an answer after the task or indirectly/mistakenly/subtly hint to an answer or provide the answer anywhere in the instruction text.
- Repetition (5 points): The instruction should not repeat the same content over and over again or contain high amounts of repetition. If there is a lot of repetition or overlap rate near zero.
- Realistic Context or Document (5 points): If there is a context or document or some text content paired with the instruction inside the instruction text, it should appear highly realistic and not be trivial to solve the task on the text. If there is no context or document paired with the instruction, rate this a full 5 points.

Please explain your answer for each of the dimensions in depth. Then, only after the explanations, as the return format, place your total score out of 30 after "Total Score:" at the very end.

<<<Instruction:
{instruction}
>>>
""".strip()


def create_judge_instruction_prompts(row):
    return {
        "prompt": JUDGE_INSTRUCTION_PROMPT.format(
            instruction=row["instantiated_instruction"]
        )
    }


JUDGE_PAIR_PROMPT = """
Here is an instruction and answer pair for an LLM. Can you please score it on a scale of 1-5 on different dimensions for how useful this would be for instruction-tuning an LLM?

Here are some dimensions to not consider at all in your scoring:
- Factuality: The pair is grounded in source documents and do not need to be evaluated for factuality.
- Verbosity: Extra verbose is fine (if the task is not such that it requires precise length, terseness, or some exact content)
- Bad or Messy Grammar, Typos, Fluency, Style: As long as the instruction and answer is reasonably understandable, we don't care at all about the style or presentation.


Here are dimensions to rate it on (5 points each, total of 25):
- Task (5 points): Identify the broader category of task that is being asked (with this being a specific instance of that broader category of task). Consider what a successful output might look like for a different instance of that broader task. Come up with an example of instances of this broader category of task that might be challenging and not trivial as ones that are not challenging. Finally, consider whether this specific instance is a good input and output pair representative of the complexity of the broader task category.
- Completeness (5 points): The answer fully attends to every single component of the instruction and does not leave anything unaddressed. Extra verbosity is fine as long as the instruction is fully addressed (if the task is not such that it requires precise length, terseness, or some exact content).
- Triviality (5 points): The input and output pair is not a "degenerate example" of the task that is trivial or too easy. Degenerate cases of tasks often look like cases where nothing challenging needs to be done to perform the task ("Convert X to format Y" where X is already in the format Y or "Give me a summary of X" where X is already a reasonably short summary). 
- Answer Provided (5 points): The instruction text should absolutely not provide an answer after the task or indirectly/mistakenly/subtly hint to an answer or provide the answer anywhere in the instruction text.
- Repetition and Overlap (5 points): There should almost zero significant repetition (phrases, sentences, information or content) between the instruction and the answer. If there is a lot of repetition or overlap rate near zero.

Please explain your answer for each of the dimensions in depth. Then, only after the explanations, as the return format, place your total score out of 25 after "Total Score:" at the very end.

<<<Instruction:
{instruction}
>>>

<<<Answer:
{answer}
>>>
""".strip()


def create_judge_pair_prompts(row):
    return {
        "prompt": JUDGE_PAIR_PROMPT.format(
            instruction=row["instantiated_instruction"], answer=row["answer"]
        )
    }


JUDGE_PAIR_PROMPT_2 = """
Here is an instruction and answer pair for an LLM. Can you please score it on a scale of 1-3?


Score 1: The answer is not correct at all and does not follow the instructions of the task.
Score 2: The answer is partially correct and somewhat follows the task, but is far from a perfect example of the task.
Score 3: The answer ia near perfect example of performing the task in the instruction.


Please explain your answer in depth. Then, only after the explanation, as the return format, place your total score out of 3 after "Total Score:" at the very end.

<<<Instruction:
{instruction}
>>>

<<<Answer:
{answer}
>>>
""".strip()


def create_judge_pair_2_prompts(row):
    return {
        "prompt": JUDGE_PAIR_PROMPT_2.format(
            instruction=row["instantiated_instruction"], answer=row["answer"]
        )
    }


JUDGE_MATCH_PROMPT = """
Given a instruction-tuning prompt template (that is representative of a real world query or task a user might ask an LLM) and a document, please judge whether the document has enough information to both instantiate both the query template and instantiate a grounded response to create a high-quality training example grounded in the document.

Requirements:
1. Both Instruction and Response: The document must have enough information to be able to instantiate the template and provide a response (i.e. create both sides of the query-response pair for the purposes of creating a high-quality training example).
2. Every <fi></fi> Variable: Document must have enough information to instantiate every single variable (<fi></fi>) in the query template.
3. Enough Information: Document must have enough information to instantiate a strong grounded response.
4. Context/Document/Text: If there is a context or document or some text content paired with the instruction inside the instruction text (a summary, quote, excerpt, a kind of document), both an example of that content and an example of a response should directly appear in the document such that a grounded instantiation can be created. For example, for a template that says "Summarize the article below: <fi>article</fi>", the document must have a long article *and* a summary of that article to be able to create a grounded instantiation of both sides of the instruction.


Return Format: Write a short explanation of your judgement and why the document does or does not meet the requirements, then return your judgement as "yes" or "no" after "Answer: ". Return nothing else at all in your output.

Instruction-Tuning Prompt Template: {template}

Document: {document}
""".strip()


def create_judge_match_prompts(row, templates_dataset_rows):
    return {
        "prompt": JUDGE_MATCH_PROMPT.format(
            document=row["text"], template=templates_dataset_rows[row["template_id"]]
        )
    }


def post_process_judge_instruction(x):
    divider = "Total Score:"
    score_string = (x.rsplit(divider, 1)[1] if divider in x else x).strip()
    match = re.search(r"\d+", score_string)
    return int(match.group()) if match else 0


def post_process_judge_pair(x):
    divider = "Total Score:"
    score_string = (x.rsplit(divider, 1)[1] if divider in x else x).strip()
    match = re.search(r"\d+", score_string)
    return int(match.group()) if match else 0


def post_process_judge_match(x):
    divider = "Answer:"
    return "yes" in ((x.rsplit(divider, 1)[1] if divider in x else x).strip().lower())


def final_train_format_mapper(row, templates_dataset_rows):
    return {
        "template": templates_dataset_rows[row["template_id"]],
        "instruction": row["instantiated_instruction"],
        "document": row["text"],
        "shortened_instruction": shorten(row["text"], row["instantiated_instruction"]),
        "shortened_answer": shorten(row["text"], row["answer"]),
    }


def make_score_filter(score, instruction_score, pair_score, pair2_score):
    r = Random(42)

    def score_filter(row):
        keep = (
            "instruction_score" in row and row["instruction_score"] <= instruction_score
        ) or ("instruction_score" not in row and r.random() < 0.6)
        if "pair_score" in row and row["pair_score"] > pair_score:
            keep = False
        if "pair2_score" in row and row["pair2_score"] > pair2_score:
            keep = False
        return row["score"] >= score or keep

    return score_filter


def make_template_match_judgement_filter(instruction_score, pair_score, pair2_score):
    def judgement_filter(row):
        return (
            row["template_match_judgement"]
            and row["instruction_score"] > instruction_score
            and row["pair_score"] > pair_score
            and row["pair2_score"] > pair2_score
        ) or (
            not row["template_match_judgement"]
            and row["instruction_score"] <= instruction_score
            and row["pair_score"] <= pair_score
            and row["pair2_score"] <= pair2_score
        )

    return judgement_filter


def uniqify_by_seen_template_ids(
    batch,
    seen_template_ids,
    current_seen_template_ids,
    max_previously_seen=0,
    max_currently_seen=3,
):
    """Filter the batch to ensure that we do not have too many previously seen template ID too many times and also don't keep too many of the same template ID even if they are not previously seen."""
    filtered = []
    for i in range(len(batch["text"])):
        template_id = batch["template_id"][i]
        if template_id in seen_template_ids:
            if seen_template_ids[template_id] < max_previously_seen:
                filtered.append(i)
                current_seen_template_ids[template_id] += 1
        else:
            if current_seen_template_ids[template_id] < max_currently_seen:
                filtered.append(i)
                current_seen_template_ids[template_id] += 1
    filtered_batch = {k: [v[i] for i in filtered] for k, v in batch.items()}
    return filtered_batch


def make_batched_filter(min=1, max=300, seen_template_ids=None):
    current_seen_template_ids = Counter()
    seen_template_ids = seen_template_ids or Counter()
    r = Random(42)

    def batched_filter(batch):
        prev = None
        for i in range(len(batch["text"])):
            if batch["text"][i] is None:
                if isinstance(prev, str):
                    batch["text"][i] = prev
            else:
                prev = batch["text"][i]

        keep = [
            text is not None
            and len(text) <= 15000
            and inst is not None
            and min <= len(inst) <= max
            for text, inst in zip(batch["text"], batch["instantiated_instruction"])
        ]

        filtered = {
            k: [v[i] for i in range(len(v)) if keep[i]] for k, v in batch.items()
        }

        if filtered:
            indices = list(range(len(next(iter(filtered.values())))))
            r.seed(json.dumps(batch["instantiated_instruction"]))
            r.shuffle(indices)
            filtered = {k: [v[i] for i in indices] for k, v in filtered.items()}

        return uniqify_by_seen_template_ids(
            batch=filtered,
            seen_template_ids=seen_template_ids,
            current_seen_template_ids=current_seen_template_ids,
        )

    return batched_filter


n_cpus = os.cpu_count()


def compute_scores_parallel(answers, scorer):
    return _compute_scores_parallel_cached(json.dumps(answers), scorer)


@lru_cache(maxsize=3)
def _compute_scores_parallel_cached(serialized_answers, scorer):
    answers = json.loads(serialized_answers)
    with concurrent.futures.ProcessPoolExecutor(max_workers=n_cpus) as executor:
        scores = list(executor.map(scorer, answers))
    return scores


def make_math_filter(score=10, min=1, max=300, seen_template_ids=None):
    current_seen_template_ids = Counter()
    seen_template_ids = seen_template_ids or Counter()
    base_filter = make_batched_filter(min=min, max=max)

    def batched_filter(batch):
        filtered = base_filter(batch)
        answers = filtered["answer"]

        scores = compute_scores_parallel(answers, compute_math_score)
        filtered_indices = [i for i, s in enumerate(scores) if s >= score]

        return uniqify_by_seen_template_ids(
            batch={k: [v[i] for i in filtered_indices] for k, v in filtered.items()},
            seen_template_ids=seen_template_ids,
            current_seen_template_ids=current_seen_template_ids,
        )

    return batched_filter


def make_code_filter(score=10, min=1, max=300, seen_template_ids=None):
    current_seen_template_ids = Counter()
    seen_template_ids = seen_template_ids or Counter()
    base_filter = make_batched_filter(min=min, max=max)

    def batched_filter(batch):
        filtered = base_filter(batch)
        answers = filtered["answer"]

        scores = compute_scores_parallel(answers, compute_code_score)
        filtered_indices = [i for i, s in enumerate(scores) if s >= score]

        return uniqify_by_seen_template_ids(
            batch={k: [v[i] for i in filtered_indices] for k, v in filtered.items()},
            seen_template_ids=seen_template_ids,
            current_seen_template_ids=current_seen_template_ids,
        )

    return batched_filter


def compute_overlap_score(pair):
    import pylcs

    instruction, document = pair
    match = pylcs.lcs2(instruction, document)
    return match, match / len(instruction)


def make_long_context_filter(
    score_len=500, score_prop=0.45, max=300, seen_template_ids=None
):
    current_seen_template_ids = Counter()
    seen_template_ids = seen_template_ids or Counter()
    base_filter = make_batched_filter(min=score_len, max=max)

    def batched_filter(batch):
        filtered = base_filter(batch)
        inputs = list(zip(filtered["instantiated_instruction"], filtered["text"]))

        scores = compute_scores_parallel(inputs, compute_overlap_score)
        filtered_indices = [
            i for i, s in enumerate(scores) if s[0] >= score_len and s[1] >= score_prop
        ]

        return uniqify_by_seen_template_ids(
            batch={k: [v[i] for i in filtered_indices] for k, v in filtered.items()},
            seen_template_ids=seen_template_ids,
            current_seen_template_ids=current_seen_template_ids,
        )

    return batched_filter
