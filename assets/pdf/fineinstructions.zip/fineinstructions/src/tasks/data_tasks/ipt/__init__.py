import gc
import json
import os
import tempfile
from functools import partial
from time import sleep

from datasets import load_dataset
from huggingface_hub import HfApi
from transformers import AutoTokenizer


def upload_file(dataset, contents, filename):
    while True:
        try:
            api = HfApi()
            with tempfile.NamedTemporaryFile(delete=False) as tmp:
                tmp.write(contents.encode("utf-8"))
                tmp_path = tmp.name
            api.upload_file(
                path_or_fileobj=tmp_path,
                path_in_repo=filename,
                repo_id=dataset,
                repo_type="dataset",
            )
            print(f"Uploaded {filename}")
            break
        except Exception as e:
            print(f"Error uploading file {filename}: {str(e)}")


def process_raw_row_actual(row, tokenizer):
    text = row["text"][0]
    try:
        rows = json.loads(text)
    except json.decoder.JSONDecodeError:
        return {"text": [], "token_count": []}
    texts = []
    token_counts = []
    for r in rows:
        current_text = r["context"].strip()
        current_token_count = len(tokenizer.encode(current_text)) - 1
        texts.append(current_text)
        token_counts.append(current_token_count)
    return {"text": texts, "token_count": token_counts}


def process_raw_row_synthetic(row, tokenizer):
    text = row["text"][0]
    try:
        rows = json.loads(text)
    except json.decoder.JSONDecodeError:
        return {"text": [], "token_count": []}
    texts = []
    token_counts = []
    for r in rows:
        current_text = (
            r["context"].strip()
            + "\n\n"
            + "\n\n".join(
                [f"Question: {qa['Q']} Answer: {qa['A']}" for qa in r["QA_list"]]
            )
        )
        current_token_count = len(tokenizer.encode(current_text)) - 1
        texts.append(current_text)
        token_counts.append(current_token_count)
    return {"text": texts, "token_count": token_counts}


def process_ipt(ctx):  # noqa: C901
    # Initialize
    from ....project import get_persistent_dir, reporter

    reporter.set(
        "data_tasks.process_ipt_datasets_cache", "data_tasks.process_ipt_datasets_cache"
    )
    ipt_ds_cache_output_dir = [
        os.path.join(
            get_persistent_dir(
                "process_ipt_datasets_cache", "data_tasks.process_ipt_datasets_cache"
            ),
            str(shard_idx),
        )
        for shard_idx in range(8)
    ]
    print("CACHE DIRS:", ipt_ds_cache_output_dir)
    tokenizer = AutoTokenizer.from_pretrained("meta-llama/Llama-3.2-1B-Instruct")

    # Pre-download everything
    BAD_FILES = [(1, 4), (1, 517), (2, 608), (6, 972)]
    for shard_idx in range(8):
        print(f"Predownloading {shard_idx}")
        dataset = load_dataset(
            "instruction-pretrain/general-instruction-augmented-corpora",
            data_files={
                "train": [
                    f"part-{shard_idx}/shard/{i:05}.txt"
                    for i in range(1000)
                    if (shard_idx, i) not in BAD_FILES
                ]
            },
            split="train",
            cache_dir=ipt_ds_cache_output_dir[shard_idx],
            num_proc=64,
        )
        del dataset
        gc.collect()
        print(f"Done downloading {shard_idx}")

    # Process shards
    for dataset_key in ["synthetic", "actual"]:
        shard_counts = {}
        cumulative_shard_counts = {}
        total_count = 0
        for shard_idx in range(8):
            print(f"Processing shard ({dataset_key}): {shard_idx}")

            # Load shard
            while True:
                try:
                    dataset = load_dataset(
                        "instruction-pretrain/general-instruction-augmented-corpora",
                        data_files={
                            "train": [
                                f"part-{shard_idx}/shard/{i:05}.txt"
                                for i in range(1000)
                                if (shard_idx, i) not in BAD_FILES
                            ]
                        },
                        split="train",
                        cache_dir=ipt_ds_cache_output_dir[shard_idx],
                        num_proc=64,
                    )
                    break
                except Exception as e:
                    print(
                        f"Exception getting  on shard_idx {shard_idx} for {dataset_key}: {str(e)}"
                    )

            # Map the dataset
            print(f"Mapping ({dataset_key}): {shard_idx}")
            dataset = dataset.map(
                partial(
                    process_raw_row_actual
                    if dataset_key == "actual"
                    else process_raw_row_synthetic,
                    tokenizer=tokenizer,
                ),
                num_proc=64,
                batched=True,
                batch_size=1,
            )

            # Upload shard
            SUBSHARDS = 14
            for subshard_idx in range(SUBSHARDS):
                new_shard_idx = shard_idx * SUBSHARDS + subshard_idx
                print(f"Sharding... ({dataset_key}): {shard_idx}/{subshard_idx}")
                new_dataset = dataset.shard(num_shards=SUBSHARDS, index=subshard_idx)
                print(f"Done sharding... ({dataset_key}): {shard_idx}/{subshard_idx}")
                shard_counts[new_shard_idx] = sum(new_dataset["token_count"])
                total_count += sum(new_dataset["token_count"])
                cumulative_shard_counts[new_shard_idx] = total_count
                while True:
                    try:
                        print(
                            f"Uploading... ({dataset_key}): {shard_idx}/{subshard_idx}"
                        )
                        new_dataset.push_to_hub(
                            f"fineinstructions-pretraining/ipt_{dataset_key}_all",
                            config_name=str(new_shard_idx),
                            max_shard_size="5GB",
                        )
                        print(f"Uploaded ({dataset_key}): {shard_idx}/{subshard_idx}")
                        break
                    except Exception as e:
                        print(f"Error uploading {shard_idx}/{subshard_idx}: {str(e)}")
                        continue

        # Upload counts
        print(f"Shard Counts ({dataset_key}):")
        print(json.dumps(shard_counts, indent=2))
        upload_file(
            f"fineinstructions-pretraining/ipt_{dataset_key}_all",
            json.dumps(shard_counts, indent=2),
            "shard_token_counts.json",
        )
        print(f"Cumulative Shard Counts ({dataset_key}):")
        print(json.dumps(cumulative_shard_counts, indent=2))
        upload_file(
            f"fineinstructions-pretraining/ipt_{dataset_key}_all",
            json.dumps(cumulative_shard_counts, indent=2),
            "cumulative_shard_token_counts.json",
        )
        print(f"Total Counts ({dataset_key}):")
        print(total_count)
        upload_file(
            f"fineinstructions-pretraining/ipt_{dataset_key}_all",
            json.dumps(total_count, indent=2),
            "total_token_count.json",
        )

    # Exit
    print("All uploads done.")
    sleep(99999)


__all__ = ["process_ipt"]
