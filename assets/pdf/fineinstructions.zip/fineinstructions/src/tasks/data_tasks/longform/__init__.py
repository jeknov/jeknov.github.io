import json
import tempfile
from functools import partial
from time import sleep

from datasets import concatenate_datasets, load_dataset
from huggingface_hub import HfApi
from transformers import AutoTokenizer


def upload_file(dataset, contents, filename):
    while True:
        try:
            api = HfApi()
            with tempfile.NamedTemporaryFile(delete=False) as tmp:
                tmp.write(contents.encode("utf-8"))
                tmp_path = tmp.name
            api.upload_file(
                path_or_fileobj=tmp_path,
                path_in_repo=filename,
                repo_id=dataset,
                repo_type="dataset",
            )
            print(f"Uploaded {filename}")
            break
        except Exception as e:
            print(f"Error uploading file {filename}: {str(e)}")


def process_raw_row_actual(row, tokenizer):
    rows = [
        {
            "input": row["input"][0],
            "output": row["output"][0],
            "source": row["source"][0],
            "subset": row["subset"][0],
        }
    ]
    texts = []
    token_counts = []
    for r in rows:
        current_text = r["output"].strip()
        current_token_count = len(tokenizer.encode(current_text)) - 1
        texts.append(current_text)
        token_counts.append(current_token_count)
    return {"text": texts, "token_count": token_counts}


def process_raw_row_synthetic(row, tokenizer):
    rows = [
        {
            "input": row["input"][0],
            "output": row["output"][0],
            "source": row["source"][0],
            "subset": row["subset"][0],
        }
    ]
    instructions = []
    answers = []
    token_counts = []
    for r in rows:
        current_instruction = r["input"]
        current_answer = r["output"]
        current_text = current_instruction + " " + current_answer
        current_token_count = len(tokenizer.encode(current_text)) - 1
        instructions.append(current_instruction)
        answers.append(current_answer)
        token_counts.append(current_token_count)
    return {"instruction": instructions, "answer": answers, "token_count": token_counts}


def process_longform(ctx):  # noqa: C901
    # Initialize
    from ....project import get_persistent_dir, reporter

    reporter.set(
        "data_tasks.process_longform_datasets_cache",
        "data_tasks.process_longform_datasets_cache",
    )
    longform_ds_cache_output_dir = get_persistent_dir(
        "process_longform_datasets_cache", "data_tasks.process_longform_datasets_cache"
    )
    tokenizer = AutoTokenizer.from_pretrained("meta-llama/Llama-3.2-1B-Instruct")

    # Process shards
    for dataset_key in ["synthetic", "actual"]:
        shard_counts = {}
        cumulative_shard_counts = {}
        total_count = 0
        shard_idx = 0
        print(f"Processing shard ({dataset_key}): {shard_idx}")

        # Load shard
        while True:
            try:
                dataset = concatenate_datasets(
                    [
                        load_dataset(
                            "akoksal/LongForm",
                            split="train",
                            cache_dir=longform_ds_cache_output_dir,
                            num_proc=64,
                        ),
                        load_dataset(
                            "akoksal/LongForm",
                            split="validation",
                            cache_dir=longform_ds_cache_output_dir,
                            num_proc=64,
                        ),
                        load_dataset(
                            "akoksal/LongForm",
                            split="test",
                            cache_dir=longform_ds_cache_output_dir,
                            num_proc=64,
                        ),
                    ]
                )
                break
            except Exception as e:
                print(
                    f"Exception getting  on shard_idx {shard_idx} for {dataset_key}: {str(e)}"
                )

        # Map the dataset
        print(f"Mapping ({dataset_key}): {shard_idx}")
        dataset = dataset.map(
            partial(
                process_raw_row_actual
                if dataset_key == "actual"
                else process_raw_row_synthetic,
                tokenizer=tokenizer,
            ),
            num_proc=64,
            batched=True,
            batch_size=1,
            remove_columns=["input", "output", "source", "subset"],
        )
        shard_counts[shard_idx] = sum(dataset["token_count"])
        total_count += sum(dataset["token_count"])
        cumulative_shard_counts[shard_idx] = total_count

        # Upload shard
        while True:
            try:
                dataset.push_to_hub(
                    f"fineinstructions-pretraining/longform_{dataset_key}_all",
                    config_name=str(shard_idx),
                    max_shard_size="5GB",
                )
                print(f"Uploaded ({dataset_key}): {shard_idx}")
                break
            except Exception as e:
                print(f"Error uploading {shard_idx}: {str(e)}")
                continue

        # Upload counts
        print(f"Shard Counts ({dataset_key}):")
        print(json.dumps(shard_counts, indent=2))
        upload_file(
            f"fineinstructions-pretraining/longform_{dataset_key}_all",
            json.dumps(shard_counts, indent=2),
            "shard_token_counts.json",
        )
        print(f"Cumulative Shard Counts ({dataset_key}):")
        print(json.dumps(cumulative_shard_counts, indent=2))
        upload_file(
            f"fineinstructions-pretraining/longform_{dataset_key}_all",
            json.dumps(cumulative_shard_counts, indent=2),
            "cumulative_shard_token_counts.json",
        )
        print(f"Total Counts ({dataset_key}):")
        print(total_count)
        upload_file(
            f"fineinstructions-pretraining/longform_{dataset_key}_all",
            json.dumps(total_count, indent=2),
            "total_token_count.json",
        )

    # Exit
    print("All uploads done.")
    sleep(99999)


__all__ = ["process_longform"]
