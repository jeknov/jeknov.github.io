import io
import itertools
import json
import sys
import tempfile
import threading
import uuid
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from functools import partial
from random import Random
from time import sleep

import boto3
import click
import datasets
import zstandard as zstd
from datasets import Dataset, disable_caching
from huggingface_hub import HfApi, RepoCard
from transformers import AutoTokenizer

current_count = defaultdict(int)
upload_queue = []
download_results = {}


class _DatasetGeneratorPickleHack:
    def __init__(self, generator, generator_id=None):
        self.generator = generator
        self.generator_id = (
            generator_id if generator_id is not None else str(uuid.uuid4())
        )

    def __call__(self, *args, **kwargs):
        return self.generator(*kwargs, **kwargs)

    def __reduce__(self):
        return (_DatasetGeneratorPickleHack_raise, (self.generator_id,))


def _DatasetGeneratorPickleHack_raise(*args, **kwargs):
    raise AssertionError("cannot actually unpickle _DatasetGeneratorPickleHack!")


def upload_queue_handler():
    print("Launching upload queue handler...")
    global upload_queue
    while True:
        while len(upload_queue) == 0:
            sleep(1)
        try:
            dataset, dataset_key, limit_string, shard_idx = upload_queue.pop(0)
        except Exception:
            print("Exiting upload queue handler...")
            break
        while True:
            try:
                HfApi._validate_yaml = lambda *args, **kwargs: print(
                    "Skipping YAML README.md validation logic...", file=sys.stderr
                )
                RepoCard.validate = lambda *args, **kwargs: print(
                    "Skipping YAML README.md validation logic...", file=sys.stderr
                )
                dataset.push_to_hub(
                    f"fineinstructions-pretraining/nemotron_{dataset_key}_"
                    + limit_string,
                    config_name=str(shard_idx),
                    max_shard_size="5GB",
                )
                print(f"Uploaded: {shard_idx}")
                break
            except Exception as e:
                print(f"Error uploading {shard_idx}: {str(e)}")
                continue


def download_prefetcher(upload_thread, bucket, files):
    global download_results

    print("Launching download prefetching thread...")
    for f in files:
        if not upload_thread.is_alive():
            print("Exiting download prefetching thread...")
            break
        while len(download_results) > 4:
            sleep(1)
        while True:
            try:
                s3 = boto3.client("s3")
                response = s3.get_object(Bucket=bucket, Key=f)
                compressed_stream = response["Body"]  # StreamingBody
                dctx = zstd.ZstdDecompressor()
                lines = []
                with dctx.stream_reader(
                    io.RawIOBase() if False else compressed_stream
                ) as reader:
                    text_stream = io.TextIOWrapper(reader, encoding="utf-8")
                    for line in text_stream:
                        try:
                            data = json.loads(line)
                            lines.append(
                                {
                                    "warc_record_id": data["warc_record_id"],
                                    "text": data["text"],
                                }
                            )
                        except json.JSONDecodeError:
                            continue
                download_results[f] = lines
                break
            except Exception as e:
                print(f"Error downloading {f}: {str(e)}")
                continue


def list_zstd_files(bucket: str, prefix: str) -> list:
    s3 = boto3.client("s3")
    paginator = s3.get_paginator("list_objects_v2")
    page_iterator = paginator.paginate(Bucket=bucket, Prefix=prefix)

    zstd_files = []

    for page in page_iterator:
        for obj in page.get("Contents", []):
            key = obj["Key"]
            if key.endswith(".zstd"):
                zstd_files.append(key)

    return zstd_files


def match_distribution_mix(actual_distribution, target_distribution):
    old_actual_distribution = actual_distribution
    actual_distribution = actual_distribution.copy()
    for idx, value in enumerate(target_distribution):
        target_key = value.split("CC-MAIN-")[1].split("-part-")[0]
        try:
            new_idx, _ = next(
                filter(
                    lambda v: v[1].split("CC-MAIN-")[1].split("-part-")[0]
                    == target_key,
                    enumerate(actual_distribution[idx:], idx),
                )
            )
            old_value = actual_distribution[idx]
            actual_distribution[idx] = actual_distribution[new_idx]
            if new_idx != idx:
                del actual_distribution[new_idx]
                actual_distribution.append(old_value)
        except StopIteration:
            pass
    assert len(old_actual_distribution) == len(actual_distribution)
    assert set(old_actual_distribution) == set(actual_distribution)
    return actual_distribution


def get_generator(tokenizer, limit, bucket, shard_idx, files, name):
    global current_count, download_results

    def generator():
        global current_count, download_results
        for f in files:
            print(
                f"Processing file ({shard_idx}):",
                name,
                f.split("/")[-1],
                current_count[name],
                limit,
                current_count[name] / limit,
                str(datetime.now()),
            )
            if (current_count[name]) > (limit - 1000):
                break
            while f not in download_results:
                print(f"Waiting for file to download...{f}")
                sleep(5)
            lines = download_results.pop(f)
            with ThreadPoolExecutor(max_workers=64) as executor:

                def add_token_count(line):
                    global current_count
                    return {
                        **line,
                        "token_count": (len(tokenizer.encode(line["text"])) - 1),
                    }

                for line in executor.map(add_token_count, lines):
                    if (current_count[name] + line["token_count"]) < limit:
                        current_count[name] += line["token_count"]
                        yield line

    return generator()


def upload_file(dataset, contents, filename):
    while True:
        try:
            api = HfApi()
            with tempfile.NamedTemporaryFile(delete=False) as tmp:
                tmp.write(contents.encode("utf-8"))
                tmp_path = tmp.name
            api.upload_file(
                path_or_fileobj=tmp_path,
                path_in_repo=filename,
                repo_id=dataset,
                repo_type="dataset",
            )
            print(f"Uploaded {filename}")
            break
        except Exception as e:
            print(f"Error uploading file {filename}: {str(e)}")


def process_dataset(
    dataset_key,
    bucket,
    FILES_MIX,
    nemotron_ds_cache_output_dir,
    tokenizer,
    limit,
    limit_string,
):
    global current_count, upload_queue
    shard_counts = {}
    cumulative_shard_counts = {}
    for shard_idx in range(len(FILES_MIX)):
        old_count = current_count[dataset_key]
        while True:
            try:
                disable_caching()
                try:
                    dataset = Dataset.from_generator(
                        _DatasetGeneratorPickleHack(
                            partial(
                                get_generator,
                                tokenizer=tokenizer,
                                limit=limit,
                                bucket=bucket,
                                shard_idx=shard_idx,
                                files=[FILES_MIX[shard_idx]],
                                name=dataset_key,
                            )
                        ),
                        keep_in_memory=True,
                        cache_dir=nemotron_ds_cache_output_dir,
                    )
                    print("----------------------------------------")
                    while len(upload_queue) > 3:
                        sleep(1)
                    upload_queue.append((dataset, dataset_key, limit_string, shard_idx))
                    shard_counts[shard_idx] = current_count[dataset_key] - old_count
                    cumulative_shard_counts[shard_idx] = current_count[dataset_key]
                    print("----------------------------------------")
                except datasets.exceptions.DatasetGenerationError as e:
                    if isinstance(
                        e.__cause__, datasets.arrow_writer.SchemaInferenceError
                    ):
                        print(f"No need to upload {shard_idx}. Hit the limit.")
                    else:
                        raise e
                break
            except Exception as e:
                print(f"Exception on shard_idx {shard_idx} for {dataset_key}: {str(e)}")
                raise e
                current_count[dataset_key] = old_count
                continue
    print(f"Shard Counts ({dataset_key}):")
    print(json.dumps(shard_counts, indent=2))
    upload_file(
        f"fineinstructions-pretraining/nemotron_{dataset_key}_" + limit_string,
        json.dumps(shard_counts, indent=2),
        "shard_token_counts.json",
    )
    print(f"Cumulative Shard Counts ({dataset_key}):")
    print(json.dumps(cumulative_shard_counts, indent=2))
    upload_file(
        f"fineinstructions-pretraining/nemotron_{dataset_key}_" + limit_string,
        json.dumps(cumulative_shard_counts, indent=2),
        "cumulative_shard_token_counts.json",
    )
    print(f"Total Counts ({dataset_key}):")
    print(current_count[dataset_key])
    upload_file(
        f"fineinstructions-pretraining/nemotron_{dataset_key}_" + limit_string,
        json.dumps(current_count[dataset_key], indent=2),
        "total_token_count.json",
    )


@click.option(
    "--dataset-name", "-d", type=str, required=True, help="The dataset to process."
)
def process_nemotron(ctx, dataset_name):  # noqa: C901
    upload_thread = threading.Thread(target=upload_queue_handler)
    upload_thread.start()

    from ....project import get_persistent_dir, reporter

    reporter.set(
        "data_tasks.process_nemotron_datasets_cache",
        "data_tasks.process_nemotron_datasets_cache",
    )
    nemotron_ds_cache_output_dir = get_persistent_dir(
        "process_nemotron_datasets_cache", "data_tasks.process_nemotron_datasets_cache"
    )

    limit = "1"
    limit_string = limit + "T"
    limit = float(limit) * int(1e12)
    # Maximum of 600 billion
    limit = min(int(limit), 600 * int(1e9))
    print("Processing data for Token Limit:", limit_string)
    print("----------------------------------------")
    tokenizer = AutoTokenizer.from_pretrained("meta-llama/Llama-3.2-1B-Instruct")
    BUCKET = "commoncrawl"
    ACTUAL_PREFIX = (
        "contrib/Nemotron/Nemotron-CC/data-jsonl/quality=high/kind=actual/kind2=actual/"
    )
    SYNTHETIC_1_PREFIX = "contrib/Nemotron/Nemotron-CC/data-jsonl/quality=high/kind=synthetic/kind2=distill/"
    SYNTHETIC_2_PREFIX = "contrib/Nemotron/Nemotron-CC/data-jsonl/quality=high/kind=synthetic/kind2=diverse_qa_pairs/"
    SYNTHETIC_3_PREFIX = "contrib/Nemotron/Nemotron-CC/data-jsonl/quality=high/kind=synthetic/kind2=extract_knowledge/"
    SYNTHETIC_4_PREFIX = "contrib/Nemotron/Nemotron-CC/data-jsonl/quality=high/kind=synthetic/kind2=knowledge_list/"
    SYNTHETIC_5_PREFIX = "contrib/Nemotron/Nemotron-CC/data-jsonl/quality=high/kind=synthetic/kind2=wrap_medium/"
    NEMOTRON_ACTUAL_MIX = [ACTUAL_PREFIX]
    NEMOTRON_SYNTHETIC_MIX = [
        ACTUAL_PREFIX,
        SYNTHETIC_1_PREFIX,
        SYNTHETIC_2_PREFIX,
        SYNTHETIC_3_PREFIX,
        SYNTHETIC_4_PREFIX,
        SYNTHETIC_5_PREFIX,
    ]
    NEMOTRON_SYNTHETIC_WRAP_MIX = [ACTUAL_PREFIX, SYNTHETIC_5_PREFIX]
    NEMOTRON_SYNTHETIC_QA_MIX = [SYNTHETIC_2_PREFIX]
    r = Random(42)

    # Get all files
    NEMOTRON_ACTUAL_MIX = list(
        itertools.chain.from_iterable(
            [list_zstd_files(bucket=BUCKET, prefix=p) for p in NEMOTRON_ACTUAL_MIX]
        )
    )
    NEMOTRON_SYNTHETIC_MIX = list(
        itertools.chain.from_iterable(
            [list_zstd_files(bucket=BUCKET, prefix=p) for p in NEMOTRON_SYNTHETIC_MIX]
        )
    )
    NEMOTRON_SYNTHETIC_WRAP_MIX = list(
        itertools.chain.from_iterable(
            [
                list_zstd_files(bucket=BUCKET, prefix=p)
                for p in NEMOTRON_SYNTHETIC_WRAP_MIX
            ]
        )
    )
    NEMOTRON_SYNTHETIC_QA_MIX = list(
        itertools.chain.from_iterable(
            [
                list_zstd_files(bucket=BUCKET, prefix=p)
                for p in NEMOTRON_SYNTHETIC_QA_MIX
            ]
        )
    )
    r.shuffle(NEMOTRON_ACTUAL_MIX)
    r.shuffle(NEMOTRON_SYNTHETIC_MIX)
    r.shuffle(NEMOTRON_SYNTHETIC_WRAP_MIX)
    r.shuffle(NEMOTRON_SYNTHETIC_QA_MIX)
    NEMOTRON_SYNTHETIC_MIX = match_distribution_mix(
        actual_distribution=NEMOTRON_SYNTHETIC_MIX,
        target_distribution=NEMOTRON_ACTUAL_MIX,
    )
    NEMOTRON_SYNTHETIC_WRAP_MIX = match_distribution_mix(
        actual_distribution=NEMOTRON_SYNTHETIC_WRAP_MIX,
        target_distribution=NEMOTRON_ACTUAL_MIX,
    )
    NEMOTRON_SYNTHETIC_QA_MIX = match_distribution_mix(
        actual_distribution=NEMOTRON_SYNTHETIC_QA_MIX,
        target_distribution=NEMOTRON_ACTUAL_MIX,
    )
    from collections import Counter

    print(
        "Actual:",
        Counter(
            [v.split("kind2=")[1].split("/CC-MAIN")[0] for v in NEMOTRON_ACTUAL_MIX]
        ),
        json.dumps(NEMOTRON_ACTUAL_MIX[0:10], indent=2),
    )
    print(
        "Synthetic:",
        Counter(
            [v.split("kind2=")[1].split("/CC-MAIN")[0] for v in NEMOTRON_SYNTHETIC_MIX]
        ),
        json.dumps(NEMOTRON_SYNTHETIC_MIX[0:10], indent=2),
    )
    print(
        "WRAP:",
        Counter(
            [
                v.split("kind2=")[1].split("/CC-MAIN")[0]
                for v in NEMOTRON_SYNTHETIC_WRAP_MIX
            ]
        ),
        json.dumps(NEMOTRON_SYNTHETIC_WRAP_MIX[0:10], indent=2),
    )
    print(
        "Diverse QA:",
        Counter(
            [
                v.split("kind2=")[1].split("/CC-MAIN")[0]
                for v in NEMOTRON_SYNTHETIC_QA_MIX
            ]
        ),
        json.dumps(NEMOTRON_SYNTHETIC_QA_MIX[0:10], indent=2),
    )
    print("----------------------------------------")

    # Process selected dataset
    datasets_available = {
        "actual": NEMOTRON_ACTUAL_MIX,
        "synthetic": NEMOTRON_SYNTHETIC_MIX,
        "wrap": NEMOTRON_SYNTHETIC_WRAP_MIX,
        "qa": NEMOTRON_SYNTHETIC_QA_MIX,
    }
    download_thread = threading.Thread(
        target=download_prefetcher,
        args=(upload_thread, BUCKET, datasets_available[dataset_name]),
    )
    download_thread.start()
    process_dataset(
        dataset_key=dataset_name,
        bucket=BUCKET,
        FILES_MIX=datasets_available[dataset_name],
        nemotron_ds_cache_output_dir=nemotron_ds_cache_output_dir,
        tokenizer=tokenizer,
        limit=limit,
        limit_string=limit_string,
    )

    # Exit the upload queue
    upload_queue.append(None)
    while upload_thread.is_alive():
        print("Waiting for uploads...")
        sleep(1)
    print("All uploads done.")
    sleep(9999999999999999999999)


__all__ = ["process_nemotron"]
