import sys

import torch


def get_compute_metrics_dtype():
    compute_metrics_dtype = torch.float16
    try:
        torch.nn.functional.cross_entropy(
            input=torch.tensor([[1.0]], dtype=compute_metrics_dtype),
            target=torch.tensor([0], dtype=torch.long),
        )
    except RuntimeError:  # pragma: no cover
        compute_metrics_dtype = torch.float32
    return compute_metrics_dtype


all_metrics = []


def compute_metrics(eval_pred, compute_result=None):
    preds, labels = eval_pred
    del eval_pred
    if isinstance(preds, tuple):
        preds = preds[0]
    preds = preds.clone().detach().cpu().to(get_compute_metrics_dtype())
    batch_size = preds.shape[0]
    if not isinstance(labels, torch.Tensor):
        labels = torch.tensor(labels).cpu()
    else:
        labels = labels.clone().detach().cpu()
    if compute_result is not None:
        rows = sum([m["weight"] for m in all_metrics])
        if rows % 100 == 0:
            print("Evaluation/Validation Progress:", rows, "row(s)", file=sys.stderr)
    is_encoder_decoder = False
    if is_encoder_decoder:
        nll = torch.nn.functional.cross_entropy(
            input=preds.view(-1, preds.size(-1)), target=labels.view(-1)
        )
    else:
        preds = preds.to(get_compute_metrics_dtype())
        labels = labels
        shift_preds = preds[..., :-1, :].contiguous()
        del preds
        shift_labels = labels[..., 1:].contiguous()
        del labels
        nll = torch.nn.functional.cross_entropy(
            input=shift_preds.view(-1, shift_preds.size(-1)),
            target=shift_labels.view(-1),
        )
    metrics = {"perplexity": torch.exp(nll)}
    if compute_result is not None:
        all_metrics.append({"weight": batch_size, "metrics": metrics})
        if compute_result is True:
            # Average the metrics
            total_weight = sum([m["weight"] for m in all_metrics])
            total_perplexity = sum(
                [m["weight"] * m["metrics"]["perplexity"] for m in all_metrics]
            )

            # Reset the metrics
            all_metrics.clear()

            return {"perplexity": total_perplexity / total_weight}
        else:
            return metrics
    else:
        return metrics
