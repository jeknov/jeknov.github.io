import os
import socket

import torch
from datadreamer import DataDreamer
from datadreamer.steps import HFHubDataSource
from datadreamer.trainers import TrainHFFineTune
from peft import LoraConfig

from .metrics import compute_metrics
from .preprocessing import (
    create_input_and_output_columns,
    create_input_and_output_columns_v2,
    template_instantiation_quality_filter_v2,
    template_instantiation_quality_filter_v3,
)


def train_instantiator(ctx):
    from ....project import (
        get_persistent_dir,
        get_torch_cpu_device,
        get_torch_devices,
        reporter,
    )

    reporter.set("doc_to_instruction.train_instantiator", "train_instantiator")
    datadreamer_output_dir = get_persistent_dir(
        "train_instantiator", "doc_to_instruction.train_instantiator"
    )

    with DataDreamer(datadreamer_output_dir, log_date=True):
        MODEL_NAME = "meta-llama/Llama-3.2-3B-Instruct"
        PEFT_CONFIG = LoraConfig(r=64)
        EPOCHS = 8
        LEARNING_RATE = 1e-4
        BATCH_SIZE = 1
        DTYPE = torch.bfloat16 if len(get_torch_devices()) > 0 else torch.float32
        TRAIN_DEVICE = (
            get_torch_devices()
            if len(get_torch_devices()) > 0
            else get_torch_cpu_device()
        )
        GRADIENT_ACCUMULATION_STEPS = 8 // len(get_torch_devices())
        VALIDATION_SIZE = 1000

        print("----------------------------------------")
        print("HOSTNAME:", socket.gethostname())
        print("EPOCHS:", EPOCHS)
        print("TRAIN_DEVICE:", TRAIN_DEVICE)
        print("DTYPE:", DTYPE)
        print("BATCH_SIZE:", BATCH_SIZE)
        print("GRADIENT_ACCUMULATION_STEPS:", GRADIENT_ACCUMULATION_STEPS)
        print("----------------------------------------")

        # Load templates instantiations dataset
        instantiations_dataset = HFHubDataSource(
            "Get Template Instantiations",
            "fineinstructions/template_instantiator_training",
            split="full",
            revision="95fe949f774b4ed53e12d11df930be5fa2fe96fd",
        )

        # Filter out template instantiations
        print(
            "Number of template instantiations before filtering:",
            len(instantiations_dataset.output),
        )
        instantiations_dataset = instantiations_dataset.filter(
            template_instantiation_quality_filter_v2,
            lazy=False,
            name="Filter out Low-Quality Instantiations",
        )
        print(
            "Number of template instantiations after filtering:",
            len(instantiations_dataset.output),
        )

        if len(instantiations_dataset.output) < VALIDATION_SIZE * 10:
            VALIDATION_SIZE = 100

        # Map instantiations to output format
        instantiations_dataset = instantiations_dataset.map(
            create_input_and_output_columns,
            lazy=False,
            name="Create Input + Output Columns",
            remove_columns=set(instantiations_dataset.output.column_names).difference(
                ["input_json", "output_json"]
            ),
        )

        # Create split for training
        splits = instantiations_dataset.splits(
            train_size=len(instantiations_dataset.output) - VALIDATION_SIZE,
            validation_size=VALIDATION_SIZE,
        )
        train_split, validation_split = splits["train"], splits["validation"]

        # Preview training data
        train_input_json = list(train_split.output.dataset["input_json"])[0]
        train_output_json = list(train_split.output.dataset["output_json"])[0]

        print("----------------------------------------")
        print("Training Data Preview Input JSON:\n", train_input_json)
        print("----------------------------------------")
        print("Training Data Preview Output JSON:\n", train_output_json)
        print("----------------------------------------")

        # Train End-to-End model
        trainer = TrainHFFineTune(
            "Train Template Instantiator",
            model_name=MODEL_NAME,
            peft_config=PEFT_CONFIG,
            device=TRAIN_DEVICE,
            dtype=DTYPE,
            fsdp=False,
        )
        trainer.train(
            train_input=train_split.output["input_json"],
            train_output=train_split.output["output_json"],
            validation_input=validation_split.output["input_json"],
            validation_output=validation_split.output["output_json"],
            epochs=EPOCHS,
            learning_rate=LEARNING_RATE,
            lr_scheduler_type="constant",
            batch_size=BATCH_SIZE,
            gradient_accumulation_steps=GRADIENT_ACCUMULATION_STEPS,
            compute_metrics=compute_metrics,
            batch_eval_metrics=True,
            early_stopping_patience=1,
        )
        end_to_end_export_path = os.path.join(
            datadreamer_output_dir, "template_instantiator_export"
        )
        trainer.export_to_disk(end_to_end_export_path, adapter_only=False)
        trainer.publish_to_hf_hub(
            "fineinstructions/template_instantiator", adapter_only=False
        )
        trainer.publish_to_hf_hub(
            "fineinstructions/template_instantiator_adapter", adapter_only=True
        )
        trainer.unload_model()

    # Sleep
    from time import sleep

    sleep(1000000)


def train_instantiator_2(ctx):
    from ....project import (
        get_persistent_dir,
        get_torch_cpu_device,
        get_torch_devices,
        reporter,
    )

    reporter.set("doc_to_instruction.train_instantiator", "train_instantiator")
    datadreamer_output_dir = get_persistent_dir(
        "train_instantiator", "doc_to_instruction.train_instantiator"
    )

    with DataDreamer(datadreamer_output_dir, log_date=True):
        MODEL_NAME = "fineinstructions/template_instantiator"
        PEFT_CONFIG = LoraConfig(r=32)
        EPOCHS = 8
        LEARNING_RATE = 1e-4
        BATCH_SIZE = 1
        DTYPE = torch.bfloat16 if len(get_torch_devices()) > 0 else torch.float32
        TRAIN_DEVICE = (
            get_torch_devices()
            if len(get_torch_devices()) > 0
            else get_torch_cpu_device()
        )
        GRADIENT_ACCUMULATION_STEPS = 8 // len(get_torch_devices())

        print("----------------------------------------")
        print("HOSTNAME:", socket.gethostname())
        print("EPOCHS:", EPOCHS)
        print("TRAIN_DEVICE:", TRAIN_DEVICE)
        print("DTYPE:", DTYPE)
        print("BATCH_SIZE:", BATCH_SIZE)
        print("GRADIENT_ACCUMULATION_STEPS:", GRADIENT_ACCUMULATION_STEPS)
        print("----------------------------------------")

        # Load templates instantiations dataset
        instantiations_train_dataset = HFHubDataSource(
            "Get Template Instantiations (train)",
            "fineinstructions/template_instantiator_training_v2",
            split="train",
            revision="f0fe60f61f224fe1a82a520a6859e34b962ef710",
        )
        instantiations_validation_dataset = HFHubDataSource(
            "Get Template Instantiations (validation)",
            "fineinstructions/template_instantiator_training_v2",
            split="validation",
            revision="f0fe60f61f224fe1a82a520a6859e34b962ef710",
        )

        # Filter out template instantiations from train dataset
        print(
            "Number of template instantiations in train set before filtering:",
            len(instantiations_train_dataset.output),
        )
        instantiations_train_dataset = instantiations_train_dataset.filter(
            template_instantiation_quality_filter_v3,
            lazy=False,
            name="Filter out Low-Quality Train Instantiations",
        )
        print(
            "Number of template instantiations in train set after filtering:",
            len(instantiations_train_dataset.output),
        )

        # Filter out template instantiations from validation dataset
        print(
            "Number of template instantiations in validation set before filtering:",
            len(instantiations_validation_dataset.output),
        )
        instantiations_validation_dataset = instantiations_validation_dataset.filter(
            template_instantiation_quality_filter_v3,
            lazy=False,
            name="Filter out Low-Quality Validation Instantiations",
        )
        print(
            "Number of template instantiations in validation set after filtering:",
            len(instantiations_validation_dataset.output),
        )

        # Map instantiations to output format
        train_split = instantiations_train_dataset.map(
            create_input_and_output_columns_v2,
            lazy=False,
            name="Create Input + Output Columns",
            remove_columns=set(
                instantiations_train_dataset.output.column_names
            ).difference(["input_json", "output_json"]),
        )
        validation_split = instantiations_validation_dataset.map(
            create_input_and_output_columns_v2,
            lazy=False,
            name="Create Input + Output Columns",
            remove_columns=set(
                instantiations_validation_dataset.output.column_names
            ).difference(["input_json", "output_json"]),
        )

        # Preview training data
        train_input_json = list(train_split.output.dataset["input_json"])[0]
        train_output_json = list(train_split.output.dataset["output_json"])[0]

        print("----------------------------------------")
        print("Training Data Preview Input JSON:\n", train_input_json)
        print("----------------------------------------")
        print("Training Data Preview Output JSON:\n", train_output_json)
        print("----------------------------------------")

        # Train End-to-End model
        trainer = TrainHFFineTune(
            "Train Template Instantiator",
            model_name=MODEL_NAME,
            revision="14f36a4af8074932e29f5d90e9ad7ca9366d96eb",
            peft_config=PEFT_CONFIG,
            device=TRAIN_DEVICE,
            dtype=DTYPE,
            fsdp=False,
        )
        trainer.train(
            train_input=train_split.output["input_json"],
            train_output=train_split.output["output_json"],
            validation_input=validation_split.output["input_json"],
            validation_output=validation_split.output["output_json"],
            epochs=EPOCHS,
            learning_rate=LEARNING_RATE,
            lr_scheduler_type="constant",
            batch_size=BATCH_SIZE,
            gradient_accumulation_steps=GRADIENT_ACCUMULATION_STEPS,
            compute_metrics=compute_metrics,
            batch_eval_metrics=True,
            early_stopping_patience=1,
        )
        end_to_end_export_path = os.path.join(
            datadreamer_output_dir, "template_instantiator_export"
        )
        trainer.export_to_disk(end_to_end_export_path, adapter_only=False)
        trainer.publish_to_hf_hub(
            "fineinstructions/template_instantiator", adapter_only=False
        )
        trainer.publish_to_hf_hub(
            "fineinstructions/template_instantiator_adapter", adapter_only=True
        )
        trainer.unload_model()

    # Sleep
    from time import sleep

    sleep(1000000)


__all__ = ["train_instantiator", "train_instantiator_2"]
