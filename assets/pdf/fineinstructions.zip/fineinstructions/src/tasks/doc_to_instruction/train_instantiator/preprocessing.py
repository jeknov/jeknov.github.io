import json
import random


def template_instantiation_quality_filter_v2(row):
    no_nulls = row["instruction"] is not None and row["shortened_answer"] is not None
    short_enough = (
        len(row["document"]) <= 15000 and len(row["instruction"]) <= 2000
    )  # Prevent OOM
    return no_nulls and short_enough


def create_input_and_output_columns(row):
    input_json = {"instruction_template": row["template"], "document": row["document"]}
    output_json = {
        "instantiated_instruction": row["instruction"],
        "answer": row["shortened_answer"],
    }

    return {
        "input_json": json.dumps(input_json, indent=2),
        "output_json": json.dumps(output_json, indent=2),
    }


r = random.seed(42)


def template_instantiation_quality_filter_v3(row):
    is_null = row["shortened_instruction"] is None and row["shortened_answer"] is None
    if is_null:
        short_enough = False
    else:
        short_enough = (
            len(row["document"]) <= 10000 and len(row["shortened_instruction"]) <= 2000
        )  # Prevent OOM
    return is_null or short_enough


def create_input_and_output_columns_v2(row):
    input_json = {"instruction_template": row["template"], "document": row["document"]}
    output_json = {
        "instantiated_instruction": row["shortened_instruction"],
        "answer": row["shortened_answer"],
    }

    return {
        "input_json": json.dumps(input_json, indent=2),
        "output_json": json.dumps(output_json, indent=2),
    }
