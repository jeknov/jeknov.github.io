import hashlib
import os
import sys
from functools import partial

from datadreamer import DataDreamer
from datadreamer.embedders import ParallelEmbedder
from datadreamer.llms import VLLM, ParallelLLM
from datadreamer.steps import (
    DataSource,
    HFDatasetDataSource,
    HFHubDataSource,
    Prompt,
    Retrieve,
    concat,
    zipped,
)
from datasets import Dataset

from ....datadreamer_ext.openrouter import OpenRouter
from .custom_datadreamer_modules import (
    CoverageEmbeddingRetriever,
    CoverageSentenceTransformersEmbedder,
)
from .instantiation_prompts import (
    create_answer_extraction_prompts,
    create_answer_rephrase_prompts,
    create_instantiation_prompts,
    create_instantiation_prompts_round_2,
    create_instantiation_prompts_round_3,
    create_instantiation_prompts_round_4,
    create_judge_instruction_prompts,
    create_judge_match_prompts,
    create_judge_pair_2_prompts,
    create_judge_pair_prompts,
    final_quality_filter,
    final_quality_map,
    final_train_format_mapper,
    keep_or_new,
    make_score_filter,
    make_template_match_judgement_filter,
    post_process_answer_extraction,
    post_process_answer_rephrase,
    post_process_instantiation,
    post_process_instantiation_round_4,
    post_process_judge_instruction,
    post_process_judge_match,
    post_process_judge_pair,
)


def instantiation_subsample(ctx):  # noqa: C901
    from ....project import get_persistent_dir, get_torch_devices, reporter

    reporter.set(
        "doc_to_instruction.instantiation_subsample_datadreamer_output",
        "instantiation_subsample_datadreamer_output",
    )
    datadreamer_output_dir = get_persistent_dir(
        "instantiation_subsample_datadreamer_output",
        "doc_to_instruction.instantiation_subsample_datadreamer_output",
    )

    with DataDreamer(datadreamer_output_dir, log_date=True):
        from time import sleep

        sleep(999999999)

        assert (
            len(get_torch_devices()) >= 2
        ), "The script must be run with at least 2 GPU(s)."

        llm_70 = OpenRouter(
            model_name="meta-llama/llama-3.3-70b-instruct",
            api_key=os.environ["OPENROUTER_API_KEY"],
            base_url="https://openrouter.ai/api/v1",
        )

        # Load FineWeb documents
        documents = (
            HFHubDataSource(
                "Get FineWeb Documents",
                "HuggingFaceFW/fineweb",
                split="train",
                config_name="sample-10BT",
            )
            .shuffle(seed=42, lazy=False)
            .take(500000, lazy=False)
            .select_columns(["text"])
            .rename_column("text", "document")
        )
        documents = documents.filter(
            lambda row: llm_70.count_tokens(row["document"]) < 12000,
            lazy=False,
            name="Filter Out Documents Too Long",
        )

        # Create a retriever
        embedder = ParallelEmbedder(
            *[
                CoverageSentenceTransformersEmbedder(
                    "fineinstructions/instruction_template_retrieval_embedding",
                    revision="db4efbde126216250ffa5a356663fc7da3bf7856",
                    device=d,
                    dtype="bfloat16",
                )
                for d in get_torch_devices()[1:]
            ]
        )
        dummy_templates = DataSource("Dummy Templates", data=[{"template": ""}])
        retriever = CoverageEmbeddingRetriever(
            texts=dummy_templates.take(1).output["template"],
            embedder=embedder,
            truncate=True,
            device=get_torch_devices()[0],
        )
        queries = documents.output["document"]
        most_compatible_templates = Retrieve(  # noqa: F841
            "Retrieve most compatible template descriptions",
            args={
                "retriever": retriever,
                "k": 2047,
                "index_batch_size": 1,
                "batch_size": 40,
                "lazy": False,
            },
            inputs={"queries": queries},
        )
        assert len(documents.output) == len(most_compatible_templates.output)

        # Combine documents and templates
        documents_and_templates = zipped(
            documents,
            most_compatible_templates,
            name="Combine documents + templates",
            lazy=False,
        )
        documents_and_templates.publish_to_hf_hub(
            "fineinstructions/documents_and_templates", split="full"
        )


def document_and_template_generator(
    documents_and_templates_dataset, templates_dataset_rows
):
    def _document_and_template_generator(
        documents_and_templates_dataset, templates_dataset_rows
    ):
        for row in documents_and_templates_dataset.output:
            for chunk_idx, idx in zip(
                row["results"]["chunks"][:6], row["results"]["indices"][:6]
            ):
                yield {**row, "chunk_idx": chunk_idx, **templates_dataset_rows[idx]}

    return partial(
        _document_and_template_generator,
        documents_and_templates_dataset=documents_and_templates_dataset,
        templates_dataset_rows=templates_dataset_rows,
    )


def instantiation_subsample_2(ctx):  # noqa: C901
    sys.setrecursionlimit(9999)
    from ....project import get_persistent_dir, reporter

    # Flag to control whether to force re-run the pipeline without caching
    FORCE = False

    reporter.set(
        "doc_to_instruction.instantiation_subsample_datadreamer_output",
        "instantiation_subsample_datadreamer_output",
    )
    datadreamer_output_dir = get_persistent_dir(
        "instantiation_subsample_datadreamer_output",
        "doc_to_instruction.instantiation_subsample_datadreamer_output",
    )

    with DataDreamer(datadreamer_output_dir, log_date=True):
        llm_70 = OpenRouter(
            model_name="meta-llama/llama-3.3-70b-instruct",
            api_key=os.environ["OPENROUTER_API_KEY"],
            base_url="https://openrouter.ai/api/v1",
        )

        # Get all documents and templates
        documents_and_templates_dataset = HFHubDataSource(
            "Get Documents and Templates Dataset",
            "fineinstructions/documents_and_templates",
            revision="94ec6a0ca08e7ae76bb3b1168292897bc9835606",
            split="full",
        ).take(100000)

        # Get all templates
        templates_dataset = HFHubDataSource(
            "Get Templates Dataset",
            "fineinstructions/finetemplates",
            revision="7b7638debc46cc9ee6bec17ce9006e7838dbf10c",
            split="full",
        )
        templates_dataset_rows = templates_dataset.output.dataset

        # Loop over all rows
        documents_and_templates_iterator = DataSource(
            "Get Documents and Templates Dataset Iterator",
            data=Dataset.from_list(
                list(
                    document_and_template_generator(
                        documents_and_templates_dataset, templates_dataset_rows
                    )()
                )
            ),
            total_num_rows=len(documents_and_templates_dataset.output) * 6,
        )

        # Generate instructions
        instantation_prompts = documents_and_templates_iterator.map(
            create_instantiation_prompts,
            lazy=False,
            name="Create Instantiation Prompts",
            total_num_rows=(len(documents_and_templates_dataset.output) * 6),
            force=FORCE,
        )
        instructions = Prompt(
            name="Generate Instructions",
            inputs={"prompts": instantation_prompts.output["prompt"]},
            args={
                "llm": llm_70,
                "batch_size": 999 * 7,
                "temperature": 1.0,
                "top_p": 0.0,
                "max_new_tokens": 3000,
                "post_process": post_process_instantiation,
            },
            outputs={"generations": "instruction"},
            force=FORCE,
        ).select_columns(["instruction"])
        documents_and_instructions = zipped(
            documents_and_templates_iterator,
            instructions,
            lazy=True,
            name="Documents + Instructions",
        )

        # Generate extractions
        extraction_prompts = documents_and_instructions.map(
            create_answer_extraction_prompts,
            lazy=False,
            name="Create Extraction Prompts",
            total_num_rows=(len(documents_and_templates_dataset.output) * 6),
            force=FORCE,
        )
        extractions = Prompt(
            name="Generate Extractions",
            inputs={"prompts": extraction_prompts.output["prompt"]},
            args={
                "llm": llm_70,
                "batch_size": 120,
                "temperature": 1.0,
                "top_p": 0.0,
                "max_new_tokens": 5000,
                "post_process": post_process_answer_extraction,
            },
            outputs={"generations": "extraction"},
            force=FORCE,
        ).select_columns(["extraction"])
        documents_and_instructions_and_extractions = zipped(
            documents_and_templates_iterator,
            instructions,
            extractions,
            lazy=True,
            name="Documents + Instructions + Extractions",
        )

        # Generate instructions (round 2)
        instantation_prompts = documents_and_instructions_and_extractions.map(
            create_instantiation_prompts_round_2,
            lazy=False,
            name="Create Instantiation Prompts (round 2)",
            total_num_rows=(len(documents_and_templates_dataset.output) * 6),
            force=FORCE,
        )
        instructions = Prompt(
            name="Generate Instructions (round 2)",
            inputs={"prompts": instantation_prompts.output["prompt"]},
            args={
                "llm": llm_70,
                "batch_size": 120,
                "temperature": 1.0,
                "top_p": 0.0,
                "max_new_tokens": 3000,
                "post_process": post_process_instantiation,
            },
            outputs={"generations": "instruction"},
            force=FORCE,
        ).select_columns(["instruction"])
        documents_and_instructions_and_extractions = zipped(
            documents_and_templates_iterator,
            instructions,
            extractions,
            lazy=True,
            name="Documents + Instructions (round 2) + Extractions",
        )

        # Generate instructions (round 3)
        instantation_prompts = documents_and_instructions_and_extractions.map(
            create_instantiation_prompts_round_3,
            lazy=False,
            name="Create Instantiation Prompts (round 3)",
            total_num_rows=(len(documents_and_templates_dataset.output) * 6),
            force=FORCE,
        )
        instructions = Prompt(
            name="Generate Instructions (round 3)",
            inputs={"prompts": instantation_prompts.output["prompt"]},
            args={
                "llm": llm_70,
                "batch_size": 120,
                "temperature": 1.0,
                "top_p": 0.0,
                "max_new_tokens": 3000,
                "post_process": post_process_instantiation,
            },
            outputs={"generations": "instruction"},
            force=FORCE,
        ).select_columns(["instruction"])
        documents_and_instructions_and_extractions = zipped(
            documents_and_templates_iterator,
            instructions,
            extractions,
            lazy=True,
            name="Documents + Instructions (round 3) + Extractions",
        )

        # Generate answers
        answer_prompts = documents_and_instructions_and_extractions.map(
            create_answer_rephrase_prompts,
            lazy=False,
            name="Create Answer Prompts",
            total_num_rows=(len(documents_and_templates_dataset.output) * 6),
            force=FORCE,
        )
        answers = Prompt(
            name="Generate Answers",
            inputs={"prompts": answer_prompts.output["prompt"]},
            args={
                "llm": llm_70,
                "batch_size": 120,
                "temperature": 1.0,
                "top_p": 0.0,
                "max_new_tokens": 5000,
                "post_process": post_process_answer_rephrase,
            },
            outputs={"generations": "answer"},
            force=FORCE,
        ).select_columns(["answer"])
        documents_and_instructions_and_answers = zipped(
            documents_and_instructions_and_extractions.select_columns(
                ["document", "chunk_idx", "template", "instruction"]
            ),
            answers,
            lazy=True,
            name="Documents + Instructions + Answers",
        )

        # Generate instructions (round 4)
        instantation_prompts = documents_and_instructions_and_answers.map(
            create_instantiation_prompts_round_4,
            lazy=False,
            name="Create Instantiation Prompts (round 4)",
            total_num_rows=(len(documents_and_templates_dataset.output) * 6),
            force=FORCE,
        )
        new_instructions = Prompt(
            name="Generate Instructions (round 4)",
            inputs={"prompts": instantation_prompts.output["prompt"]},
            args={
                "llm": llm_70,
                "batch_size": 120,
                "temperature": 1.0,
                "top_p": 0.0,
                "max_new_tokens": 3000,
                "post_process": post_process_instantiation_round_4,
            },
            outputs={"generations": "new_instruction"},
            force=FORCE,
        ).select_columns(["new_instruction"])
        documents_and_instructions_and_answers = zipped(
            documents_and_templates_iterator.select_columns(
                ["document", "chunk_idx", "template"]
            ),
            instructions,
            new_instructions,
            answers,
            lazy=True,
            name="Documents + Instructions (round 4) + Answers",
        ).map(
            keep_or_new,
            remove_columns=["new_instruction"],
            lazy=False,
            name="Keep old instructions or use new instructions (round 4)",
            total_num_rows=(len(documents_and_templates_dataset.output) * 6),
            force=FORCE,
        )

        # Create final dataset
        final_dataset = documents_and_instructions_and_answers.filter(
            final_quality_filter,
            force=FORCE,
            lazy=True,
            name="Filter out Low-Quality Examples",
            total_num_rows=(len(documents_and_templates_dataset.output) * 6),
        ).map(
            final_quality_map,
            force=FORCE,
            lazy=False,
            name="Add Shortened Answer",
            total_num_rows=(len(documents_and_templates_dataset.output) * 6),
            save_num_proc=16,
        )
        final_dataset.publish_to_hf_hub(
            "fineinstructions/template_instantiator_training", split="full"
        )
        from time import sleep

        sleep(999999999)  # TODO


def instantiation_subsample_3(ctx):  # noqa: C901
    sys.setrecursionlimit(9999)
    from ....project import get_persistent_dir, get_torch_devices, reporter

    # Flag to control whether to force re-run the pipeline without caching
    FORCE = False

    reporter.set(
        "doc_to_instruction.instantiation_subsample_datadreamer_output",
        "instantiation_subsample_datadreamer_output",
    )
    datadreamer_output_dir = get_persistent_dir(
        "instantiation_subsample_datadreamer_output",
        "doc_to_instruction.instantiation_subsample_datadreamer_output",
    )

    with DataDreamer(datadreamer_output_dir, log_date=True):
        # Get all templates
        templates_dataset = HFHubDataSource(
            "Get Templates Dataset",
            "fineinstructions/finetemplates",
            revision="7b7638debc46cc9ee6bec17ce9006e7838dbf10c",
            split="full",
        )
        templates_dataset_rows = templates_dataset.output.dataset

        # Get all expanded dataset
        expanded_dataset = HFHubDataSource(  # noqa: F841
            "Get expanded dataset",
            "fineinstructions-pretraining/ipt_fineinstructions_all",
            revision="d284d7bddc166004d44edb1ca66a4b777a795589",
            split="train",
            num_proc=10,
        )

        # Stratify by length
        LIMIT = 0.50
        PER_STRAT_DICT = {
            1: 944632,
            2: 1055765,
            3: 1495625,
            4: 1196500,
            5: 340500,
            6: 36497,
            7: 10874,
            8: 330250,
        }
        UPSAMPLE_STRAT = {1: 1, 2: 1, 3: 1, 4: 1, 5: 6, 6: 6, 7: 18, 8: 14}
        max_multiplier = {
            k: max(min(int(1.000 / LIMIT), v), 1) for k, v in UPSAMPLE_STRAT.items()
        }
        PER_STRAT_DICT = {
            k: int(v * LIMIT * max_multiplier[k]) for k, v in PER_STRAT_DICT.items()
        }
        UPSAMPLE_STRAT = {
            k: v
            if v == 1 or max_multiplier[k] == 1
            else max(int(v / max_multiplier[k]), 1)
            for k, v in UPSAMPLE_STRAT.items()
        }
        print("Limit:", LIMIT)
        print("Max Multiplier:", max_multiplier)
        print("UPSAMPLE_STRAT:", UPSAMPLE_STRAT)
        PER_STRAT = max(PER_STRAT_DICT.values())
        # stratification_1 = expanded_dataset.map(
        #     make_batched_filter(0, 300),
        #     lazy=True,
        #     batched=True,
        #     batch_size=400000,
        #     total_num_rows=len(expanded_dataset.output),
        #     name="Stratification_1",
        # ).take(PER_STRAT_DICT[1], lazy=False)
        stratification_1 = HFDatasetDataSource(
            "Stratification_1_direct",
            os.path.realpath(
                os.path.join(
                    datadreamer_output_dir, "stratification_1-take", "_dataset"
                )
            ),
        ).take(PER_STRAT_DICT[1], lazy=False)
        print("Strat 1", len(stratification_1.output))
        # stratification_2 = expanded_dataset.map(
        #     make_batched_filter(300, 600),
        #     lazy=True,
        #     batched=True,
        #     batch_size=400000,
        #     total_num_rows=len(expanded_dataset.output),
        #     name="Stratification_2",
        # ).take(PER_STRAT_DICT[2], lazy=False)
        stratification_2 = HFDatasetDataSource(
            "Stratification_2_direct",
            os.path.realpath(
                os.path.join(
                    datadreamer_output_dir, "stratification_2-take", "_dataset"
                )
            ),
        ).take(PER_STRAT_DICT[2], lazy=False)
        print("Strat 2", len(stratification_2.output))
        # stratification_3 = expanded_dataset.map(
        #     make_batched_filter(600, 900),
        #     lazy=False,
        #     batched=True,
        #     batch_size=400000,
        #     total_num_rows=len(expanded_dataset.output),
        #     name="Stratification_3",
        # ).take(PER_STRAT_DICT[3], lazy=False)
        stratification_3 = HFDatasetDataSource(
            "Stratification_3_direct",
            os.path.realpath(
                os.path.join(datadreamer_output_dir, "stratification_3", "_dataset")
            ),
        ).take(PER_STRAT_DICT[3], lazy=False)
        print("Strat 3", len(stratification_3.output))
        # stratification_4 = expanded_dataset.map(
        #     make_batched_filter(900, 1100),
        #     lazy=False,
        #     batched=True,
        #     batch_size=400000,
        #     total_num_rows=len(expanded_dataset.output),
        #     save_num_proc=64,
        #     name="Stratification_4",
        # ).take(PER_STRAT_DICT[4], lazy=False)
        stratification_4 = HFDatasetDataSource(
            "Stratification_4_direct",
            os.path.realpath(
                os.path.join(datadreamer_output_dir, "stratification_4", "_dataset")
            ),
        ).take(PER_STRAT_DICT[4], lazy=False)
        print("Strat 4", len(stratification_4.output))
        # stratification_5 = expanded_dataset.map(
        #     make_batched_filter(1100, 2000),
        #     lazy=False,
        #     batched=True,
        #     batch_size=400000,
        #     total_num_rows=len(expanded_dataset.output),
        #     save_num_proc=64,
        #     name="Stratification_5",
        # ).take(PER_STRAT_DICT[5], lazy=False)
        stratification_5 = HFDatasetDataSource(
            "Stratification_5_direct",
            os.path.realpath(
                os.path.join(datadreamer_output_dir, "stratification_5", "_dataset")
            ),
        ).take(PER_STRAT_DICT[5], lazy=False)
        print("Strat 5", len(stratification_5.output))
        # stratification_6 = expanded_dataset.map(
        #     make_code_filter(score=25, min=0, max=2000),
        #     lazy=False,
        #     batched=True,
        #     batch_size=400000,
        #     total_num_rows=len(expanded_dataset.output),
        #     name="Stratification_6",
        # ).take(PER_STRAT_DICT[6], lazy=False)
        stratification_6 = HFDatasetDataSource(
            "Stratification_6_direct",
            os.path.realpath(
                os.path.join(datadreamer_output_dir, "stratification_6", "_dataset")
            ),
        ).take(PER_STRAT_DICT[6], lazy=False)
        print("Strat 6", len(stratification_6.output))
        # stratification_7 = expanded_dataset.map(
        #     make_math_filter(score=6, min=0, max=2000),
        #     lazy=False,
        #     batched=True,
        #     batch_size=400000,
        #     total_num_rows=len(expanded_dataset.output),
        #     name="Stratification_7",
        # ).take(PER_STRAT_DICT[7], lazy=False)
        stratification_7 = HFDatasetDataSource(
            "Stratification_7_direct",
            os.path.realpath(
                os.path.join(datadreamer_output_dir, "stratification_7", "_dataset")
            ),
        ).take(PER_STRAT_DICT[7], lazy=False)
        print("Strat 7", len(stratification_7.output))
        # stratification_8 = expanded_dataset.map(
        #     make_long_context_filter(score_len=150, score_prop=0.30, max=6000),
        #     lazy=False,
        #     batched=True,
        #     batch_size=400000,
        #     total_num_rows=len(expanded_dataset.output),
        #     name="Stratification_8",
        # ).take(PER_STRAT_DICT[8], lazy=False)
        stratification_8 = HFDatasetDataSource(
            "Stratification_8_direct",
            os.path.realpath(
                os.path.join(datadreamer_output_dir, "stratification_8", "_dataset")
            ),
            force=True,
        ).take(PER_STRAT_DICT[8], lazy=False)
        print("Strat 8", len(stratification_8.output))

        llm_70 = ParallelLLM(
            *(
                [
                    OpenRouter(  # noqa: F841
                        model_name="meta-llama/llama-3.3-70b-instruct",
                        api_key=os.environ["OPENROUTER_API_KEY"],
                        base_url="https://openrouter.ai/api/v1",
                        cache_folder_path=os.path.join(
                            datadreamer_output_dir, ".cache"
                        ),
                    )
                    for i in range(64)
                ]
            )
        )
        os.environ["VLLM_DO_NOT_TRACK"] = "1"
        os.environ["DO_NOT_TRACK"] = "1"
        os.environ["VLLM_NO_USAGE_STATS"] = "1"
        os.environ["HF_HUB_DOWNLOAD_TIMEOUT"] = "120"
        os.environ["TORCHINDUCTOR_CACHE_DIR"] = os.path.realpath(
            os.path.join(datadreamer_output_dir, ".inductorcache")
        )
        local_llm_70 = VLLM(  # noqa: F841
            cache_folder_path=os.path.join(datadreamer_output_dir, ".cache"),
            model_name="RedHatAI/Llama-3.3-70B-Instruct-quantized.w8a8",
            device=get_torch_devices(),
            tensor_parallel_size=len(get_torch_devices()),
            disable_log_stats=True,
            enable_chunked_prefill=False,
            enable_prefix_caching=True,
            enforce_eager=False,
            disable_custom_all_reduce=False,
            gpu_memory_utilization=0.90,
            max_model_len=11500,
            max_num_seqs=64,
            max_num_batched_tokens=11504,
        )
        # Get highest quality in each stratification
        final_strats = []
        for strat_idx, strat in [
            (1, stratification_1),
            (2, stratification_2),
            (3, stratification_3),
            (4, stratification_4),
            (5, stratification_5),
            (6, stratification_6),
            (7, stratification_7),
            (8, stratification_8),
        ]:
            done_path = os.path.realpath(
                os.path.join(
                    datadreamer_output_dir,
                    f"add-strat_idx-and-upsample-{UPSAMPLE_STRAT[strat_idx]}-{strat_idx}-take",
                    "_dataset",
                )
            )
            if os.path.isdir(done_path):
                final_take = HFDatasetDataSource(
                    f"Final_Filtered_Strat_Take_{strat_idx}_direct", done_path
                )
            else:
                # Judge instruction
                judge_instruction_prompts = strat.map(
                    create_judge_instruction_prompts,
                    lazy=False,
                    name=f"Judge Instruction Prompt (({strat_idx}))",
                    force=FORCE,
                )
                judge_instruction_scores = Prompt(
                    name=f"Judge Instructions (({strat_idx}))",
                    inputs={"prompts": judge_instruction_prompts.output["prompt"]},
                    args={
                        "llm": llm_70,
                        "batch_size": 120,
                        "temperature": 1.0,
                        "top_p": 0.0,
                        "max_new_tokens": 5000,
                        "post_process": post_process_judge_instruction,
                        "lazy": False,
                    },
                    outputs={"generations": "score"},
                    force=FORCE,
                ).select_columns(["score"])

                # Filter
                strat = zipped(
                    strat,
                    judge_instruction_scores,
                    lazy=True,
                    name=f"Combine Strat (({strat_idx})) + Instruction Scores",
                )
                strat = strat.filter(
                    make_score_filter(
                        28, instruction_score=20, pair_score=15, pair2_score=2
                    ),
                    lazy=True,
                    total_num_rows=PER_STRAT,
                ).rename_column("score", "instruction_score", lazy=False)

                # Judge pair
                judge_pair_prompts = strat.map(
                    create_judge_pair_prompts,
                    lazy=False,
                    name=f"Judge Pair Prompt (({strat_idx}))",
                    force=FORCE,
                )
                judge_pair_scores = Prompt(
                    name=f"Judge Pairs (({strat_idx}))",
                    inputs={"prompts": judge_pair_prompts.output["prompt"]},
                    args={
                        "llm": llm_70,
                        "batch_size": 120,
                        "temperature": 1.0,
                        "top_p": 0.0,
                        "max_new_tokens": 5000,
                        "post_process": post_process_judge_pair,
                        "lazy": False,
                    },
                    outputs={"generations": "score"},
                    force=FORCE,
                ).select_columns(["score"])

                # Filter
                strat = zipped(
                    strat,
                    judge_pair_scores,
                    lazy=True,
                    name=f"Combine Strat (({strat_idx})) + Pair Scores",
                )
                strat = strat.filter(
                    make_score_filter(
                        23, instruction_score=20, pair_score=15, pair2_score=2
                    ),
                    lazy=False,
                    total_num_rows=PER_STRAT,
                ).rename_column("score", "pair_score", lazy=False)

                # Judge pair 2
                judge_pair_prompts = strat.map(
                    create_judge_pair_2_prompts,
                    lazy=False,
                    name=f"Judge Pair 2 Prompt (({strat_idx}))",
                    force=FORCE,
                )
                judge_pair_scores = Prompt(
                    name=f"Judge Pairs (({strat_idx})) 2",
                    inputs={"prompts": judge_pair_prompts.output["prompt"]},
                    args={
                        "llm": llm_70,
                        "batch_size": 120,
                        "temperature": 1.0,
                        "top_p": 0.0,
                        "max_new_tokens": 5000,
                        "post_process": post_process_judge_pair,
                        "lazy": False,
                    },
                    outputs={"generations": "score"},
                    force=FORCE,
                ).select_columns(["score"])

                # Filter
                strat = zipped(
                    strat,
                    judge_pair_scores,
                    lazy=True,
                    name=f"Combine Strat (({strat_idx})) + Pair Scores 2",
                )
                strat = strat.filter(
                    make_score_filter(
                        3, instruction_score=20, pair_score=15, pair2_score=2
                    ),
                    lazy=False,
                    total_num_rows=PER_STRAT,
                ).rename_column("score", "pair2_score", lazy=False)

                # Judge Match
                judge_match_prompts = strat.map(
                    partial(
                        create_judge_match_prompts,
                        templates_dataset_rows=templates_dataset_rows["template"],
                    ),
                    lazy=False,
                    name=f"Judge Template Match Prompt (({strat_idx}))",
                    force=FORCE,
                )
                match_judgements = Prompt(
                    name=f"Judge Template Matches (({strat_idx}))",
                    inputs={"prompts": judge_match_prompts.output["prompt"]},
                    args={
                        "llm": llm_70,
                        "batch_size": 120,
                        "temperature": 1.0,
                        "top_p": 0.0,
                        "max_new_tokens": 5000,
                        "post_process": post_process_judge_match,
                        "lazy": False,
                    },
                    outputs={"generations": "template_match_judgement"},
                    force=FORCE,
                ).select_columns(["template_match_judgement"])

                strat = zipped(
                    strat,
                    match_judgements,
                    lazy=False,
                    name=f"Combine Strat (({strat_idx})) + Match Judgements",
                )

                strat = strat.filter(
                    make_template_match_judgement_filter(
                        instruction_score=20, pair_score=15, pair2_score=2
                    ),
                    lazy=False,
                    total_num_rows=PER_STRAT,
                )

                # Add strat index and upsample
                strat = strat.map(
                    lambda batch, indices, strat_idx=strat_idx: {
                        "strat": [strat_idx] * UPSAMPLE_STRAT[strat_idx],
                        "uid": [
                            hashlib.blake2b(
                                str((batch["text"], batch["template_id"])).encode()
                            ).hexdigest()
                        ]
                        * UPSAMPLE_STRAT[strat_idx],
                        **{
                            key: batch[key] * UPSAMPLE_STRAT[strat_idx]
                            for key in batch
                            if key not in {"uid", "strat"}
                        },
                    },
                    batched=True,
                    batch_size=1,
                    with_indices=True,
                    lazy=False,
                    total_num_rows=PER_STRAT,
                    name=f"Add strat_idx and upsample (×{UPSAMPLE_STRAT[strat_idx]}) (({strat_idx}))",
                    force=FORCE,
                )

                final_take = strat.take(50000, lazy=False)
            print("Final Take", strat_idx, len(final_take.output))
            final_strats.append(final_take)

        # Convert to training format
        all_strats = concat(*final_strats, name="Combine all strats").shuffle(
            lazy=False, seed=42
        )
        all_strats = all_strats.map(
            partial(
                final_train_format_mapper,
                templates_dataset_rows=templates_dataset_rows["template"],
            ),
            lazy=False,
            name="Final Map",
            force=FORCE,
            remove_columns=["instantiated_instruction", "text"],
        )
        all_strats = zipped(
            *[
                all_strats.select_columns([cn], lazy=True)
                for cn in [
                    "strat",
                    "document",
                    "instruction",
                    "answer",
                    "template",
                    "shortened_instruction",
                    "shortened_answer",
                    "token_count",
                    "synthetic_token_count",
                    "instruction_score",
                    "pair_score",
                    "pair2_score",
                    "template_match_judgement",
                    "template_id",
                    "uid",
                ]
            ],
            name="Combine all strats and rearrange columns",
        )

        all_strats.publish_to_hf_hub(
            "fineinstructions/template_instantiator_training_v2", split="full"
        )
        from time import sleep

        sleep(99999999)


__all__ = ["instantiation_subsample"]
