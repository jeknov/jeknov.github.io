import re
from math import floor

# === DEFINITE MATH INDICATORS (TRIGGERS HARD OVERRIDE) ===
CERTAIN_MATH_REGEX = re.compile(
    r"|".join(
        [
            r"\bQ\.E\.D\.\b",  # conclusion of a proof
            r"\\begin\{(align|equation|proof|theorem|lemma|cases)\}",  # LaTeX math environments
            r"(?<!\$)(?:solve|equation|let|assume|given|show|prove)\s[^$]{0,15}\$(?!\d)[^$\n]{1,100}[^\\]?\$(?!\d)",  # inline LaTeX math
            r"\$\$[^\n$]{0,10}(\\[a-zA-Z]+|[a-zA-Z]\s*[\+\-\*/=^]|[0-9]{1,3}\s*[\+\-\*/=^])[^\n$]{0,100}\$\$",  # display LaTeX math
            r"∫.+?dx",  # integral expression
            r"\blim_{?[a-z→0∞]+}?[\s\S]*?=",  # limit notation
            r"\bsin\(|\bcos\(|\btan\(",  # trig functions
            r"\\frac\{[^}]+\}\{[^}]+\}",  # LaTeX fractions
        ]
    ),
    re.MULTILINE | re.DOTALL,
)

# === STRONG MATH-LIKE PATTERNS ===
STRONG_MATH_REGEX = re.compile(
    r"|".join(
        [
            r"\b(prove|show|derive|solve|calculate|simplify)\s+(that\s+)?\b",
            r"\b(theorem|lemma|corollary|proof)\b",
            r"\b(quadratic|polynomial|matrix|vector|scalar|logarithm|differentiable|continuous)\b",
            r"\bP\s*\(\s*[A-Z]\s*\)",  # probability notation
            r"\bn\s*!\b",  # factorial
            r"\bsigma\s*\(",  # summation notation
            r"\b∑\s*\(?\s*[^\n]{1,20}\s*\)?",  # unicode summation
            r"\b∀|\b∃",  # quantifiers
            r"\bn\s+choose\s+k\b",
            r"\b(x|y|z|n|m|a|b)\s*\^\s*\d+",  # exponent form
            r"\(\s*[a-z0-9+\-*/^ ]+\s*\)\s*/\s*\(\s*[a-z0-9+\-*/^ ]+\s*\)",  # fraction in plain text
            r"\bmod\s+\d+\b",  # modulo arithmetic
            r"(\d+(\.\d+)?|\bpi\b|\be\b)\s*≈\s*\d+(\.\d+)?",  # approximations
        ]
    ),
    re.IGNORECASE | re.MULTILINE,
)

# === WEAK MATH-LIKE STRUCTURES ===
WEAK_MATH_REGEX = re.compile(
    r"|".join(
        [
            r"[+\-*/^=<>]{2,}",  # multiple math operators
            r"\b(true|false|null|None)\b",  # not math per se, but can show up in logic/math
            r"^\s{4,}[\w=+\-*/^()]+",  # indented expression line
            r"`[^`\n]+`",  # inline code (can contain math)
            r"\b(if and only if|w\.l\.o\.g\.|without loss of generality)\b",
        ]
    ),
    re.IGNORECASE | re.MULTILINE,
)


# === COUNT LINES WITH STRUCTURED MATH SYMBOLS ===
def count_math_lines(text):
    lines = text.splitlines()
    return sum(
        1
        for line in lines
        if re.search(r"[=^√±∞∑∫{}\\]", line)
        or re.search(r"\b(prove|solve|let|assume)\b", line)
    )


# === MAIN HEURISTIC FUNCTION ===
def compute_math_score(text):
    if compute_code_score(text) > 5:
        return 0

    # Hard override for clear math signals
    if CERTAIN_MATH_REGEX.search(text):
        return 100

    score = 0
    has_latex_block = (
        bool(re.search(r"\$\$[^$]+\$\$", text, re.DOTALL))
        or "\\begin{equation}" in text
    )

    strong_matches = STRONG_MATH_REGEX.findall(text)
    weak_matches = WEAK_MATH_REGEX.findall(text)

    strong_score = len(strong_matches)
    weak_score = 0.5 * len(weak_matches)
    math_lines = count_math_lines(text)

    strong_signals = sum([strong_score >= 2, has_latex_block, math_lines >= 6])

    if strong_signals >= 2:
        score += strong_score + weak_score
        if math_lines >= 6:
            score += 2
        elif math_lines >= 2:
            score += 1
    else:
        score = 0  # not enough evidence to trust lone signals

    return floor(score)


#########################################################################################
#########################################################################################
#########################################################################################


# === DEFINITE CODE INDICATORS (TRIGGERS HARD OVERRIDE) ===
CERTAIN_CODE_REGEX = re.compile(
    r"|".join(
        [
            r"^#!\s*/usr/bin/env\s+\w+",
            r"^#!\s*/bin/(ba)?sh",
            r"^#!\s*/usr/(local/)?bin/(python|perl|ruby|node)",
            r"<code>.*?</code>",
            r"```(?:[a-zA-Z]+\n)?[\s\S]*?```",
            r"\bint\s+main\s*\([^)]*\)\s*{",
            r"\bpublic\s+(static\s+)?void\s+main\s*\(",
            r"\bfn\s+main\s*\(",
            r"\bdef\s+main\s*\(",
            r"\bfunction\s+\w+\s*\([^)]*\)\s*{",
            r"\b\w+\s+\w+\s*\([^)]*\)\s*{",
            r"\bCREATE\s+TABLE\s+\w+\s*\(",
            # Only match uppercase SELECT ... FROM with ≤3 words
            r"\bSELECT(?:\s+\w+){1,3}\s+FROM\b",
        ]
    ),
    re.MULTILINE | re.DOTALL,  # <-- IGNORECASE removed
)

# === STRONG CODE-LIKE PATTERNS (MULTI-TOKEN) ===
STRONG_REGEX = re.compile(
    r"|".join(
        [
            r"\b(def|function|fn)\s+\w+\s*\([^)]*\)\s*(:|{)",
            r"\bfunc\s+\w+\s*\([^)]*\)\s*(->|\{)",
            r"\b(public|private|protected)?\s*(static\s+)?\w+\s+\w+\s*\([^)]*\)\s*{",
            r"\b(class|struct|enum|interface|trait)\s+\w+(\([^)]*\))?\s*{?",
            r"\(.*?\)\s*=>\s*{?",
            r"\blambda\s+\w+\s*:\s*",
            r"\b(if|else if|while|for|switch)\s*\([^)]*\)\s*{",
            r"\b(elif|else|except|finally)\s*:\s*",
            r"\btry\s*:\s*\n\s*except",
            r"\bimport\s+\w+(\.\w+)*(\s+as\s+\w+)?",
            r"\bexport\s+(default\s+)?(function|class|const|let)\b",
            r"#include\s+[<\"]\w+(\.\w+)?[>\"]",
            r"\brequire\s*\(\s*['\"]\w+(['\"])?\s*\)",
            r"^\s*@\w+",
            r"^\s*\#\[\w+.*?\]",
            r"\b(let|var|const|mut|val)\s+\w+\s*(?::\s*\w+)?\s*=\s*",
            r"\b(print|echo|console\.log|System\.out\.println)\s*\(\s*['\"]",
            r"\bSELECT\s+.+?\s+FROM\s+\w+",
            r"\bINSERT\s+INTO\s+\w+",
            r"<[a-zA-Z]+\s*[^>]*?>.*?</[a-zA-Z]+>",
            r"\breturn\s+[\w\[\]\"']+",
            r"\bself\.\w+\s*=\s*",
            r"\bthis\.\w+\s*=",
            r"\bawait\s+\w+",
        ]
    ),
    re.MULTILINE,
)

# === WEAK CODE-LIKE STRUCTURES ===
WEAK_REGEX = re.compile(
    r"|".join(
        [
            r"#\s*\w+",
            r"//\s*\w+",
            r"/\*[\s\S]*?\*/",
            r"`[^`\n]+`",
            r"\b(null|None|true|false)\b",
            r"\$\{\w+\}",
            r"^\s{4,}\w+",
            r"\b(stdin|stdout|stderr|args)\b",
        ]
    ),
    re.MULTILINE,
)


# === COUNT LINES WITH STRUCTURED CODE SYMBOLS ===
def count_code_lines(text):
    lines = text.splitlines()
    return sum(
        1
        for line in lines
        if re.search(r"[;{}()]|(\breturn\b)|(\b(let|var|const)\s+)", line)
    )


# === MAIN HEURISTIC FUNCTION ===
def compute_code_score(text):
    # Hard override if definitely code
    if CERTAIN_CODE_REGEX.search(text):
        return 100

    score = 0

    has_code_block = (
        "```" in text or bool(re.search(r"<code>.*?</code>", text, re.DOTALL)) or False
    )

    strong_matches = STRONG_REGEX.findall(text)
    weak_matches = WEAK_REGEX.findall(text)

    strong_score = len(strong_matches)
    weak_score = 0.5 * len(weak_matches)
    code_lines = count_code_lines(text)

    # Apply multi-signal gating: don't return strong score alone
    strong_signals = sum([strong_score >= 2, has_code_block, code_lines >= 6])

    if strong_signals >= 2:
        score += strong_score + weak_score
        if code_lines >= 6:
            score += 2
        elif code_lines >= 2:
            score += 1
    else:
        score = 0  # not enough to trust weak or lone strong signals

    return floor(score)
