import concurrent.futures
import json
import os
import re
import string
from functools import lru_cache
from random import Random

from .heuristic_scores import compute_code_score, compute_math_score

INSTANTIATION_PROMPT = """
Below is a generic query template that can be used for instruction-tuning an LLM. It contains a template of a natural language user query, with template variables using <fi></fi> tags ("<fi>description of content that should go there....</fi>").

Here is an example of a simple template, although they can be much longer and more complex with many more variables:
I'm doing a project with a couple of other guys who have <fi>version or model of a tool</fi>, will it hurt if just I <fi>a few word description of getting the newest version or model of a tool</fi>. Will it <fi>a few word description of a potential negative result that could happen</fi> when we <fi>a few word description of interacting with team members with the tool</fi>? Will everything still be compatible as far as <fi>a few potential areas of potential incompatibility, comma-separated</fi>, etc.. goes. Should I be aware of anything about the new <fi>name of newest version or model of a tool</fi>?

These templates can then be instantiated from a *compatible* document (such as a web page, article, book, essay, etc.) that has contain enough information to both fill in all of the template variables and also has the answer to the query so that we can create grounded, realistic, diverse instruction-tuning questions and answers using a combination of the template + document.

Given the provided template + a compatible document we found below:

1. **Task:** Can you instantiate the template by filling in the <fi></fi> template variables to create a realistic instruction that could be realistically asked about the content/topic/subject described in the document?

2. **Section of the Document:** This template is most relevant to the {section}, try to make the instantiated instruction relevant to that specific portion of the document.

3. **Answerability and Template Incompatibility:** Whatever instruction/query/task you choose to create out of the template, ensure the compatible document has enough information to create a grounded answer to the query/task directly without any external knowledge or transformation / processing whatsoever. In very rare cases where the template is not remotely compatible at all (should be very rare, be creative to make the template work even if it is a stretch), you can return "Instruction template not compatible.".

4. **Requirements:** Only fill in the <fi></fi> variables. All of these variables must be replaced / instantiated. Do not edit any other parts of the template outside of the <fi></fi>, keep that text *exactly* verbatim the same (even if there are grammar errors / typos / extra or double whitespace or newlines / corrupted characters / informal writing).

5. **Standalone Perspective:** Should be written as a standalone question/query/task such that it is assumed the document is not provided and the question/query/task can still be understood.

6. **Return Format:** Return your single instantiated instruction template after "Instantiated Instruction:". Do not provide the answer or output anything else at all, just the single instantiated instruction.

<<<Instruction Template:
{template}
>>>
<<<Compatible Document:
{document}
>>>
""".strip()

INSTANTIATION_PROMPT_ROUND_2 = """
Below is a generic query template that can be used for instruction-tuning an LLM. It contains a template of a natural language user query, with template variables using <fi></fi> tags ("<fi>description of content that should go there....</fi>").

These templates can then be instantiated from a *compatible* document (such as a web page, article, book, essay, etc.) that has contain enough information to both fill in all of the template variables and also has the answer to the query so that we can create grounded, realistic, diverse instruction-tuning questions and answers using a combination of the template + document.

Given the provided template + an expected response (an answer excerpt pulled from a compatible document we found) + the entire compatible document we found below:

1. **Task:** Can you instantiate the template by filling in the <fi></fi> template variables to create a realistic instruction that could be realistically asked about the content/topic/subject described in the compatible document that would result in the "Expected Response" as the best possible answer/response to the instruction?

3. **Answerability and Template Incompatibility with Expected Response:** Whatever instruction/query/task you choose to create out of the template, ensure the "Expected Response" would be a reasonable grounded answer to the query/task directly without any external knowledge or transformation required whatsoever. In very rare cases where the template is not remotely compatible at all (should be very rare, be creative to make the template work even if it is a stretch), you can return "Instruction template not compatible.".

4. **Requirements:** Only fill in the <fi></fi> variables. All of these variables must be replaced / instantiated. Do not edit any other parts of the template outside of the <fi></fi>, keep that text *exactly* verbatim the same (even if there are grammar errors / typos / extra or double whitespace or newlines / corrupted characters / informal writing).

5. **Standalone Perspective:** Should be written as a standalone question/query/task such that it is assumed the document is not provided and the question/query/task can still be understood.

6. **Return Format:** Return your single instantiated instruction template after "Instantiated Instruction:". Do not output anything else at all, just the single instantiated instruction.

<<<Instruction Template:
{template}
>>>

<<<Expected Response:
{extraction}
>>>

<<<Entire Compatible Document:
{document}
>>>
""".strip()

INSTANTIATION_PROMPT_ROUND_3 = """
Below is a generic query template that can be used for instruction-tuning an LLM. It contains a template of a natural language user query, with template variables using <fi></fi> tags ("<fi>description of content that should go there....</fi>").

These templates can then be instantiated from a *compatible* document (such as a web page, article, book, essay, etc.) that has contain enough information to both fill in all of the template variables and also has the answer to the query so that we can create grounded, realistic, diverse instruction-tuning questions and answers using a combination of the template + document.

Given the provided template + a compatible document + an instantation of the template, please improve the template instantiation:

1. **Requirements:** Only fill in the <fi></fi> variables. All of these variables must be replaced / instantiated. Do not edit any other parts of the template outside of the <fi></fi>, keep that text *exactly* verbatim the same (even if there are grammar errors / typos / extra or double whitespace or newlines / corrupted characters / informal writing).

2. **Very Important: Standalone, but Realistic, Perspective:** Should be written as a standalone question/query/task such that it is assumed the document is not provided and the question/query/task can still be understood without having the document next to it. That means vague references should be improved to provide more detail in the instruction so it can be understood standalone. Ensure it is still realistic though.

3. **Return Format:** Return your single instantiated instruction template after "Instantiated Instruction:". Do not output anything else at all, just the single instantiated instruction.

<<<Instruction Template:
{template}
>>>

<<<Instantiated Instruction:
{instruction}
>>>

<<<Entire Compatible Document:
{document}
>>>
""".strip()

INSTANTIATION_PROMPT_ROUND_4 = """
Below is a generic query template that can be used for instruction-tuning an LLM. It contains a template of a natural language user query, with template variables using <fi></fi> tags ("<fi>description of content that should go there....</fi>").

These templates can then be instantiated from a *compatible* document (such as a web page, article, book, essay, etc.) that has contain enough information to both fill in all of the template variables and also has the answer to the query so that we can create grounded, realistic, diverse instruction-tuning questions and answers using a combination of the template + document.

Given the provided template + a compatible document + an instantation of the template, please improve the template instantiation:

1. **Focus on Accurate Numerical Details:** Focus on numerical details in the "Instantiated Instruction" where variables in the template were instantiated. Some of the numerical details in the instruction may not be correct for the expected response. Edit just those numerical details in the instantiated instruction (if they are not correct) to better fit "Expected Response" and ensure the "Expected Response" would be the most optimal answer for such an instruction.

2. **Return Format:** Return your single improved instantiated instruction template after "Instantiated Instruction:". Do not output anything else at all, just the single improved instantiated instruction.

<<<Instruction Template:
{template}
>>>

<<<Instantiated Instruction:
{instruction}
>>>

<<<Expected Response:
{answer}
>>>
""".strip()


ANSWER_EXTRACTION_PROMPT = """
Below is an instruction/query/task and a document that has enough information to answer the query so that we can create a grounded, realistic, diverse instruction-tuning dataset.

Given the provided instruction + a document we found below:

1. **Task:** Can you extract the closest substring from the document that could be considered an answer to the instruction or as close to an answer as possible? In cases where the instruction is not answerable directly the document at all (should be very rare, in most cases, be creative find a substring excerpt that is suitable as an indirect answer), you can return "Instruction not answerable with document.".

2. **Section of the Document:** This instruction is likely most relevant to the {section}, try to look in that area of the document for a relevant answer substring.

4. **Exact and Verbatim Extraction:** The extraction from the document must be *verbatim*: no formatting changes / spacing or whitespace changes / phrasing changes whatsoever. Do not use ellipsis or any other technique to shorten the extraction, the extracted substring must be output *verbatim* from the document.

5. **Substring Length:** You are encouraged to extract longer excerpts from the document (or even the entire document) if it would provide a fuller answer with more detail and nuance to the question, don't just try to extract a single sentence or a few sentences if that doesn't give the full answer without detail.

6. **Return Format:** Return your substring extraction after "Extraction:". Do not output anything else at all, just the verbatim substring extraction that is the closest to an answer to the instruction that exists in the document.

<<<Instruction:
{instruction}
>>>

<<<Document:
{document}
>>>
""".strip()

ANSWER_REPHRASE_PROMPT = """
Below is an instruction/query/task and a document that has enough information to answer the query so that we can create a grounded, realistic, diverse instruction-tuning dataset.

Given the provided instruction + a document + the extracted answer from the document we found below:

1. **Task:** Right now, the "Extracted Answer" is relevant content that may indirectly help answer the instruction, but doesn't read like and is not phrased like a direct answer. Can you please *minimally* rewrite / rephrase / rearrange the "Extracted Answer" as needed to directly be more phrased like a direct response to the instruction? You may also add a short bit of text before or after the "Extracted Answer" if needed, although it's preferable not to do that if not required.

2. **Requirements:** You are not allowed to radically change "Extracted Answer", this is a *minimal* rewrite / rephrase / rearrange to make the "Extracted Answer" read more like a direct response. At the end of your edits, >90% of n-grams should remain the exact same between the "New Extracted Answer" and the "Extracted Answer". It should be mostly *verbatim*: no formatting changes / spacing or whitespace changes / fixing of grammar or typos whatsoever.

3. **Return Format:** Return your edited version after "New Extracted Answer:". Do not output anything else at all.

<<<Instruction:
{instruction}
>>>

<<<Document:
{document}
>>>

<<<Extracted Answer:
{extraction}
>>>
""".strip()


def chunk_idx_to_section(chunk_idx):
    if chunk_idx == 0:
        return "entire document"
    elif chunk_idx == 1:
        return "first 20% of the document"
    elif chunk_idx == 2:
        return "second 20% (20%-40%) of the document"
    elif chunk_idx == 3:
        return "third 20% (40%-60%) of the document"
    elif chunk_idx == 4:
        return "fourth 20% (60%-80%) of the document"
    elif chunk_idx == 5:
        return "last 20% of the document"


def post_process_instantiation(x):
    if "Instruction template not compatible.".lower() in x.lower():
        return None
    divider = "Instantiated Instruction:"
    return (x.rsplit(divider, 1)[1] if divider in x else x).strip()


def post_process_answer_extraction(x):
    if "Instruction not answerable with document.".lower() in x.lower():
        return None
    divider = "Extraction:"
    return (x.rsplit(divider, 1)[1] if divider in x else x).strip()


def post_process_answer_rephrase(x):
    if "Instruction not answerable with document.".lower() in x.lower():
        return None
    divider = "New Extracted Answer:"
    return (x.rsplit(divider, 1)[1] if divider in x else x).strip()


def create_instantiation_prompts(row):
    return {
        "prompt": INSTANTIATION_PROMPT.format(
            section=chunk_idx_to_section(row["chunk_idx"]),
            template=row["template"],
            document=row["document"],
        )
    }


def create_instantiation_prompts_round_2(row):
    if row["instruction"] is None or row["extraction"] is None:
        return {
            "prompt": "Output 'Instruction template not compatible.' and nothing else at all."
        }
    return {
        "prompt": INSTANTIATION_PROMPT_ROUND_2.format(
            template=row["template"],
            extraction=row["extraction"],
            document=row["document"],
        )
    }


def create_instantiation_prompts_round_3(row):
    if row["instruction"] is None:
        return {
            "prompt": "Output 'Instruction template not compatible.' and nothing else at all."
        }
    return {
        "prompt": INSTANTIATION_PROMPT_ROUND_3.format(
            template=row["template"],
            instruction=row["instruction"],
            document=row["document"],
        )
    }


def create_instantiation_prompts_round_4(row):
    if row["instruction"] is None:
        return {
            "prompt": "Output 'Instruction template not compatible.' and nothing else at all."
        }
    if not any(
        [
            ((" " + s) in row["instruction"].lower())
            for s in [
                "0",
                "1",
                "2",
                "3",
                "4",
                "5",
                "6",
                "7",
                "8",
                "9",
                "one",
                "two",
                "three",
                "four",
                "five",
                "six",
                "seven",
                "eight",
                "nine",
                "ten",
            ]
        ]
    ):
        return {"prompt": "Output 'Keep the previous output.' and nothing else at all."}
    return {
        "prompt": INSTANTIATION_PROMPT_ROUND_4.format(
            template=row["template"],
            instruction=row["instruction"],
            answer=row["answer"],
        )
    }


def post_process_instantiation_round_4(x):
    if "Keep the previous output.".lower() in x.lower():
        return "Keep the previous output."
    if "Instruction template not compatible.".lower() in x.lower():
        return None
    divider = "Instantiated Instruction:"
    return (x.rsplit(divider, 1)[1] if divider in x else x).strip()


def keep_or_new(row):
    if row["new_instruction"] is None:
        return {"instruction": row["instruction"]}
    elif "Keep the previous output." in row["new_instruction"]:
        return {"instruction": row["instruction"]}
    else:
        return {"instruction": row["new_instruction"]}


def create_answer_extraction_prompts(row):
    if row["instruction"] is None:
        return {
            "prompt": "Output 'Instruction not answerable with document.' and nothing else at all."
        }
    return {
        "prompt": ANSWER_EXTRACTION_PROMPT.format(
            section=chunk_idx_to_section(row["chunk_idx"]),
            instruction=row["instruction"],
            document=row["document"],
        )
    }


def create_answer_rephrase_prompts(row):
    if row["instruction"] is None or row["extraction"] is None:
        return {
            "prompt": "Output 'Instruction not answerable with document.' and nothing else at all."
        }
    return {
        "prompt": ANSWER_REPHRASE_PROMPT.format(
            instruction=row["instruction"],
            document=row["document"],
            extraction=row["extraction"],
        )
    }


def shorten(document, text, min_excerpt_words=15, min_excerpt_hint=3):  # noqa: C901
    words = text.split(" ")
    num_document_words = len(document.split(" "))
    min_excerpt_words = max(min(min_excerpt_words, num_document_words), 8)
    output_words = []
    verbatim_streak = 0
    for w_idx, w in enumerate(words):
        last_word = w_idx == (len(words) - 1)
        output_words.append(w)
        next_streak_substring = " ".join(output_words[-(verbatim_streak + 1) :])
        next_streak_substring_in_document = next_streak_substring in document
        next_streak_substring_not_in_document = not (next_streak_substring_in_document)
        if next_streak_substring_in_document:
            verbatim_streak += 1
        if (
            next_streak_substring_not_in_document or last_word
        ) and verbatim_streak >= min_excerpt_words:
            if next_streak_substring_not_in_document:
                current_streak_words = output_words[-(verbatim_streak + 1) : -1]
            else:
                current_streak_words = output_words[-(verbatim_streak):]
            prefix_words = current_streak_words[:min_excerpt_hint]
            middle_words = current_streak_words[min_excerpt_hint:-min_excerpt_hint]
            suffix_words = current_streak_words[-min_excerpt_hint:]
            while matches := re.findall(
                re.escape(" ".join(prefix_words))
                + r" (.*?) "
                + re.escape(" ".join(suffix_words)),
                document,
                flags=re.DOTALL,
            ):
                if len(matches) == 0:
                    break
                elif len(matches) > 0:
                    if matches[0] == " ".join(middle_words):
                        if next_streak_substring_not_in_document:
                            output_words = output_words[: -(verbatim_streak + 1)]
                            output_words.append(
                                "<excerpt>"
                                + (" ".join(prefix_words))
                                + "<...>"
                                + (" ".join(suffix_words))
                                + "</excerpt>"
                            )
                            output_words.append(w)
                        else:
                            output_words = output_words[:-(verbatim_streak)]
                            output_words.append(
                                "<excerpt>"
                                + (" ".join(prefix_words))
                                + "<...>"
                                + (" ".join(suffix_words))
                                + "</excerpt>"
                            )
                        break
                    elif len(middle_words) >= 2:
                        prefix_words += [middle_words[0]]
                        suffix_words = [middle_words[-1]] + suffix_words
                        middle_words = middle_words[1:-1]
                    elif len(middle_words) == 1:
                        prefix_words += [middle_words[0]]
                        middle_words = middle_words[1:]
                    else:
                        break
        if next_streak_substring_not_in_document:
            verbatim_streak = 0
    return " ".join(output_words)


def expand(document, text):
    text = re.sub(
        r"<excerpt>(.*?)<\.\.\.([^>]{1}?)(.*?)</excerpt>",
        r"<excerpt>\1<...>\2\3</excerpt>",
        text,
    )  # Fix broken ellipsis
    excerpt_pattern = r"<excerpt>(.*?)<\.\.\.>(.*?)</excerpt>"
    matches = re.findall(excerpt_pattern, text, flags=re.DOTALL)
    replacements = {}
    for prefix, suffix in matches:
        orig_prefix, orig_suffix = prefix, suffix
        prefix_pre = ""
        while True:
            match = re.search(
                re.escape(prefix) + r"(.*?)" + re.escape(suffix),
                document,
                flags=re.DOTALL,
            )
            try:
                if match:
                    replacements[
                        f"<excerpt>{orig_prefix}<...>{orig_suffix}</excerpt>"
                    ] = prefix_pre + match.group(0)
                    break
                else:
                    if prefix not in document and len(prefix.split(" ")) > 1:
                        if prefix_pre == "":
                            prefix = (
                                prefix[:-1]
                                if prefix and prefix[-1] in string.punctuation
                                else prefix
                            )
                        prefix_pre = prefix.split(" ")[0] + " "
                        prefix = " ".join(prefix.split(" ")[1:])
                        continue
                    if suffix not in document and len(suffix.split(" ")) > 1:
                        suffix = " ".join(suffix.split(" ")[1:])
                        continue
                    return None
            except Exception:
                return None
    for old, new in replacements.items():
        text = text.replace(old, new)
    if "<...>" in text or "<excerpt" in text or "</excerpt" in text:
        return None
    return text


def excerpt_ratio(document, text):
    excerpt_pattern = r"<excerpt>.*?<\.\.\.>.*?</excerpt>"
    new_content = len(re.sub(excerpt_pattern, "", shorten(document, text)))
    all_content = len(text)
    excerpt_content = all_content - new_content
    try:
        return excerpt_content / all_content
    except ZeroDivisionError:
        return 0.0


def final_quality_filter(row):
    collapse_whitespace = lambda text: re.sub(r"\s+", " ", text).strip()  # noqa: E731

    # No errors
    no_errors = row["instruction"] is not None and row["answer"] is not None

    # All variables must be instantiated
    instantiated = no_errors and (
        "<fi>" not in row["instruction"] and "</fi>" not in row["instruction"]
    )

    if not instantiated or not no_errors:
        row["instruction"] = None
        return False

    # Must not be paraphrased
    starter = collapse_whitespace(
        row["template"][: row["template"].find("<fi>")]
        if "<fi>" in row["template"]
        else row["template"]
    )
    ender = collapse_whitespace(
        row["template"][row["template"].rfind("</fi>") + len("</fi>") :]
        if "</fi>" in row["template"]
        else ""
    )
    instruction_must_not_be_paraphrased = collapse_whitespace(
        row["instruction"]
    ).startswith(starter) and collapse_whitespace(row["instruction"]).endswith(ender)

    # Answer must be close to verbatim
    answer_close_to_verbatim = len(shorten(row["document"], row["answer"])) < 2048

    # Answer must have at least a single excerpt
    answer_has_excerpt = "<excerpt>" in shorten(row["document"], row["answer"])
    answer_is_mostly_excerpt = excerpt_ratio(row["document"], row["answer"]) >= 0.80

    return (
        instantiated
        and no_errors
        and instruction_must_not_be_paraphrased
        and answer_close_to_verbatim
        and answer_has_excerpt
        and answer_is_mostly_excerpt
    )


def final_quality_map(row):
    if row["instruction"] is None:
        row["chunk_idx"] = None
        row["instruction"] = None
        row["answer"] = None
        row["shortened_answer"] = None
    else:
        row["shortened_answer"] = shorten(row["document"], row["answer"])
    return row


JUDGE_INSTRUCTION_PROMPT = """
Here is an instruction for an LLM. Can you please score it on a scale of 1-5 on different dimensions for how useful this would be for instruction-tuning an LLM?

Here are some dimensions to not consider at all in your scoring:
- Factuality: These instructions are grounded in source documents and do not need to be evaluated for factuality.
- Verbosity: Extra verbose is fine.
- Bad or Messy Grammar, Typos, Fluency, Style: As long as the instruction are reasonably understandable, we don't care at all about the style or presentation.


Here are dimensions to rate it on (5 points each, total of 30):
- Task (5 points): Identify the broader category of task that is being asked (with this being a specific instance of that broader category of task). Consider what a successful output might look like for a different instance of that broader task. Come up with an example of instances of this broader category of task that might be challenging and not trivial as well as ones that are not challenging. Finally, consider whether this specific instance is a good instance representative of the complexity of the broader task category.
- Specificity (5 points): The instruction is specified enough to be answered without vagueness of what is being asked, asking for subjective opinions is totally okay, but the question should not contain unresolvable or highly vague anaphors or references or lack significant context.
- Triviality (5 points): The instruction is not a "degenerate example" of the task that is trivial or too easy. Degenerate cases of tasks often look like cases where nothing challenging needs to be done to perform the task ("Convert X to format Y" where X is already in the format Y or "Give me a summary of X" where X is already a reasonably short summary). 
- Answer Provided (5 points): The instruction text should absolutely not provide an answer after the task or indirectly/mistakenly/subtly hint to an answer or provide the answer anywhere in the instruction text.
- Repetition (5 points): The instruction should not repeat the same content over and over again or contain high amounts of repetition. If there is a lot of repetition or overlap rate near zero.
- Realistic Context or Document (5 points): If there is a context or document or some text content paired with the instruction inside the instruction text, it should appear highly realistic and not be trivial to solve the task on the text. If there is no context or document paired with the instruction, rate this a full 5 points.

Please explain your answer for each of the dimensions in depth. Then, only after the explanations, as the return format, place your total score out of 30 after "Total Score:" at the very end.

<<<Instruction:
{instruction}
>>>
""".strip()


def create_judge_instruction_prompts(row):
    return {
        "prompt": JUDGE_INSTRUCTION_PROMPT.format(
            instruction=row["instantiated_instruction"]
        )
    }


JUDGE_PAIR_PROMPT = """
Here is an instruction and answer pair for an LLM. Can you please score it on a scale of 1-5 on different dimensions for how useful this would be for instruction-tuning an LLM?

Here are some dimensions to not consider at all in your scoring:
- Factuality: The pair is grounded in source documents and do not need to be evaluated for factuality.
- Verbosity: Extra verbose is fine (if the task is not such that it requires precise length, terseness, or some exact content)
- Bad or Messy Grammar, Typos, Fluency, Style: As long as the instruction and answer is reasonably understandable, we don't care at all about the style or presentation.


Here are dimensions to rate it on (5 points each, total of 25):
- Task (5 points): Identify the broader category of task that is being asked (with this being a specific instance of that broader category of task). Consider what a successful output might look like for a different instance of that broader task. Come up with an example of instances of this broader category of task that might be challenging and not trivial as ones that are not challenging. Finally, consider whether this specific instance is a good input and output pair representative of the complexity of the broader task category.
- Completeness (5 points): The answer fully attends to every single component of the instruction and does not leave anything unaddressed. Extra verbosity is fine as long as the instruction is fully addressed (if the task is not such that it requires precise length, terseness, or some exact content).
- Triviality (5 points): The input and output pair is not a "degenerate example" of the task that is trivial or too easy. Degenerate cases of tasks often look like cases where nothing challenging needs to be done to perform the task ("Convert X to format Y" where X is already in the format Y or "Give me a summary of X" where X is already a reasonably short summary). 
- Answer Provided (5 points): The instruction text should absolutely not provide an answer after the task or indirectly/mistakenly/subtly hint to an answer or provide the answer anywhere in the instruction text.
- Repetition and Overlap (5 points): There should almost zero significant repetition (phrases, sentences, information or content) between the instruction and the answer. If there is a lot of repetition or overlap rate near zero.

Please explain your answer for each of the dimensions in depth. Then, only after the explanations, as the return format, place your total score out of 25 after "Total Score:" at the very end.

<<<Instruction:
{instruction}
>>>

<<<Answer:
{answer}
>>>
""".strip()


def create_judge_pair_prompts(row):
    return {
        "prompt": JUDGE_PAIR_PROMPT.format(
            instruction=row["instantiated_instruction"], answer=row["answer"]
        )
    }


JUDGE_PAIR_PROMPT_2 = """
Here is an instruction and answer pair for an LLM. Can you please score it on a scale of 1-3?


Score 1: The answer is not correct at all and does not follow the instructions of the task.
Score 2: The answer is partially correct and somewhat follows the task, but is far from a perfect example of the task.
Score 3: The answer ia near perfect example of performing the task in the instruction.


Please explain your answer in depth. Then, only after the explanation, as the return format, place your total score out of 3 after "Total Score:" at the very end.

<<<Instruction:
{instruction}
>>>

<<<Answer:
{answer}
>>>
""".strip()


def create_judge_pair_2_prompts(row):
    return {
        "prompt": JUDGE_PAIR_PROMPT_2.format(
            instruction=row["instantiated_instruction"], answer=row["answer"]
        )
    }


JUDGE_MATCH_PROMPT = """
Given a instruction-tuning prompt template (that is representative of a real world query or task a user might ask an LLM) and a document, please judge whether the document has enough information to both instantiate both the query template and instantiate a grounded response to create a high-quality training example grounded in the document.

Requirements:
1. Both Instruction and Response: The document must have enough information to be able to instantiate the template and provide a response (i.e. create both sides of the query-response pair for the purposes of creating a high-quality training example).
2. Every <fi></fi> Variable: Document must have enough information to instantiate every single variable (<fi></fi>) in the query template.
3. Enough Information: Document must have enough information to instantiate a strong grounded response.
4. Context/Document/Text: If there is a context or document or some text content paired with the instruction inside the instruction text (a summary, quote, excerpt, a kind of document), both an example of that content and an example of a response should directly appear in the document such that a grounded instantiation can be created. For example, for a template that says "Summarize the article below: <fi>article</fi>", the document must have a long article *and* a summary of that article to be able to create a grounded instantiation of both sides of the instruction.


Return Format: Write a short explanation of your judgement and why the document does or does not meet the requirements, then return your judgement as "yes" or "no" after "Answer: ". Return nothing else at all in your output.

Instruction-Tuning Prompt Template: {template}

Document: {document}
""".strip()


def create_judge_match_prompts(row, templates_dataset_rows):
    return {
        "prompt": JUDGE_MATCH_PROMPT.format(
            document=row["text"], template=templates_dataset_rows[row["template_id"]]
        )
    }


def post_process_judge_instruction(x):
    divider = "Total Score:"
    score_string = (x.rsplit(divider, 1)[1] if divider in x else x).strip()
    match = re.search(r"\d+", score_string)
    return int(match.group()) if match else 0


def post_process_judge_pair(x):
    divider = "Total Score:"
    score_string = (x.rsplit(divider, 1)[1] if divider in x else x).strip()
    match = re.search(r"\d+", score_string)
    return int(match.group()) if match else 0


def post_process_judge_match(x):
    divider = "Answer:"
    return "yes" in ((x.rsplit(divider, 1)[1] if divider in x else x).strip().lower())


def final_train_format_mapper(row, templates_dataset_rows):
    if row["template_match_judgement"]:
        return {
            "template": templates_dataset_rows[row["template_id"]],
            "instruction": row["instantiated_instruction"],
            "document": row["text"],
            "shortened_instruction": shorten(
                row["text"], row["instantiated_instruction"]
            ),
            "shortened_answer": shorten(row["text"], row["answer"]),
        }
    else:
        return {
            "template": templates_dataset_rows[row["template_id"]],
            "instruction": None,
            "document": row["text"],
            "answer": None,
            "shortened_instruction": None,
            "shortened_answer": None,
        }


def make_score_filter(score, instruction_score, pair_score, pair2_score):
    r = Random(42)

    def score_filter(row):
        keep = (
            "instruction_score" in row and row["instruction_score"] <= instruction_score
        ) or ("instruction_score" not in row and r.random() < 0.6)
        if "pair_score" in row and row["pair_score"] > pair_score:
            keep = False
        if "pair2_score" in row and row["pair2_score"] > pair2_score:
            keep = False
        return row["score"] >= score or keep

    return score_filter


def make_template_match_judgement_filter(instruction_score, pair_score, pair2_score):
    def judgement_filter(row):
        return (
            row["template_match_judgement"]
            and row["instruction_score"] > instruction_score
            and row["pair_score"] > pair_score
            and row["pair2_score"] > pair2_score
        ) or (
            not row["template_match_judgement"]
            and row["instruction_score"] <= instruction_score
            and row["pair_score"] <= pair_score
            and row["pair2_score"] <= pair2_score
        )

    return judgement_filter


def make_batched_filter(min=1, max=300):
    r = Random(42)

    def batched_filter(batch):
        prev = None
        for i in range(len(batch["text"])):
            if batch["text"][i] is None:
                if isinstance(prev, str):
                    batch["text"][i] = prev
            else:
                prev = batch["text"][i]

        keep = [
            text is not None
            and len(text) <= 15000
            and inst is not None
            and min <= len(inst) <= max
            for text, inst in zip(batch["text"], batch["instantiated_instruction"])
        ]

        filtered = {
            k: [v[i] for i in range(len(v)) if keep[i]] for k, v in batch.items()
        }

        if filtered:
            indices = list(range(len(next(iter(filtered.values())))))
            r.seed(json.dumps(batch["instantiated_instruction"]))
            r.shuffle(indices)
            filtered = {k: [v[i] for i in indices] for k, v in filtered.items()}

        return filtered

    return batched_filter


n_cpus = os.cpu_count()


def compute_scores_parallel(answers, scorer):
    return _compute_scores_parallel_cached(json.dumps(answers), scorer)


@lru_cache(maxsize=3)
def _compute_scores_parallel_cached(serialized_answers, scorer):
    answers = json.loads(serialized_answers)
    with concurrent.futures.ProcessPoolExecutor(max_workers=n_cpus) as executor:
        scores = list(executor.map(scorer, answers))
    return scores


def make_math_filter(score=10, min=1, max=300):
    base_filter = make_batched_filter(min=min, max=max)

    def batched_filter(batch):
        filtered = base_filter(batch)
        answers = filtered["answer"]

        scores = compute_scores_parallel(answers, compute_math_score)
        filtered_indices = [i for i, s in enumerate(scores) if s >= score]

        return {k: [v[i] for i in filtered_indices] for k, v in filtered.items()}

    return batched_filter


def make_code_filter(score=10, min=1, max=300):
    base_filter = make_batched_filter(min=min, max=max)

    def batched_filter(batch):
        filtered = base_filter(batch)
        answers = filtered["answer"]

        scores = compute_scores_parallel(answers, compute_code_score)
        filtered_indices = [i for i, s in enumerate(scores) if s >= score]

        return {k: [v[i] for i in filtered_indices] for k, v in filtered.items()}

    return batched_filter


def compute_overlap_score(pair):
    import pylcs

    instruction, document = pair
    match = pylcs.lcs2(instruction, document)
    return match, match / len(instruction)


def make_long_context_filter(score_len=500, score_prop=0.45, max=300):
    base_filter = make_batched_filter(min=score_len, max=max)

    def batched_filter(batch):
        filtered = base_filter(batch)
        inputs = list(zip(filtered["instantiated_instruction"], filtered["text"]))

        scores = compute_scores_parallel(inputs, compute_overlap_score)
        filtered_indices = [
            i for i, s in enumerate(scores) if s[0] >= score_len and s[1] >= score_prop
        ]

        return {k: [v[i] for i in filtered_indices] for k, v in filtered.items()}

    return batched_filter
