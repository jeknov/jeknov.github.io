import json
import os
import socket
from typing import Optional

import click
import torch
from datadreamer import DataDreamer
from datadreamer.steps import HFHubDataSource
from datadreamer.trainers import TrainHFFineTune
from datadreamer.utils.fs_utils import safe_fn
from huggingface_hub import HfApi, snapshot_download
from peft import LoraConfig
from transformers import AutoTokenizer

from .metrics import compute_metrics
from .preprocessing import (
    SFT_CHAT_TEMPLATE,
    create_input_and_output_columns,
    instruction_filter,
)


def download_subfolder(
    repo_id: str, subfolder: Optional[str] = None, repo_type: str = "model"
) -> str:
    allow_patterns = f"{subfolder}/*" if subfolder else None
    repo_path = snapshot_download(
        repo_id=repo_id, repo_type=repo_type, allow_patterns=allow_patterns
    )
    return os.path.join(repo_path, subfolder) if subfolder else repo_path


@click.option(
    "--dataset_name", "-d", type=str, required=True, help="The repository of the model"
)
@click.option(
    "--path",
    "-p",
    type=str,
    default=None,
    help="The path to the model in the repository",
)
@click.option(
    "--bz",
    type=int,
    default=1,
    show_default=True,
    help="The batch size per-GPU for training.",
)
def train_sft(ctx, dataset_name, path, bz):
    from ....project import (
        get_persistent_dir,
        get_torch_cpu_device,
        get_torch_devices,
        reporter,
    )

    if path.endswith("/"):
        path = path[:-1]
    dir_key = safe_fn(dataset_name + "/" + str(path))

    reporter.set(f"posttrain.train_sft.{dir_key}", f"sft_{dir_key}")
    datadreamer_output_dir = get_persistent_dir(
        f"sft_v2_{dir_key}", f"posttrain.train_sft.{dir_key}"
    )

    with DataDreamer(datadreamer_output_dir, log_date=True):
        MODEL_NAME = download_subfolder(repo_id=dataset_name, subfolder=path)
        PEFT_CONFIG = LoraConfig(r=8)
        EPOCHS = 30
        LEARNING_RATE = 1e-3
        BATCH_SIZE = bz
        DTYPE = torch.bfloat16 if len(get_torch_devices()) > 0 else torch.float32
        TRAIN_DEVICE = (
            get_torch_devices()
            if len(get_torch_devices()) > 0
            else get_torch_cpu_device()
        )
        GRADIENT_ACCUMULATION_STEPS = 8 // len(get_torch_devices())

        print("----------------------------------------")
        print("HOSTNAME:", socket.gethostname())
        print("EPOCHS:", EPOCHS)
        print("TRAIN_DEVICE:", TRAIN_DEVICE)
        print("DTYPE:", DTYPE)
        print("BATCH_SIZE:", BATCH_SIZE)
        print("GRADIENT_ACCUMULATION_STEPS:", GRADIENT_ACCUMULATION_STEPS)
        print("----------------------------------------")

        # Load instructions dataset
        instructions_dataset = HFHubDataSource(
            "Get SFT Dataset",
            "allenai/tulu-v3.1-mix-preview-4096-OLMoE",
            split="train",
            revision="a16e10fdbec0b3430b4cc1e1716bec5ec39d08ce",
        ).shuffle(seed=42, lazy=True)
        splits = instructions_dataset.splits(
            train_size=len(instructions_dataset.output) - 200, validation_size=200
        )
        instructions_train_dataset = splits["train"]
        instructions_validation_dataset = splits["validation"]

        # Filter out instructions from train dataset
        print(
            "Number of instructions in train set before filtering:",
            len(instructions_train_dataset.output),
        )
        instructions_train_dataset = instructions_train_dataset.filter(
            instruction_filter,
            lazy=False,
            name="Filter out Low-Quality Train Instantiations",
        )
        print(
            "Number of instructions in train set after filtering:",
            len(instructions_train_dataset.output),
        )

        # Filter out instructions from validation dataset
        print(
            "Number of instructions in validation set before filtering:",
            len(instructions_validation_dataset.output),
        )
        instructions_validation_dataset = instructions_validation_dataset.filter(
            instruction_filter,
            lazy=False,
            name="Filter out Low-Quality Validation Instantiations",
        )
        print(
            "Number of instructions in validation set after filtering:",
            len(instructions_validation_dataset.output),
        )

        # Map instructions to output format
        train_split = instructions_train_dataset.map(
            create_input_and_output_columns,
            lazy=False,
            batched=True,
            batch_size=1,
            save_num_proc=32,
            name="Create Input + Output Columns (Train)",
            remove_columns=set(
                instructions_train_dataset.output.column_names
            ).difference(["input", "output"]),
        ).shuffle(seed=42, lazy=False)
        validation_split = instructions_validation_dataset.map(
            create_input_and_output_columns,
            lazy=False,
            batched=True,
            batch_size=1,
            save_num_proc=32,
            name="Create Input + Output Columns (Validation)",
            remove_columns=set(
                instructions_validation_dataset.output.column_names
            ).difference(["input", "output"]),
        )

        # Preview training data
        test_tokenizer = AutoTokenizer.from_pretrained("gpt2", use_fast=True)
        test_tokenizer.chat_template = SFT_CHAT_TEMPLATE
        print("----------------------------------------")
        print(
            "Test Tokenizer Chat Template:",
            json.dumps(
                test_tokenizer.apply_chat_template(
                    [{"role": "user", "content": "Hello!"}], tokenize=False
                )
            ),
        )
        print(
            "Test Tokenizer Chat Template:",
            json.dumps(
                test_tokenizer.apply_chat_template(
                    [{"role": "user", "content": "Hello!"}],
                    tokenize=False,
                    add_generation_prompt=True,
                )
            ),
        )
        print(
            "Test Tokenizer Chat Template:",
            json.dumps(
                test_tokenizer.apply_chat_template(
                    [
                        {"role": "user", "content": "Hello!"},
                        {"role": "assistant", "content": "Hi back to you."},
                    ],
                    tokenize=False,
                    add_generation_prompt=False,
                )
            ),
        )
        print(
            "Test Tokenizer Chat Template:",
            json.dumps(
                test_tokenizer.apply_chat_template(
                    [
                        {"role": "user", "content": "Hello!"},
                        {"role": "assistant", "content": "Hi back to you."},
                        {"role": "user", "content": "What's up."},
                    ],
                    tokenize=False,
                    add_generation_prompt=False,
                )
            ),
        )
        print(
            "Test Tokenizer Chat Template:",
            json.dumps(
                test_tokenizer.apply_chat_template(
                    [
                        {"role": "user", "content": "Hello!"},
                        {"role": "assistant", "content": "Hi back to you."},
                        {"role": "user", "content": "What's up."},
                    ],
                    tokenize=False,
                    add_generation_prompt=True,
                )
            ),
        )
        test_tokenizer.chat_template = "<|begin_of_text|>" + SFT_CHAT_TEMPLATE
        print(
            "Test Tokenizer Chat Template:",
            json.dumps(
                test_tokenizer.apply_chat_template(
                    [{"role": "user", "content": "Hello!"}], tokenize=False
                )
            ),
        )
        print(
            "Test Tokenizer Chat Template:",
            json.dumps(
                test_tokenizer.apply_chat_template(
                    [{"role": "user", "content": "Hello!"}],
                    tokenize=False,
                    add_generation_prompt=True,
                )
            ),
        )
        print(
            "Test Tokenizer Chat Template:",
            json.dumps(
                test_tokenizer.apply_chat_template(
                    [
                        {"role": "user", "content": "Hello!"},
                        {"role": "assistant", "content": "Hi back to you."},
                    ],
                    tokenize=False,
                    add_generation_prompt=False,
                )
            ),
        )
        print(
            "Test Tokenizer Chat Template:",
            json.dumps(
                test_tokenizer.apply_chat_template(
                    [
                        {"role": "user", "content": "Hello!"},
                        {"role": "assistant", "content": "Hi back to you."},
                        {"role": "user", "content": "What's up."},
                    ],
                    tokenize=False,
                    add_generation_prompt=False,
                )
            ),
        )
        print(
            "Test Tokenizer Chat Template:",
            json.dumps(
                test_tokenizer.apply_chat_template(
                    [
                        {"role": "user", "content": "Hello!"},
                        {"role": "assistant", "content": "Hi back to you."},
                        {"role": "user", "content": "What's up."},
                    ],
                    tokenize=False,
                    add_generation_prompt=True,
                )
            ),
        )
        print("----------------------------------------")

        example_inputs = list(train_split.output.dataset["input"])
        example_outputs = list(train_split.output.dataset["output"])
        for i in range(5):
            train_input_example = example_inputs[i]
            train_output_example = example_outputs[i]
            print("----------------------------------------")
            print(
                f"Training Data Preview Input ({i}):\n", json.dumps(train_input_example)
            )
            print("----------------------------------------")
            print(
                f"Training Data Preview Output ({i}):\n",
                json.dumps(train_output_example),
            )
            print("----------------------------------------")
        found_multiple_user_messages = False
        for i in range(len(example_inputs)):
            if (
                json.dumps(example_inputs[i]).count(
                    "<|start_header_id|>user<|end_header_id|>"
                )
                > 1
            ):
                found_multiple_user_messages = True
                print(
                    "Training Data Preview Input has more than one user message, skipping further examples."
                )
                print(
                    f"Training Data Preview Input ({i}):\n",
                    json.dumps(example_inputs[i]),
                )
                print("----------------------------------------")
                print(
                    f"Training Data Preview Output ({i}):\n",
                    json.dumps(example_outputs[i]),
                )
                print("----------------------------------------")
                break
        assert found_multiple_user_messages, "No examples with multiple user messages"

        # Train End-to-End model
        trainer = TrainHFFineTune(
            "Post-Train SFT",
            model_name=MODEL_NAME,
            chat_prompt_template=None,
            peft_config=PEFT_CONFIG,
            device=TRAIN_DEVICE,
            dtype=DTYPE,
            fsdp=False,
        )
        trainer.train(
            train_input=train_split.output["input"],
            train_output=train_split.output["output"],
            validation_input=validation_split.output["input"],
            validation_output=validation_split.output["output"],
            epochs=EPOCHS,
            learning_rate=LEARNING_RATE,
            lr_scheduler_type="cosine_with_restarts",
            lr_scheduler_kwargs={"num_cycles": 5},
            warmup_steps=8000,
            batch_size=BATCH_SIZE,
            gradient_accumulation_steps=GRADIENT_ACCUMULATION_STEPS,
            compute_metrics=compute_metrics,
            batch_eval_metrics=True,
            early_stopping_patience=5,
            eval_strategy="steps",
            save_strategy="steps",
            eval_steps=1600,
            save_steps=1600,
            save_total_limit=2,
        )
        end_to_end_export_path = os.path.join(datadreamer_output_dir, "export_path")
        trainer.export_to_disk(end_to_end_export_path, adapter_only=False)
        tokenizer = AutoTokenizer.from_pretrained(end_to_end_export_path)
        tokenizer.chat_template = "<|begin_of_text|>" + SFT_CHAT_TEMPLATE
        tokenizer.save_pretrained(end_to_end_export_path)
        print("Uploading post-trained SFT model to Hugging Face Hub...")
        api = HfApi()
        api.upload_folder(
            folder_path=end_to_end_export_path,
            path_in_repo=path.replace("/hf", "") + "_sft/hf",
            repo_id=dataset_name,
            repo_type="model",
        )
        trainer.unload_model()

    # Sleep
    from time import sleep

    sleep(1000000)


__all__ = ["train_sft"]
