from transformers import AutoTokenizer

SFT_CHAT_TEMPLATE = "{% if not add_generation_prompt is defined %}{% set add_generation_prompt = false %}{% endif %}{% for msg in messages %}{% if msg.role=='user' %}{% if loop.index > 1 %}{{ '\\n\\n' }}{% endif %}<|start_header_id|>user<|end_header_id|>{{ '\\n' }}{{ msg.content }}{% elif msg.role=='assistant' %}{{ '\\n\\n<|start_header_id|>assistant<|end_header_id|>\\n' }}{{ msg.content }}{% endif %}{% endfor %}{% if add_generation_prompt %}{{ '\\n\\n<|start_header_id|>assistant<|end_header_id|>\\n' }}{% endif %}"

tokenizer = None


def create_input_and_output_columns(batch_of_columns):
    """
    Create input and output columns for the instruction dataset.
    """
    global tokenizer
    if tokenizer is None:
        tokenizer = AutoTokenizer.from_pretrained("gpt2", use_fast=True)
        tokenizer.chat_template = SFT_CHAT_TEMPLATE

    # Batch size is always one
    row = {k: v[0] for k, v in batch_of_columns.items()}
    messages = row["messages"]

    # Get each history-assistant message pair given a multiturn conversation
    pairs = []
    for i in range(len(messages) - 1):
        if messages[i]["role"] == "user" and messages[i + 1]["role"] == "assistant":
            pairs.append((messages[0 : i + 1], messages[i + 1]["content"]))

    return {
        "input": [
            tokenizer.apply_chat_template(
                p[0], tokenize=False, add_generation_prompt=True
            )
            for p in pairs
        ],
        "output": [p[1] for p in pairs],
    }


def instruction_filter(row):
    """
    Filter out low-quality instructions based on specific criteria.
    """
    return len(str(row["messages"])) < 8000
