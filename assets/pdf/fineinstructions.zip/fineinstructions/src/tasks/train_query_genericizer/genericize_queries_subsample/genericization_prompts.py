GENERICIZING_PROMPT = """
Genericize the following query into a re-usable template for instruction-tuning. Three examples have been provided below as well to help you better understand the best abstraction-level at which to genericize the query. Ensure the template retains the same natural language style as the original query (including slang, lowercasing, or misspellings), while allowing it to be reused across different domains or use-cases. 

1. **Retain the original query format:** Keep the exact same word-for-word structure, style, and tone of the query, but make it adaptable to new domains or situations.

2. **Replace domain-specific elements:** Identify and replace any terms or phrases that are specific to the original domain with placeholders. Use tags like `<fi>description of content</fi>` to mark these placeholders.

3. **Genericization-Level: ** Very important, ensure to genericize it at a level such that there are <= 20 of these placeholders, if you have too many template variables, it's way too specific of a template.

4. **Describe placeholders clearly:** Inside each tag, provide a detailed description of what type of content fits there. The description should allow for compatible, domain-agnostic substitutions. Avoid being overly generic and ensure the description provides enough context for similar specificity, length, and style as the original.

5. **Genericize few-shot examples in the query:** Genericize few-shot examples so that they can also be replaced with examples applicable to the domain the template will be applied to.

6. **Avoid examples in placeholder descriptions:** Write the descriptions without providing any examples. The standalone description should make it clear what type of content is expected.

7. **Return Format:** Return your explanation of why your genericization is good after "Explanation:". Return your template after "Template: ". Return nothing else at all in your output.

The goal is to create a reusable template that is flexible across domains while staying true to the original query's style and format.

Here are the three examples:

Example #1: Here is an example of genericizing a query about asking about how to implement some functionality when using a particular component:

Example Query:
I'm using a WebGrid to create a paged/sortable list in MVC3. I've created an AJAX enabled Delete button which makes the delete call via AJAX, after which I'd like it to remove the row from the table.

The way I'd like to achieve this is by having an `id` or `data-id` attribute on the `<tr>` in the table so that I can easily manipulate it using jQuery. However I can't work out how to add attributes to rows when using a WebGrid.

I know that attributes can easily set at the grid level like so:  

`@grid.GetHtml(htmlAttributes: new {{ id = "gridMapping", style = "width:100%;" }},`

However I don't know how to achieve the same at the row/column level.

Example Explanation:
This template is effective because it strikes the right balance between generalization and specificity, making it easy to instantiate from various documents across different domains. It uses broad, adaptable placeholders like "<fi>name of class, module, or component</fi>" instead of narrowing down to specific methods, error messages, or syntax, which can be found in many other contexts. For instance, rather than focusing on exact jQuery functions or specific MVC3 implementations, the template focuses on higher-level concepts like "a few word description of the desirable effect," which could apply to scenarios involving different technologies, from React's state management to a Python web framework. This allows students to use examples from various sources they can find online. In contrast, overly granular templates—such as specifying a particular method or error code—would lock the template into one specific context, making it much harder to find comparable examples in other domains. By avoiding this level of abstraction, the template remains flexible and reusable, encouraging the student to generalize their reasoning rather than get bogged down in details that may not apply elsewhere.

Example Template:
I'm using a <fi>name of class, module, or component</fi> to <fi>a few word description of the desirable effect</fi>. <fi>a sentence elaborating on further details of the implementation to achieve a more specific desired functionality</fi> 

The way I'd like to achieve this is by <fi>a few word description of an implementation plan to achieve the more specific desired functionality</fi>. However I can't work out how to <fi>a few word description of an issue being faced with the implementation plan to achieve the more specific desired functionality due to the class, module, or component being used</fi>.

I know that <fi>a few word description of how the issue could be fixed in a slightly different circumstance when not using the class, module, or component</fi>:  

`<fi>code demonstrating the solution in a slightly different circumstance when not using the class, module, or component</fi>`

However I don't know how to achieve the same <fi>a few word description of the current circumstance</fi>.

Example #2: Here is an example of genericizing a query about asking about incompatibilities if you upgrade a piece of software:

Example Query:
I'm doing a project with a couple of other guys who have vs10, will it hurt if just I upgrade to vs12. Will it hurt when we all check in on svn? Will everything still be compatible as far as wpf, mvc, etc.. goes. Should I be aware of anything about the new visual studio 2012?

Example Explanation:
The key strength of this template is its level of abstraction, which strikes the right balance to make it easily adaptable to a wide variety of contexts. By using broad placeholders like <fi>version or model of a tool</fi> and <fi>a few potential areas of incompatibility</fi>, the template can be filled with examples from many different fields without needing specific references to exact tools or steps. For instance, instead of abstracting down to a specific tool like "Visual Studio 2012" or "WPF," the template keeps it general with "a tool" and "compatibility issues" to ensure it could apply to anything from software upgrades to hardware changes. If the template were made too specific, such as by including detailed steps or exact model names, it would be hard to find real-world documents or examples that match, making the template too rigid and ineffective. For example, something like "Will upgrading from Photoshop CS5 to CS6 break my brushes?" is too detailed, while keeping it as "a version of a tool" makes it flexible enough to apply to a wide range of tool upgrades.

Example Template:
I'm doing a project with a couple of other guys who have <fi>version or model of a tool</fi>, will it hurt if just I <fi>a few word description of getting the newest version or model of a tool</fi>. Will it <fi>a few word description of a potential negative result that could happen</fi> when we <fi>a few word description of interacting with team members with the tool</fi>? Will everything still be compatible as far as <fi>a few potential areas of potential incompatibility, comma-separated</fi>, etc.. goes. Should I be aware of anything about the new <fi>name of newest version or model of a tool</fi>?

Example #3: Here is an example of genericizing a query about asking for SQL query modification:

Example Query:
I have two tables, say Users and Interviews. One user can have multiple interview records. 

```
Users
-----
UserID
FirstName
LastName

Interviews
----------
InterviewID
UserID
DateOfInterview

```

I want to get only the latest interview records. Here's my query

```
select u.UserID, firstname, lastname, max(DateOfInterview) as latestDOI 
from users u 
left join interviews i 
on u.UserID = i.UserID 
GROUP BY u.UserID, firstname, lastname
ORDER BY max(DateOfInterview) DESC

```

How do I update the query to return the InterviewID as well (i.e. the one which corresponds to max(DateOfInterview))?

Example Explanation:
This genericization is effective because it strikes the right balance between flexibility and clarity. By focusing on higher-level concepts—like "tables," "entities," and "desired results"—it can be easily instantiated from a wide variety of real-world examples. For instance, you can fill in the placeholders with common entities such as "Customers" and "Orders," "Students" and "Courses," or "Employees" and "Reviews." The template doesn’t go too granular (like specifying exact column names or specific SQL functions), which means it’s adaptable across many situations and domains. For example, instead of locking the template to something very domain-specific like "DateOfInterview," it leaves that open to any time-related column like "OrderDate" or "ReviewDate." Lower-level abstractions—such as focusing on specific SQL syntax or operations—would make the template harder to use because those details would only apply in certain contexts, making it difficult to find other, relevant examples online. So, by keeping the abstraction level at the right height, it ensures the template can easily be instantiated in many different scenarios without becoming overly tailored to a narrow use case.

Example Template:
I have two tables, say <fi>the name of the Table A</fi> and <fi>the name of the Table B</fi>. One <fi>name of entity stored in Table A</fi> can have multiple <fi>name of entity stored in Table B</fi> records. 

```
<fi>plain text representation of Table A schema</fi>

<fi>plain text representation of Table B schema</fi>

```

I want to get <fi>a few word description of initial desired result from the tables</fi>. Here's my query

```
<fi>an existing query over the tables that results in the initial desired result</fi>

```

How do I update the query to <fi>a few word description of additional requirements for the result</fi> as well (i.e. <fi>a few word description of further details about the additional requirements</fi>)?




Now do the same type of genericizing for this query.

Query:
{query}
""".strip()

GENERICIZING_PROMPT_ROUND_2_SLIGHTLY = """
Goal: Our goal is to genericize a real user query into a re-usable template for instruction-tuning. This template can then be instantiated by finding analogous situations / problems in different domains or circumstances.

Method: To do this, we replace pieces of the user's query with template variables (<fi>content description goes here...</fi> tags) that are variables that will get replaced with appropriate content matching the description to instantiate the template.

Example Query:
I'm doing a project with a couple of other guys who have vs10, will it hurt if just I upgrade to vs12. Will it hurt when we all check in on svn? Will everything still be compatible as far as wpf, mvc, etc.. goes. Should I be aware of anything about the new visual studio 2012?

Example Template:
I'm doing a project with a couple of other guys who have <fi>version or model of a tool</fi>, will it hurt if just I <fi>a few word description of getting the newest version or model of a tool</fi>. Will it <fi>a few word description of a potential negative result that could happen</fi> when we <fi>a few word description of interacting with team members with the tool</fi>? Will everything still be compatible as far as <fi>a few potential areas of potential incompatibility, comma-separated</fi>, etc.. goes. Should I be aware of anything about the new <fi>name of newest version or model of a tool</fi>?

Explanation of Abstraction-Level in Example Template:
The key strength of this template is its level of abstraction, which strikes the right balance to make it easily adaptable to a wide variety of contexts. By using broad placeholders like <fi>version or model of a tool</fi> and <fi>a few potential areas of incompatibility</fi>, the template can be filled with examples from many different fields without needing specific references to exact tools or steps. For instance, instead of abstracting down to a specific tool like "Visual Studio 2012" or "WPF," the template keeps it general with "a tool" and "compatibility issues" to ensure it could apply to anything from software upgrades to hardware changes. If the template were made too specific, such as by including detailed steps or exact model names, it would be hard to find real-world documents or examples that match, making the template too rigid and ineffective. For example, something like "Will upgrading from Photoshop CS5 to CS6 break my brushes?" is too detailed, while keeping it as "a version of a tool" makes it flexible enough to apply to a wide range of tool upgrades.

Problem: I have a template that is potentially too specific, narrow, and niche, that I would like you to further genericize if it is OR you can leave it exactly the same if you deem it is at a good abstraction level for re-usabilility.

The ideal template:
1. Doesn't have too many template variables (<fi></fi> tags). It's better for the template variables to replace longer spans of the original query than for there to be many template variables.
2. Has replaced *all* spans from the original query in the template that are specific to a certain domain or circumstance with a template variable.

You can help improve genericization by:
1. Expanding the span of the template variables slightly to replace more of the surrounding context in the user's original query that might be domain-specific and limit the template's reusability.
2. If there are a lot of template variables, merge template variables with nearby adjacent ones to make the template overall less complex and specific if it is very specific (useful if 5+ template variables, with highly specific conditions unlikely to be able to be instantiated from another analogous situation in a different domain or circumstance).
3. Make the content descriptions inside the <fi></fi> tags even more generic and less domain-specific to improve the template's reusability.
4. If multiple things similar items are being replaced by a template variable, refer to them as #1, #2, #3, etc.
5. Important: DO NOT change the template or template variables too radically, it's in almost final state. Just help expand/merge template variables very slightly, as needed, to further genericize the query.

Return the new template after "Template:" and return absolutely nothing else after it.

Query:
{query}

Original Template:
{template}
""".strip()

GENERICIZING_PROMPT_ROUND_2_AGGRESSIVE = """
Goal: Our goal is to genericize a real user query into a re-usable template for instruction-tuning. This template can then be instantiated by finding analogous situations / problems in different domains or circumstances.

Method: To do this, we replace pieces of the user's query with template variables (<fi>content description goes here...</fi> tags) that are variables that will get replaced with appropriate content matching the description to instantiate the template.

Example Query:
I'm doing a project with a couple of other guys who have vs10, will it hurt if just I upgrade to vs12. Will it hurt when we all check in on svn? Will everything still be compatible as far as wpf, mvc, etc.. goes. Should I be aware of anything about the new visual studio 2012?

Example Template:
I'm doing a project with a couple of other guys who have <fi>version or model of a tool</fi>, will it hurt if just I <fi>a few word description of getting the newest version or model of a tool</fi>. Will it <fi>a few word description of a potential negative result that could happen</fi> when we <fi>a few word description of interacting with team members with the tool</fi>? Will everything still be compatible as far as <fi>a few potential areas of potential incompatibility, comma-separated</fi>, etc.. goes. Should I be aware of anything about the new <fi>name of newest version or model of a tool</fi>?

Explanation of Abstraction-Level in Example Template:
The key strength of this template is its level of abstraction, which strikes the right balance to make it easily adaptable to a wide variety of contexts. By using broad placeholders like <fi>version or model of a tool</fi> and <fi>a few potential areas of incompatibility</fi>, the template can be filled with examples from many different fields without needing specific references to exact tools or steps. For instance, instead of abstracting down to a specific tool like "Visual Studio 2012" or "WPF," the template keeps it general with "a tool" and "compatibility issues" to ensure it could apply to anything from software upgrades to hardware changes. If the template were made too specific, such as by including detailed steps or exact model names, it would be hard to find real-world documents or examples that match, making the template too rigid and ineffective. For example, something like "Will upgrading from Photoshop CS5 to CS6 break my brushes?" is too detailed, while keeping it as "a version of a tool" makes it flexible enough to apply to a wide range of tool upgrades.

Problem: I have a template that is too specific, narrow, and niche, that I would like you to aggressively better genericize.

The ideal template:
1. Doesn't have too many template variables (<fi></fi> tags). It's better for the template variables to replace longer spans of the original query than for there to be many template variables.
2. Has replaced *all* spans from the original query in the template that are specific to a certain domain or circumstance with a template variable.
3. VERY IMPORTANT: Ensure to genericize it at a level such that there are <= 20 of these placeholders, if you have too many template variables, it's way too specific of a template.

You can help aggressively improve genericization by:
1. Expanding the span of the template variables to replace more of the surrounding context in the user's original query that might be domain-specific and limit the template's reusability.
2. If there are a lot of template variables, merge template variables with nearby adjacent ones to make the template overall less complex and specific if it is very specific (useful if 5+ template variables, with highly specific conditions unlikely to be able to be instantiated from another analogous situation in a different domain or circumstance).
3. Make the content descriptions inside the <fi></fi> tags even more generic and less domain-specific to improve the template's reusability.
4. If multiple things similar items are being replaced by a template variable, refer to them as #1, #2, #3, etc.
5. Important: This template currently has way too many template variables. Help expand/merge template variables, as needed, to further genericize the query.

Absolutely do not:
1. Do not change the phrasing or natural language structure away from the original query though, that is important for the diversity in the query. Just help expand/merge template variables.

Return the new template after "Template:" and return absolutely nothing else after it. Ensure to genericize it at a level such that there are <= 20 of these placeholders, if you have too many template variables, it's way too specific of a template.

Query:
{query}

Original Template:
{template}
""".strip()

GENERICIZING_EXPLANATION_PROMPT = """
Goal: Here is a real user query (provided after "Query:") and its genericized version (provided after "Template:"), designed to make it potentially applicable to other domains or situations and a re-usable template for instruction-tuning. Based on this, retrospectively write a detailed rationale for determining the appropriate level of abstraction when genericizing the query, ensuring the result is neither too granular with excessive variables nor too high-level and vague. 

Your Task: Begin with a concise summary of the original query, identifying its key elements and intent. Propose a hypothesis for how to generalize it effectively, focusing on achieving a balance that preserves clarity and adaptability. Then, analyze why the genericized version provided is a brilliant masterstroke of abstraction at just the right level, explaining how its structure, use of variables, and phrasing perfectly capture the original intent while making it widely applicable and without using too many template variables. Conclude with a step-by-step explanation of how you would abstract the query to arrive at the genericized version, specifying which parts should be variable and why, while ensuring the abstraction remains precise and practical.

Perspective: Write from the first-person persepective that the query has not been genericized yet and that you are providing a rationale for how to get to the perfect genericized version.

Important: Be very specific about each decision so someone else can learn how to genericize queries at this perfect level.

Return Format: Return the entire explanation as a single paragraph, no lists, bullets, or other structures. Return your explanation after "Explanation: ". Return nothing else at all in your output.

————————————————

Query:
{query}

Template:
{template}
"""


def genericizing_round_2_prompt_selector(gen_idx, row):
    if row["template"].count("<fi>") > 30:
        prompt_template = GENERICIZING_PROMPT_ROUND_2_AGGRESSIVE
    elif gen_idx >= 0:
        return {
            "prompt": """Please output the string "FineInstructions Skip" and return nothing else at all."""
        }
    else:
        prompt_template = GENERICIZING_PROMPT_ROUND_2_SLIGHTLY
    return {
        "prompt": prompt_template.format(query=row["query"], template=row["template"])
    }


def select_round_2_template_output(row):
    if "FineInstructions Skip" not in row["generations"]:
        row["template"] = row["generations"]
    return row


def post_process_template(x):
    divider = "Template:"
    return (x.rsplit(divider, 1)[1] if divider in x else x).strip()


def post_process_explanation(x):
    divider = "Explanation:"
    return (x.rsplit(divider, 1)[1] if divider in x else x).strip()
