import os
from functools import partial

from datadreamer import DataDreamer
from datadreamer.steps import HFHubDataSource, Prompt, zipped

from ....datadreamer_ext.openrouter import OpenRouter
from .annotation_prompts import (
    ANNOTATION_PROMPT_1,
    default_annotation_1,
    explode_annotation_into_columns,
    post_process_annotation_1,
)
from .compatibility_prompts import COMPATIBILITY_PROMPT, post_process_compatibility
from .genericization_prompts import (
    GENERICIZING_EXPLANATION_PROMPT,
    GENERICIZING_PROMPT,
    genericizing_round_2_prompt_selector,
    post_process_explanation,
    post_process_template,
    select_round_2_template_output,
)


def genericize_queries_subsample(ctx):
    from ....project import get_persistent_dir, reporter

    # Flag to control whether to force re-run the pipeline without caching
    FORCE = False

    reporter.set(
        "genericize_queries_subsample.datadreamer_output", "datadreamer_output"
    )
    datadreamer_output_dir = get_persistent_dir(
        "datadreamer_output", "genericize_queries_subsample.datadreamer_output"
    )

    with DataDreamer(datadreamer_output_dir):
        llm_70 = OpenRouter(
            model_name="meta-llama/llama-3.3-70b-instruct",
            api_key=os.environ["OPENROUTER_API_KEY"],
            base_url="https://openrouter.ai/api/v1",
        )

        # Load real queries dataset
        real_queries_dataset = HFHubDataSource(
            "Get Sub-sample of Real Queries",
            "fineinstructions/real_queries_subsample",
            split="full",
        )

        # Get "query" column
        queries = real_queries_dataset.select_columns(["query"])

        # Genericize queries
        genericizing_prompts = queries.map(
            lambda row: {"prompt": GENERICIZING_PROMPT.format(query=row["query"])},
            lazy=False,
            name="Create Genericizing Prompts",
            force=FORCE,
        )
        genericized_queries = Prompt(
            name="Generate Genericized Queries",
            inputs={"prompts": genericizing_prompts.output["prompt"]},
            args={
                "llm": llm_70,
                "batch_size": 120,
                "temperature": 1.0,
                "top_p": 0.0,
                "max_new_tokens": 10000,
                "post_process": post_process_template,
            },
            outputs={"generations": "template"},
            force=FORCE,
        ).select_columns(["template"], name="Get Genericized Queries")
        queries_and_templates = zipped(
            queries, genericized_queries, name="Combine queries + templates"
        )
        genericizing_prompts_round_2 = queries_and_templates.map(
            partial(genericizing_round_2_prompt_selector, -1),
            lazy=False,
            name="Create Genericizing Prompts (round 2)",
            force=FORCE,
        )
        genericized_queries = Prompt(
            name="Generate Genericized Queries (Round 2)",
            inputs={"prompts": genericizing_prompts_round_2.output["prompt"]},
            args={
                "llm": llm_70,
                "batch_size": 120,
                "temperature": 1.0,
                "top_p": 0.0,
                "max_new_tokens": 10000,
                "post_process": post_process_template,
            },
            outputs={"generations": "template"},
            force=FORCE,
        ).select_columns(["template"], name="Get Genericized Queries (round 2)")
        for gen_idx, gen_attempt in enumerate(["b", "c", "d"]):
            queries_and_templates = zipped(
                queries, genericized_queries, name="Combine queries + templates"
            )
            genericizing_prompts_round_attempt = queries_and_templates.map(
                partial(genericizing_round_2_prompt_selector, gen_idx),
                lazy=False,
                name=f"Create Genericizing Prompts (round 2{gen_attempt})",
                force=FORCE,
            )
            genericized_queries = Prompt(
                name=f"Generate Genericized Queries (Round 2{gen_attempt})",
                inputs={"prompts": genericizing_prompts_round_attempt.output["prompt"]},
                args={
                    "llm": llm_70,
                    "batch_size": 120,
                    "temperature": 1.0,
                    "top_p": 0.0,
                    "max_new_tokens": 10000,
                    "post_process": post_process_template,
                },
                outputs={"generations": "generations"},
                force=FORCE,
            ).select_columns(
                ["generations"], name=f"Get Genericized Queries (round 2{gen_attempt})"
            )
            round_2_output = zipped(
                queries_and_templates,
                genericized_queries,
                name=f"Combine Inputs + Outputs (round 2{gen_attempt})",
            )
            genericized_queries = round_2_output.map(
                select_round_2_template_output,
                lazy=False,
                name=f"Select correct output  (round 2{gen_attempt})",
                force=FORCE,
            ).select_columns(["template"])

        # Generate explanations
        queries_and_templates = zipped(
            queries, genericized_queries, name="Combine queries + templates"
        )
        genericizing_explanation_prompts = queries_and_templates.map(
            lambda row: {
                "prompt": GENERICIZING_EXPLANATION_PROMPT.format(
                    query=row["query"], template=row["template"]
                )
            },
            lazy=False,
            name="Create Genericizing Explanation Prompts",
            force=FORCE,
        )
        genericization_explanations = Prompt(
            name="Generate Genericization Explanations",
            inputs={"prompts": genericizing_explanation_prompts.output["prompt"]},
            args={
                "llm": llm_70,
                "batch_size": 120,
                "temperature": 1.0,
                "top_p": 0.0,
                "max_new_tokens": 1000,
                "post_process": post_process_explanation,
            },
            outputs={"generations": "template_explanation"},
            force=FORCE,
        ).select_columns(
            ["template_explanation"], name="Get Genericization Explanations"
        )

        # Describe compatible documents
        compatibility_prompts = genericized_queries.map(
            lambda row: {
                "prompt": COMPATIBILITY_PROMPT.format(template=row["template"])
            },
            lazy=False,
            name="Create Compatibility Prompts",
            force=FORCE,
        )
        compatible_document_descriptions = Prompt(
            name="Generate Compatible Document Descriptions",
            inputs={"prompts": compatibility_prompts.output["prompt"]},
            args={
                "llm": llm_70,
                "batch_size": 120,
                "temperature": 1.0,
                "top_p": 0.0,
                "max_new_tokens": 500,
                "post_process": post_process_compatibility,
            },
            outputs={"generations": "compatible_document_description"},
            force=FORCE,
        ).select_columns(
            ["compatible_document_description"],
            name="Get Compatible Document Descriptions",
        )

        # Annotate the templates
        templates_and_descriptions = zipped(
            genericized_queries,
            compatible_document_descriptions,
            name="Combine templates + compatible document descriptions",
        )
        annotation_1_prompts = templates_and_descriptions.map(
            lambda row: {
                "prompt": ANNOTATION_PROMPT_1.format(
                    template=row["template"],
                    description=row["compatible_document_description"],
                )
            },
            lazy=False,
            name="Create Annotation Prompts",
            force=FORCE,
        )
        annotations_1 = Prompt(
            name="Generate Annotations",
            inputs={"prompts": annotation_1_prompts.output["prompt"]},
            args={
                "llm": llm_70,
                "batch_size": 120,
                "temperature": 1.0,
                "top_p": 0.0,
                "max_new_tokens": 4000,
                "post_process": post_process_annotation_1,
            },
            outputs={"generations": "annotation_object"},
            force=False,
        ).map(
            explode_annotation_into_columns,
            lazy=False,
            name="Create Annotation Columns",
            force=FORCE,
            remove_columns=["prompts", "annotation_object"],
        )

        # Combine all columns
        combined = zipped(
            real_queries_dataset.select_columns(["source_name", "query"]),
            genericized_queries,
            compatible_document_descriptions,
            annotations_1.select_columns(
                [k for k in default_annotation_1 if not k.endswith("_explanation")]
            ),
            genericization_explanations,
            annotations_1.select_columns(
                [k for k in default_annotation_1 if k.endswith("_explanation")]
            ),
            real_queries_dataset.select_columns(
                ["language", "source", "metadata", "stratify_key"]
            ),
            name="Combine all columns",
        )
        combined.publish_to_hf_hub(
            "fineinstructions/templates_raw_subsample", split="full"
        )


__all__ = ["genericize_queries_subsample"]
