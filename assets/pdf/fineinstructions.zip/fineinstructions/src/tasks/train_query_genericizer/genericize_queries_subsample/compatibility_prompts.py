COMPATIBILITY_PROMPT = """
Below is a generic query template that can be used for instruction-tuning an LLM. It contains a template of a natural language user query, with template variables using <fi></fi> tags ("<fi>description of content that should go there....</fi>").

Here is an example of a simple template, although they can be much longer and more complex with many more variables:
I'm doing a project with a couple of other guys who have <fi>version or model of a tool</fi>, will it hurt if just I <fi>a few word description of getting the newest version or model of a tool</fi>. Will it <fi>a few word description of a potential negative result that could happen</fi> when we <fi>a few word description of interacting with team members with the tool</fi>? Will everything still be compatible as far as <fi>a few potential areas of potential incompatibility, comma-separated</fi>, etc.. goes. Should I be aware of anything about the new <fi>name of newest version or model of a tool</fi>?

These templates can then be instantiated from a *compatible* document (such as a web page, article, book, essay, etc.) that has contain enough information to both fill in all of the template variables and also has the answer to the query so that we can create grounded, realistic, diverse instruction-tuning questions and answers using a combination of the template + document.

Given the provided template:

1. **Task:** Can you write a single paragraph (3-10 sentences) that broadly summarizes what kinds of documents may be compatible to instantiate this template *and* would also provide an answer to the query?

2. **Requirements for Compatibility:** Ensure that the description exhaustively captures all requirements the document must have to fill in every single <fi></fi> template variable and in order to provide a response the query.

3. **Ensure Maximal Compatibility with Abstract Requirements:** Think broadly and abstractly, don't describe a single, narrow kind of document that is compatible with the template. Try to describe all possible kinds of documents (web page, article, book, essay, etc.), that might come from various domains that could be useful in instantiating the template. In very abstract terms, describe the general requirements needed of a document to to fill in every single template variable and provide an answer to the query.

4. **Do not mention the template:** Do not directly reference the instruction-tuning "template" or "query" at all, don't reference "compatible" or "compatibility", don't reference "instantiation", don't reference instruction-tuning, don't reference <fi></fi> tags. This description will be used judge documents independently for compatibility with the template and the template will not be provided when judging compatibility.

5. **Use As Few Sentences As Needed:** While you can output 3-10 sentences, fewer sentences is preferable, if and only if, *all* requirements needed of a document to to fill in every single template variable and provide an answer to the query can fit within fewer sentences.

6. **Return Format:** Return your paragraph after "Compatible Document Description:". Ensure your answer starts with "A document that...". Do not use bullet points or lists, return your response as sentences in a single paragraph.

Template:
{template}
"""


def post_process_compatibility(x):
    divider = "Compatible Document Description:"
    return (x.rsplit(divider, 1)[1] if divider in x else x).strip()
