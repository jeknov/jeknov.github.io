import json
import re

ANNOTATION_PROMPT_1 = """
Below is a generic query template that can be used for instruction-tuning an LLM. It contains a template of a natural language user query, with template variables using <fi></fi> tags ("<fi>description of content that should go there....</fi>").

Here is an example of a simple template, although they can be much longer and more complex with many more variables:
I'm doing a project with a couple of other guys who have <fi>version or model of a tool</fi>, will it hurt if just I <fi>a few word description of getting the newest version or model of a tool</fi>. Will it <fi>a few word description of a potential negative result that could happen</fi> when we <fi>a few word description of interacting with team members with the tool</fi>? Will everything still be compatible as far as <fi>a few potential areas of potential incompatibility, comma-separated</fi>, etc.. goes. Should I be aware of anything about the new <fi>name of newest version or model of a tool</fi>?

These templates can then be instantiated from a *compatible* document (such as a web page, article, book, essay, etc.) that has contain enough information to both fill in all of the template variables and also has the answer to the query so that we can create grounded, realistic, diverse instruction-tuning questions and answers using a combination of the template + document.

Given the provided template, produce a single JSON object between ``` and ``` with the following keys and values.
1. Key: qa_or_tasky
   Type: string (must be one of "tasky" or "qa")
   Value: Classify whether the query in this template (if instantiated) is asking someone or an LLM to perform some actual task ("tasky") (ex. "Can you rewrite this to be more...?" or "Can you suggest...?" or "Do you have any suggestions...?" or "Given the document, can you answer the following question....?" or "I want...") v.s. just requesting an answer to a simple, factoid question ("qa") (ex. "What is the capital of...?" or "How many meters in a foot...?" or "Who did Brad Pitt date in...?"). The key difference here is that for "qa" the answer likely already exists somewhere online if Google-d, where as for a task, something creative has to be done with pre-existing knowledge or something new and unique has to be created on-the-fly to respond to the task.

2. Key: qa_or_tasky_explanation
   Type: string
   Value: A short, single sentence, explaining why you made the choice for `qa_or_tasky`.

3. Key: realistic
   Type: boolean
   Value: Whether or not the query in this template (if instantiated) is something someone would realistically input into ChatGPT (for example, just random spam or babble should be false).

4. Key: realistic_explanation
   Type: string
   Value: A short, single sentence, explaining why you made the choice for `realistic`.

5. Key: conversational
   Type: boolean
   Value: Is this just a conversational message? i.e. A conversational message is one that only is "chatting" with the LLM or querying the LLM's personal subjective beliefs or subjective opinions and does not actually ask about some task like advice, classification, generation, information retrieval, knowledge recall, question answering, etc.

6. Key: conversational_explanation
   Type: string
   Value: A short, single sentence, explaining why you made the choice for `conversational`.

7. Key: task_type_open
   Type: string
   Value: In the mandatory format, using no more than 8 words, describe what task is being asked of the LLM in the query template. The mandatory format is you start your answer with a verb (extract the *exact* action verb used in the template) then follow with a modifier/prepositonal phrase (...about..., ...for..., ...in..., etc.) with additional details, for example, "Provide advice about choosing between two items".

8. Key: task_type_open_explanation
   Type: string
   Value: A short, single sentence, explaining why you made the choice for `task_type_open_explanation`.
   
9. Key: task_type_closed
   Type: string (must be one of "text_generation", or "code_generation")
   Value: Classify the closest task being asked of by the query in this template (if instantiated).

10. Key: task_type_closed_explanation
    Type: string
    Value: A short, single sentence, explaining why you made the choice for `task_type_closed`.

11. Key: difficulty
    Type: float (must be >=0.0 and <=1.0)
    Value: How difficult is the query in this template (if instantiated) for a state-of-the-art, frontier LLM like ChatGPT to complete based on the skills / reasoning abilities the task requires? What would be the percentage rate of failure from 0.0 to 1.0. (0.0 = would always succeed, 1.0 = would always fail)

12. Key: difficulty_explanation
    Type: string
    Value: A short, single sentence, explaining why you made the choice for `difficulty`.

13. Key: compatibility
    Type: float (must be >=0.0 and <=100.0, come up with a highly precise (to the decimal point) estimate like 5.46% or 0.00016%, do not approximate)
    Value: Approximately what percentage of documents in CommonCrawl would be compatible with this template? To guide your estimate, here is what various magnitudes would be: 0% (no pages)...0.000000X% (ones of pages)...0.00000X% (tens of pages)...100% (billions of pages).

14. Key: compatibility_explanation
    Type: string
    Value: A short, single sentence, explaining why you made the percentage estimate for `compatibility` (analyze like McKinsey consultant).

15. Key: query_frequency
    Type: float (must be >=0.0 and <=100.0, come up with a highly precise (to the decimal point) estimate like 5.46% or 0.00016%, do not approximate)
    Value: Approximately what percentage of queries to ChatGPT or the ChatGPT API in a year would look something like the query in this template (if instantiated)? To guide your estimate, here is what various magnitudes would be: 0% (no requests)...0.000000X% (ones of requests)...0.00000X% (tens of requests)...100% (billions of requests).

16. Key: query_frequency_explanation
    Type: string
    Value: A short, single sentence, explaining why you made the percentage estimate  for `query_frequency` (analyze like McKinsey consultant).

17. Key: is_knowledge_recall
    Type: boolean
    Value: Does the task being asked of by the query in this template (if instantiated) require retrieving / recalling some knowledge in order to answer it?

18. Key: is_knowledge_recall_explanation
    Type: string
    Value: A short, single sentence, explaining why you made the choice for `is_knowledge_recall`.

19. Key: is_reasoning
    Type: boolean
    Value: Does the task being asked of by the query in this template (if instantiated) require complex reasoning over some knowledge in order to answer it?

20. Key: is_reasoning_explanation
    Type: string
    Value: A short, single sentence, explaining why you made the choice for `is_reasoning`.

21. Key: is_code
    Type: boolean
    Value: Does the task being asked of by the query in this template (if instantiated) involve computer code / programming languages?

22. Key: is_code_explanation
    Type: string
    Value: A short, single sentence, explaining why you made the choice for `is_code`.

23. Key: is_math
    Type: boolean
    Value: Does the task being asked of by the query in this template (if instantiated) involve math?

24. Key: is_math_explanation
    Type: string
    Value: A short, single sentence, explaining why you made the choice for `is_math`.

25. Key: is_science
    Type: boolean
    Value: Does the task being asked of by the query in this template (if instantiated) involve science, science rearch, or scientific topics?

26. Key: is_science_explanation
    Type: string
    Value: A short, single sentence, explaining why you made the choice for `is_science`.

27. Key: is_medicine
    Type: boolean
    Value: Does the task being asked of by the query in this template (if instantiated) involve medicine, healthcare, or medical science topics?

28. Key: is_medicine_explanation
    Type: string
    Value: A short, single sentence, explaining why you made the choice for `is_medicine`.

29. Key: is_personal_life
    Type: boolean
    Value: Does the task being asked of by the query in this template (if instantiated) involve personal life topics?

30. Key: is_personal_life_explanation
    Type: string
    Value: A short, single sentence, explaining why you made the choice for `is_personal_life`.

31. Key: is_agenty
    Type: boolean
    Value: Does the task being asked of by the query in this template (if instantiated) have overlap with the core skills that an LLM agent automating computer tasks might need to reasonably perform? (future planning, assessing the state of an environment and making inferences, understanding negative and positive feedback, backtracking and re-formulating a new plan, understanding when a goal has been reached, understanding computer, website, mobile device, and world navigation)

32. Key: is_agenty_explanation
    Type: string
    Value: A short, single sentence, explaining why you made the choice for `is_agenty`.

33. Key: is_planning
    Type: boolean
    Value: Does the task being asked of by the query in this template (if instantiated) require making some inference about the future, planning about the future, thinking about the consequence of some action, or involve counterfactual reasoning?

34. Key: is_planning_explanation
    Type: string
    Value: A short, single sentence, explaining why you made the choice for `is_planning`.
   
35. Key: is_few_shot
    Type: boolean
    Value: Is the template a few-shot prompt template? (i.e. does it contain variables for inputting examples of outputs)

36. Key: is_few_shot_explanation
    Type: string
    Value: A short, single sentence, explaining why you made the choice for `is_few_shot`.

Template:
{template}

Description of Compatible Potential Documents:
{description}
"""

default_annotation_1 = {
    "qa_or_tasky": None,
    "qa_or_tasky_explanation": "The annotation failed.",
    "realistic": False,
    "realistic_explanation": "The annotation failed.",
    "conversational": False,
    "conversational_explanation": "The annotation failed.",
    "task_type_open": None,
    "task_type_open_explanation": "The annotation failed.",
    "task_type_closed": None,
    "task_type_closed_explanation": "The annotation failed.",
    "difficulty": 0.0,
    "difficulty_explanation": "The annotation failed.",
    "compatibility": 0.0,
    "compatibility_explanation": "The annotation failed.",
    "query_frequency": 0.0,
    "query_frequency_explanation": "The annotation failed.",
    "is_knowledge_recall": False,
    "is_knowledge_recall_explanation": "The annotation failed.",
    "is_reasoning": False,
    "is_reasoning_explanation": "The annotation failed.",
    "is_code": False,
    "is_code_explanation": "The annotation failed.",
    "is_math": False,
    "is_math_explanation": "The annotation failed.",
    "is_science": False,
    "is_science_explanation": "The annotation failed.",
    "is_medicine": False,
    "is_medicine_explanation": "The annotation failed.",
    "is_personal_life": False,
    "is_personal_life_explanation": "The annotation failed.",
    "is_agenty": False,
    "is_agenty_explanation": "The annotation failed.",
    "is_planning": False,
    "is_planning_explanation": "The annotation failed.",
    "is_few_shot": False,
    "is_few_shot_explanation": "The annotation failed.",
}


def extract_json(input_string, normalize_trailing_commas=True):
    # Using regex to identify JSON structures in the string
    if normalize_trailing_commas:
        input_string = re.sub(
            r",\s*([\]}])", r"\1", input_string
        )  # Normalize trailing commas
    json_match = re.search(r"(\{[.\s\S]*\}|\[[.\s\S]*\])", input_string, re.DOTALL)
    if json_match:
        extracted_json = json_match.group(0)
        try:
            # Forgive broken JSON escaping on template
            template_match = re.search(
                r'"template": "([.\s\S]*)",\n  "compatible_document_description":',
                extracted_json,
                re.DOTALL,
            )
            if template_match:
                extracted_template = template_match.group(1)
                extracted_json = extracted_json.replace(
                    extracted_template,
                    re.sub(r'\\([^"\\/bfnrtu])', r"\1", extracted_template).replace(
                        "\t", "\\t"
                    ),
                )

            # Convert the extracted JSON string into a Python dictionary or list of dictionaries
            val = json.loads(extracted_json)
            if isinstance(val, dict):
                return val
            else:
                return {}
        except json.JSONDecodeError:
            return {}
    else:
        return {}


def cast_to_bool(x):
    if isinstance(x, bool):
        return x
    return str(x).lower().strip() in ["true", "1", "yes", "t"]


def cast_to_float(x):
    if isinstance(x, int):
        return float(x)
    if isinstance(x, float):
        return x
    try:
        # Extract just digits and a single decimal point
        x = re.sub(r"[^\d.]", "", str(x))
        return float(x)
    except ValueError:
        return 0.0


def cast_to_ref_type(x, reference):
    if reference is None and not isinstance(x, str):
        return "The annotation failed."
    if isinstance(reference, bool):
        return cast_to_bool(x)
    elif isinstance(reference, float):
        return cast_to_float(x)
    else:
        return x


def post_process_annotation_1(x):
    response = default_annotation_1.copy()
    extracted = {
        k: cast_to_ref_type(v, default_annotation_1[k])
        for k, v in extract_json(x).items()
        if k in default_annotation_1
    }
    response.update(extracted)
    return json.dumps(response)


def explode_annotation_into_columns(row):
    annotation_object = json.loads(row["annotation_object"])
    return annotation_object
