import sys
from collections import Counter

import numpy as np
from datasets import concatenate_datasets, load_dataset

key_count = Counter()
true_key_count = Counter()


def compute_lengths(batch):
    return {"length": [len(query) for query in batch["query"]]}


def get_stratify_keys(batch):
    return batch


def find_log_bucket(value, start, end, n_buckets):
    buckets = np.logspace(np.log10(start), np.log10(end), n_buckets + 1)
    for i in range(len(buckets) - 1):
        if buckets[i] <= value < buckets[i + 1]:
            return i + 1
    if value >= buckets[-1]:
        return n_buckets
    return None  # Out of range for values below `start`


def create_stratify_key(key_count, x, min_length, max_length):
    key = (
        x["source_name"]
        + "_"
        + str(
            find_log_bucket(
                value=len(x["query"]), start=min_length, end=max_length, n_buckets=10
            )
        )
    )
    key_count[key] += 1
    return key


def stratify_real_queries(ctx):
    dataset_name = "fineinstructions/real_queries"
    print("Loading dataset...", file=sys.stderr)
    dataset = load_dataset(dataset_name, split="full")
    print("Loaded dataset.", file=sys.stderr)
    dataset_with_lengths = dataset.map(
        compute_lengths,
        batched=True,
        batch_size=10000,
        num_proc=10,
        remove_columns=dataset.column_names,
        desc="Compute Length",
    )
    min_length = min(dataset_with_lengths["length"])
    max_length = max(dataset_with_lengths["length"])
    print(f"Min Length: {min_length}, Max Length: {max_length}", file=sys.stderr)
    dataset = (
        dataset.shuffle(seed=42)
        .map(
            lambda x: {
                **x,
                "stratify_key": create_stratify_key(
                    key_count, x, min_length, max_length
                ),
            },
            desc="Adding stratify_key...",
            num_proc=1,
        )
        .class_encode_column("stratify_key")
    )
    stratify_keys = dataset.map(
        get_stratify_keys,
        batched=True,
        batch_size=10000,
        num_proc=10,
        remove_columns=list(set(dataset.column_names).difference(["stratify_key"])),
        desc="Get Stratify Keys",
    )["stratify_key"]
    for key in stratify_keys:
        true_key_count[key] += 1
    assert len(true_key_count) > 0
    print(f"Stratify Keys: {list(true_key_count.items())}", file=sys.stderr)
    stratifiable = dataset.filter(
        lambda x: true_key_count[x["stratify_key"]] >= 2,
        desc="Filtering stratifiable...",
        num_proc=10,
    )
    unstratifiable = dataset.filter(
        lambda x: true_key_count[x["stratify_key"]] < 2,
        desc="Filtering un-stratifiable...",
        num_proc=10,
    )
    stratifiable_splits = stratifiable.train_test_split(
        test_size=50000, stratify_by_column="stratify_key"
    )
    print(
        "Sizes:",
        stratifiable_splits,
        len(stratifiable_splits["test"]),
        len(unstratifiable),
        file=sys.stderr,
    )
    subsample = concatenate_datasets(
        [stratifiable_splits["test"], unstratifiable]
    ).shuffle(seed=42)
    print("Subsample Size:", len(subsample), file=sys.stderr)
    subsample.push_to_hub(
        "fineinstructions/real_queries_subsample", split="full", max_shard_size="500MB"
    )


__all__ = ["stratify_real_queries"]
