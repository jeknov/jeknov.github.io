import itertools
import json

from ..genericize_queries_subsample.annotation_prompts import default_annotation_1

annotation_column_names = [
    k for k in default_annotation_1 if not k.endswith("_explanation")
]
annotation_explanation_column_names = [
    k for k in default_annotation_1 if k.endswith("_explanation")
]


def template_quality_filter(row):
    # Must have tags
    must_have_tags = (
        row["template"].count("<fi>") == row["template"].count("</fi>")
    ) and row["template"].count("<fi>") > 0

    # Must not be paraphrased
    starter = (
        row["template"][: row["template"].find("<fi>")]
        if "<fi>" in row["template"]
        else row["template"]
    )
    ender = (
        row["template"][row["template"].rfind("</fi>") + len("</fi>") :]
        if "</fi>" in row["template"]
        else ""
    )
    must_not_be_paraphrased = row["query"].startswith(starter) and row[
        "query"
    ].endswith(ender)

    # Must have annotations
    must_have_annotations = True
    for cn in annotation_explanation_column_names + annotation_column_names:
        if "The annotation failed." in str(row[cn]) or row[cn] is None:
            must_have_annotations = False

    # Must not have too specific tags
    must_not_be_too_specific = True
    if len(row["query"]) < 200 and row["template"].count("<fi>") >= 5:
        must_not_be_too_specific = False
    if len(row["query"]) < 1000 and row["template"].count("<fi>") >= 15:
        must_not_be_too_specific = False
    if row["template"].count("<fi>") >= 20:
        must_not_be_too_specific = False

    # Must not be too long
    must_not_be_too_long = (
        len(row["query"])
        + len(row["template"])
        + len(row["template_explanation"])
        + len(row["compatible_document_description"])
    ) < 25000

    return (
        must_have_tags
        and must_not_be_paraphrased
        and must_have_annotations
        and must_not_be_too_specific
        and must_not_be_too_long
    )


PRIMING_ANNOTATION_PROMPT = """
Goal: Our goal is to genericize a real user query into a re-usable template for instruction-tuning. This template can then be instantiated by finding analogous situations / problems in different domains or circumstances.

Method: To do this, we replace pieces of the user's query with template variables (<fi>content description goes here...</fi> tags) that are variables that will get replaced with appropriate content matching the description to instantiate the template.

Task: Analyze the input query and generate a detailed, structured JSON output with a generalized, abstract query template, a compatible document description, and comprehensive annotations (including task type, difficulty, compatibility, query frequency, other categorical annotation tags) along with precise explanations for each.

Here are some details on the annotations that are not self-explanatory:
- Whether the query is `realistic` (mark as "true" if the query is something that a user would plausibly input into ChatGPT in a real-world scenario, mark as "false" if it is too artificial, nonsensical, niche, or spam).
- Whether the query is `conversational` (mark as "true" if the query resembles casual dialogue, seeks informal interaction, and explicitly does not ask for any question to be answered or task to be completed)
- The category of task in `task_type_closed` (specify `text_generation` if the response requires generating natural language text or `code_generation` if it involves generating programming code)
- Whether the query is `is_few_shot` (mark as "true" if the query is designed to include examples or prompts for generating outputs based on patterns).

- Additionally, provide detailed explanations for the following scoring annotations, make your estimate like an expert consultant at McKinsey:
- `compatibility` refers to the estimate of how many documents in CommonCrawl would align with this template, which should be expressed in a logarithmic range. Values could range from 0% (no documents) up to 100% (billions of pages), with intermediate values like 0.0000001% (ones of pages), 0.00001% (hundreds of pages), or 0.0001% (thousands of pages).
- `query_frequency` should estimate the percentage of queries to ChatGPT or the ChatGPT API that would resemble the query in this template, also in a logarithmic range. Values could range from 0% (no requests) up to 100% (billions of requests), with intermediate values like 0.0000001% (ones of requests), 0.00001% (hundreds of requests), or 0.0001% (thousands of requests).
""".strip()


def create_input_and_output_columns(row):
    output_with_explanations_json = {
        "template_explanation": row["template_explanation"],
        "template": row["template"],
        "compatible_document_description": row["compatible_document_description"],
    }
    all_annotation_column_names = list(
        itertools.chain.from_iterable(
            zip(annotation_column_names, annotation_explanation_column_names)
        )
    )
    annotation_columns = {cn: row[cn] for cn in all_annotation_column_names}
    output_with_explanations_json.update(annotation_columns)
    if output_with_explanations_json["conversational"]:
        output_with_explanations_json["conversational_explanation"] = (
            "This original input query (not the template) is not actually asking something (question or task) and it's more just conversing with the AI without a goal or it's random spam. Here's why: "
            + output_with_explanations_json["conversational_explanation"]
        )
    elif not output_with_explanations_json["conversational"]:
        output_with_explanations_json["conversational_explanation"] = (
            "This original input query (not the template) is actually asking something (question or task) and it's not just conversing with the AI without a goal and it's not random spam. Here's why: "
            + output_with_explanations_json["conversational_explanation"]
        )
    if output_with_explanations_json["realistic"]:
        output_with_explanations_json["realistic_explanation"] = (
            "This original input query (not the template) is something that a user would plausibly input into ChatGPT in a real-world scenario and does not look like spam. Here's why: "
            + output_with_explanations_json["realistic_explanation"]
        )
    elif not output_with_explanations_json["realistic"]:
        output_with_explanations_json["realistic_explanation"] = (
            "This original input query (not the template) is not something that a user would plausibly input into ChatGPT in a real-world scenario and looks more like spam. Here's why: "
            + output_with_explanations_json["realistic_explanation"]
        )
    output_with_explanations_json["compatibility_explanation"] = (
        f"Realistically, on a logarithmic scale from 0.0000001% (ones of pages) to 100% (billions of pages): {output_with_explanations_json['compatibility']}% of documents in CommonCrawl would be compatible with this document. Here's why this is a really good numerical estimate: "
        + output_with_explanations_json["compatibility_explanation"]
    )
    output_with_explanations_json["query_frequency_explanation"] = (
        f"Realistically, on a logarithmic scale from 0.0000001% (ones of requests) to 100% (billions of requests): {output_with_explanations_json['query_frequency']}% of requests to ChatGPT or the ChatGPT API would resemble the query. Here's why this is a really good numerical estimate: "
        + output_with_explanations_json["query_frequency_explanation"]
    )
    output_without_explanations_json = {
        k: v
        for k, v in output_with_explanations_json.items()
        if not k.endswith("_explanation") or k == "template_explanation"
    }
    output_with_bottom_explanations_json = output_without_explanations_json.copy()
    output_with_bottom_explanations_json.update(
        {
            k: v
            for k, v in output_with_explanations_json.items()
            if k.endswith("_explanation") and k != "template_explanation"
        }
    )

    return {
        "query_with_prompt": (
            PRIMING_ANNOTATION_PROMPT + "\n\nInput Query:\n" + row["query"]
        ),
        "output": json.dumps(output_without_explanations_json, indent=2),
        "output_with_explanation": json.dumps(output_with_explanations_json, indent=2),
        "output_with_bottom_explanation": json.dumps(
            output_with_bottom_explanations_json, indent=2
        ),
    }
