import os
import socket

import torch
from datadreamer import DataDreamer
from datadreamer.steps import HFHubDataSource
from datadreamer.trainers import TrainHFFineTune
from peft import LoraConfig

from .metrics import compute_metrics
from .preprocessing import create_input_and_output_columns, template_quality_filter


def train_query_genericizer(ctx):
    from ....project import (
        get_persistent_dir,
        get_torch_cpu_device,
        get_torch_devices,
        reporter,
    )

    reporter.set(
        "train_query_genericizer.distill_datadreamer_output_end_to_end",
        "distill_datadreamer_output_end_to_end",
    )
    datadreamer_output_dir = get_persistent_dir(
        "distill_datadreamer_output_end_to_end",
        "train_query_genericizer.distill_datadreamer_output_end_to_end",
    )

    with DataDreamer(datadreamer_output_dir, log_date=True):
        MODEL_NAME = "meta-llama/Llama-3.2-1B-Instruct"
        PEFT_CONFIG = LoraConfig(r=1024)
        EPOCHS = 8
        LEARNING_RATE = 1e-4
        BATCH_SIZE = 1
        DTYPE = torch.bfloat16 if len(get_torch_devices()) > 0 else torch.float32
        TRAIN_DEVICE = (
            get_torch_devices()
            if len(get_torch_devices()) > 0
            else get_torch_cpu_device()
        )
        GRADIENT_ACCUMULATION_STEPS = 8 // len(get_torch_devices())
        INFERENCE_DEVICE = TRAIN_DEVICE
        VALIDATION_SIZE = 1000

        print("----------------------------------------")
        print("HOSTNAME:", socket.gethostname())
        print("EPOCHS:", EPOCHS)
        print("TRAIN_DEVICE:", TRAIN_DEVICE)
        print("INFERENCE_DEVICE:", INFERENCE_DEVICE)
        print("DTYPE:", DTYPE)
        print("BATCH_SIZE:", BATCH_SIZE)
        print("GRADIENT_ACCUMULATION_STEPS:", GRADIENT_ACCUMULATION_STEPS)
        print("----------------------------------------")

        # Load templates dataset
        templates_dataset = HFHubDataSource(
            "Get Templates",
            "fineinstructions/templates_raw_subsample",
            split="full",
            revision="7d792a2dbc25a75dc0597151b82ea845cd305766",
        )

        # Filter out lower quality templates
        print("Number of templates before filtering:", len(templates_dataset.output))
        templates_dataset = templates_dataset.filter(
            template_quality_filter, lazy=False, name="Filter out Low-Quality Templates"
        )
        print("Number of templates after filtering:", len(templates_dataset.output))

        if len(templates_dataset.output) < VALIDATION_SIZE * 10:
            VALIDATION_SIZE = 100

        # Map templates and annotations to output format
        templates_dataset = templates_dataset.map(
            create_input_and_output_columns,
            lazy=False,
            name="Create Input + Output Columns",
            remove_columns=set(templates_dataset.output.column_names).difference(
                [
                    "query",
                    "output",
                    "query_with_prompt",
                    "output_with_explanation",
                    "output_with_bottom_explanation",
                ]
            ),
        )

        # Create split for training
        splits = templates_dataset.splits(
            train_size=len(templates_dataset.output) - VALIDATION_SIZE,
            validation_size=VALIDATION_SIZE,
        )
        train_split, validation_split = splits["train"], splits["validation"]

        # Preview training data
        train_query = list(train_split.output.dataset["query"])[0]
        train_output_with_explanation = list(
            train_split.output.dataset["output_with_explanation"]
        )[0]
        train_output_with_bottom_explanation = list(
            train_split.output.dataset["output_with_bottom_explanation"]
        )[0]
        train_output = list(train_split.output.dataset["output"])[0]

        print("----------------------------------------")
        print("Training Data Preview Input:\n", train_query)
        print("----------------------------------------")
        print(
            "Training Data Preview Output With Explanation:\n",
            train_output_with_explanation,
        )
        print("----------------------------------------")
        print(
            "Training Data Preview Output With Bottom Explanation:\n",
            train_output_with_bottom_explanation,
        )
        print("----------------------------------------")
        print("Training Data Preview Output Without Explanation:\n", train_output)
        print("----------------------------------------")

        # Train End-to-End model
        trainer = TrainHFFineTune(
            "Train Stage-1 Model",
            model_name=MODEL_NAME,
            peft_config=PEFT_CONFIG,
            device=TRAIN_DEVICE,
            dtype=DTYPE,
            fsdp=False,
        )
        trainer.train(
            train_input=train_split.output["query_with_prompt"],
            train_output=train_split.output["output_with_explanation"],
            validation_input=validation_split.output["query_with_prompt"],
            validation_output=validation_split.output["output_with_explanation"],
            epochs=EPOCHS,
            learning_rate=LEARNING_RATE,
            lr_scheduler_type="constant",
            batch_size=BATCH_SIZE,
            gradient_accumulation_steps=GRADIENT_ACCUMULATION_STEPS,
            gradient_checkpointing=True,
            compute_metrics=compute_metrics,
            batch_eval_metrics=True,
            early_stopping_patience=1,
        )
        end_to_end_export_path_s1 = os.path.join(
            datadreamer_output_dir, "end_to_end_output_model_s1"
        )
        if not trainer._resumed:
            trainer.export_to_disk(end_to_end_export_path_s1, adapter_only=False)
            trainer.publish_to_hf_hub(
                "fineinstructions/query_templatizer_full_end_to_end_s1",
                adapter_only=False,
            )
            trainer.publish_to_hf_hub(
                "fineinstructions/query_templatizer_end_to_end_s1", adapter_only=True
            )
        trainer.unload_model()

        # Train Stage-2 model
        trainer = TrainHFFineTune(
            "Train Stage-2 Model",
            model_name="fineinstructions/query_templatizer_full_end_to_end_s1",
            peft_config=PEFT_CONFIG,
            device=TRAIN_DEVICE,
            dtype=DTYPE,
            fsdp=False,
        )
        trainer.train(
            train_input=train_split.output["query"],
            train_output=train_split.output["output_with_bottom_explanation"],
            validation_input=validation_split.output["query"],
            validation_output=validation_split.output["output_with_bottom_explanation"],
            epochs=EPOCHS,
            learning_rate=LEARNING_RATE * 10,
            batch_size=BATCH_SIZE,
            gradient_accumulation_steps=GRADIENT_ACCUMULATION_STEPS * 8,
            gradient_checkpointing=True,
            compute_metrics=compute_metrics,
            batch_eval_metrics=True,
            early_stopping_patience=2,
        )
        end_to_end_export_path_s2 = os.path.join(
            datadreamer_output_dir, "end_to_end_output_model_s2"
        )
        if not trainer._resumed:
            trainer.export_to_disk(end_to_end_export_path_s2, adapter_only=False)
            trainer.publish_to_hf_hub(
                "fineinstructions/query_templatizer_full_end_to_end_s2",
                adapter_only=False,
            )
            trainer.publish_to_hf_hub(
                "fineinstructions/query_templatizer_end_to_end_s2", adapter_only=True
            )
        trainer.unload_model()


__all__ = ["train_query_genericizer"]
