import math
import re

from ...train_query_genericizer.train_query_genericizer.preprocessing import (
    annotation_column_names,
)
from ..genericize_queries_subsample.annotation_prompts import (
    cast_to_ref_type,
    default_annotation_1,
    extract_json,
)


def explode_output_into_columns(row):
    row["genericization_object"] = row["genericization_object"] + "}"
    extracted_output = extract_json(
        row["genericization_object"], normalize_trailing_commas=False
    )
    new_row = {
        "template": extracted_output.pop("template", None),
        "compatible_document_description": extracted_output.pop(
            "compatible_document_description", None
        ),
    }
    new_row.update(
        {
            k: (
                cast_to_ref_type(extracted_output[k], default_annotation_1[k])
                if k in extracted_output
                else None
            )
            for k in default_annotation_1
            if k in default_annotation_1 and not k.endswith("_explanation")
        }
    )
    for key in new_row:
        if isinstance(new_row[key], str):
            new_row[key] = (
                new_row[key]
                .encode("utf8", errors="ignore")
                .decode("utf8", errors="ignore")
            )
    return new_row


def template_quality_filter_final(row):
    if row["template"] is None:
        return False

    # Must have tags
    must_have_tags = (
        row["template"].count("<fi>") == row["template"].count("</fi>")
    ) and row["template"].count("<fi>") > 0

    # Must not be paraphrased
    # starter = (
    #     row["template"][: row["template"].find("<fi>")]
    #     if "<fi>" in row["template"]
    #     else row["template"]
    # )
    # ender = (
    #     row["template"][row["template"].rfind("</fi>") + len("</fi>") :]
    #     if "</fi>" in row["template"]
    #     else ""
    # )
    # must_not_be_paraphrased = row["query"].startswith(starter) and row[
    #     "query"
    # ].endswith(ender)

    # Must have annotations
    must_have_annotations = True
    for cn in annotation_column_names:
        if "The annotation failed." in str(row[cn]) or row[cn] is None:
            must_have_annotations = False

    # Must not have too specific tags
    must_not_be_too_specific = True
    if len(row["query"]) < 200 and row["template"].count("<fi>") >= 10:
        must_not_be_too_specific = False
    if len(row["query"]) < 1000 and row["template"].count("<fi>") >= 20:
        must_not_be_too_specific = False
    if row["template"].count("<fi>") >= 25:
        must_not_be_too_specific = False

    # Must be realistic and must not be conversational
    must_be_realistic = row["realistic"]
    must_not_be_conversational = not row["conversational"]

    return (
        must_have_tags
        # and must_not_be_paraphrased
        and must_have_annotations
        and must_not_be_too_specific
        and must_be_realistic
        and must_not_be_conversational
    )


def clean_decimal(num):
    num_str = str(num)
    num_str = re.search(r"[0-9]*\.?0*[123456789]?", num_str).group()
    round_to_five = (  # noqa: E731
        lambda x: round(x / 10 ** math.floor(math.log10(abs(x))))
        * 10 ** math.floor(math.log10(abs(x)))
        if x
        else 0
    )
    clean_float = lambda x: float(format(x, ".9f"))  # noqa: E731
    return clean_float(round_to_five(float(num_str)))


def map_rows(row):
    if isinstance(row["query_frequency"], float) or isinstance(
        row["query_frequency"], int
    ):
        row["query_frequency"] = clean_decimal(row["query_frequency"])
    if isinstance(row["compatibility"], float) or isinstance(row["compatibility"], int):
        row["compatibility"] = clean_decimal(row["compatibility"])
    if isinstance(row["template"], str):
        row["template_variable_count"] = row["template"].count("<fi>")
    else:
        row["template_variable_count"] = 0
    return row
