import logging
import os
from time import sleep

import click
import torch
from datadreamer import DataDreamer
from datadreamer.llms import VLLM, ParallelLLM
from datadreamer.steps import DataSource, HFHubDataSource, Prompt, concat, zipped
from datadreamer.utils.fs_utils import safe_fn
from datasets import get_dataset_split_names
from datasets.exceptions import DatasetNotFoundError
from huggingface_hub import snapshot_download

from .postprocessing import (
    explode_output_into_columns,
    map_rows,
    template_quality_filter_final,
)


@click.option(
    "--shards", "-s", type=str, required=True, help="The range of shards to process."
)
def genericize_queries(ctx, shards):  # noqa: C901
    from ....project import get_persistent_dir, get_torch_devices, reporter

    # Model name
    MODEL_NAME = "fineinstructions/query_templatizer"
    MODEL_REVISION = "b7e0dae64c8984cc65b461ecfc481ceb1374d0d3"
    snapshot_download(repo_id=MODEL_NAME, revision=MODEL_REVISION)

    # Get devices
    INFERENCE_DEVICE = get_torch_devices()

    # Flag to control whether to force re-run the pipeline without caching
    FORCE = False

    # Process shards
    TOTAL_NUM_SHARDS = 220
    shards = shards.replace(" ", "").lower()
    if shards == "all":
        shards = "0-" + str(TOTAL_NUM_SHARDS)
    shard_ranges = shards.split(",")
    shards_to_run = []
    for shard_range in shard_ranges:
        shard_start_idx = shard_range.split("-")[0]
        shard_end_idx = (
            shard_range.split("-")[1]
            if len(shard_range.split("-")) > 1
            else str(int(shard_range.split("-")[0]) + 1)
        )
        for shard_idx in range(int(shard_start_idx), int(shard_end_idx)):
            shards_to_run.append(shard_idx)
    del shard_idx, shard_range, shard_start_idx, shard_end_idx

    # Check what splits are already processed
    while True:
        try:
            split_names = get_dataset_split_names(
                "fineinstructions/templates_raw_shards"
            )
            break
        except DatasetNotFoundError:
            split_names = []
            break
        except Exception as e:
            print(f"Error checking if shards exists. Retrying...{e}")
            sleep(10)
            continue
    shards_to_run = [s for s in shards_to_run if str(s) not in split_names]

    # Setup DataDreamer
    reporter.set("genericize_queries.datadreamer_output", "datadreamer_output")
    datadreamer_output_dir = get_persistent_dir(
        "datadreamer_output", "genericize_queries.datadreamer_output"
    )

    with DataDreamer(datadreamer_output_dir, log_date=True, log_level=logging.DEBUG):
        print("INFERENCE DEVICE:", INFERENCE_DEVICE)
        os.environ["VLLM_DO_NOT_TRACK"] = "1"
        os.environ["DO_NOT_TRACK"] = "1"
        os.environ["VLLM_NO_USAGE_STATS"] = "1"
        os.environ["VLLM_ATTENTION_BACKEND"] = "FLASHINFER"
        os.environ["HF_HUB_DOWNLOAD_TIMEOUT"] = "120"
        templatizer_model = ParallelLLM(
            *[
                VLLM(
                    cache_folder_path=os.path.join(
                        datadreamer_output_dir,
                        ".cache",
                        safe_fn(shards),
                        safe_fn(str(inf_device)),
                    ),
                    model_name=MODEL_NAME,
                    revision=MODEL_REVISION,
                    device=inf_device,
                    tensor_parallel_size=1,
                    dtype=torch.bfloat16,
                    disable_log_stats=True,
                    enable_chunked_prefill=True,
                    enable_prefix_caching=True,
                    enforce_eager=False,
                    disable_custom_all_reduce=False,
                    gpu_memory_utilization=0.95,
                    max_model_len=11500,
                    max_num_seqs=100,  # to max_num_seqs=384 if 48GBVRAM
                    max_num_batched_tokens=28000,  # to max_num_batched_tokens=48000 if 48GBVRAM
                )
                for inf_device in INFERENCE_DEVICE
            ]
        )

        # Load real queries dataset
        real_queries_dataset = HFHubDataSource(
            "Get Real Queries", "fineinstructions/real_queries", split="full"
        )

        for current_shard_idx in shards_to_run:
            print(f"Processing shard #{current_shard_idx}/{TOTAL_NUM_SHARDS}...")

            # Check if shard exists
            should_skip = False
            while True:
                try:
                    if str(current_shard_idx) in get_dataset_split_names(
                        "fineinstructions/templates_raw_shards"
                    ):
                        print(f"Shard {current_shard_idx} already exists. Skipping...")
                        should_skip = True
                    else:
                        should_skip = False
                    break
                except DatasetNotFoundError:
                    should_skip = False
                    break
                except Exception as e:
                    print(f"Error checking if shard exists. Retrying...{e}")
                    sleep(10)
                    continue
            if should_skip:
                continue

            # Get shard
            real_queries_dataset_shard = real_queries_dataset.shard(
                num_shards=TOTAL_NUM_SHARDS,
                index=current_shard_idx,
                contiguous=True,
                name=f"Create shard {current_shard_idx}",
            ).filter(
                lambda row: templatizer_model.count_tokens(row["query"]) <= 8000,
                lazy=False,
                name=f"Filter queries that are too long for shard {current_shard_idx}",
                force=FORCE,
            )

            # Get "query" column
            queries = real_queries_dataset_shard.select_columns(
                ["query"], name=f"Select 'query' column for shard {current_shard_idx}"
            )

            # Filter queries that are too long
            genericizing_prompts = queries.rename_column(
                "query",
                "prompt",
                name=f"Rename 'query' to 'prompt' for shard {current_shard_idx}",
            )

            # Genericize queries
            genericized_queries = Prompt(
                name=f"Generate Genericized Queries for shard {current_shard_idx}",
                inputs={"prompts": genericizing_prompts.output["prompt"]},
                args={
                    "llm": templatizer_model,
                    "batch_size": 1000,
                    "temperature": 0.0,
                    "top_p": 0.0,
                    "repetition_penalty": 0.1,
                    "max_new_tokens": 2500,
                    "stop": [',\n  "qa_or_tasky_explanation":'],
                },
                outputs={"generations": "genericization_object"},
                force=FORCE,
            ).map(
                explode_output_into_columns,
                lazy=False,
                name=f"Create Template and Annotation Columns for shard {current_shard_idx}",
                force=FORCE,
                remove_columns=["prompts", "genericization_object"],
            )

            # Combine all columns
            combined = zipped(
                real_queries_dataset_shard.select_columns(
                    ["source_name", "query"],
                    name=f"Select source and query columns for shard {current_shard_idx}",
                ),
                genericized_queries,
                real_queries_dataset_shard.select_columns(
                    ["language", "source", "metadata"],
                    name=f"Select metadata columns for shard {current_shard_idx}",
                ),
                name=f"Combine all columns for shard {current_shard_idx}",
            ).save(name=f"Save combined dataset for shard {current_shard_idx}")

            while True:
                try:
                    combined.output.dataset.push_to_hub(
                        "fineinstructions/templates_raw_shards",
                        split=f"{current_shard_idx}",
                        max_shard_size="500MB",
                    )
                    break
                except Exception as e:
                    print(f"Error uploading: {e}")
                    sleep(10)
                    continue

        # Load all shards
        all_shards = []
        total_num_rows = 0
        for shard_idx in range(TOTAL_NUM_SHARDS):
            while True:
                try:
                    all_shards.append(
                        HFHubDataSource(
                            f"Get Shard {shard_idx}",
                            "fineinstructions/templates_raw_shards",
                            split=str(shard_idx),
                        )
                    )
                    total_num_rows += len(all_shards[-1].output)
                    break
                except Exception as e:
                    print(f"Error getting shard. Retrying...{e}")
                    sleep(10)
                    continue
        all_combined = concat(*all_shards, name="Concatenate all shards")

        # Filter out low-quality templates
        all_combined = all_combined.map(
            map_rows,
            lazy=True,
            name="Map rows",
            save_num_proc=16,
            total_num_rows=total_num_rows,
        ).filter(
            template_quality_filter_final,
            lazy=False,
            name="Filter out Low-Quality Templates",
            save_num_proc=16,
        )
        all_combined = all_combined.remove_columns(["realistic", "conversational"])

        # Create and add template IDs
        template_ids = DataSource(
            "Create template IDs",
            data=[
                {"template_id": template_id}
                for template_id in range(len(all_combined.output))
            ],
        )
        all_column_names = list(all_combined.output.column_names)
        all_column_names_pre = all_column_names[: all_column_names.index("qa_or_tasky")]
        all_column_names_post = all_column_names[
            all_column_names.index("qa_or_tasky") :
        ]
        all_column_names_pre.remove("query")
        all_combined = zipped(
            template_ids,
            all_combined.select_columns(all_column_names_pre),
            all_combined.select_columns(["query"]).rename_column(
                "query", "example_template_instantiation"
            ),
            all_combined.select_columns(all_column_names_post),
            name="Add Template IDs and Change Final Structure",
            lazy=False,
            save_num_proc=16,
        )

        # Push final cleaned templates
        all_combined.publish_to_hf_hub("fineinstructions/finetemplates", split="full")


__all__ = ["genericize_queries"]
