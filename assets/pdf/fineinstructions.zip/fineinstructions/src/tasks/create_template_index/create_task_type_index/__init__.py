import logging
import os
from itertools import islice, tee
from time import time

import faiss
import numpy as np
from datadreamer import DataDreamer
from datadreamer.embedders import ParallelEmbedder, SentenceTransformersEmbedder
from datadreamer.steps import HFHubDataSource
from huggingface_hub import HfApi


def create_task_type_index(ctx):
    from ....project import get_persistent_dir, get_torch_devices, reporter

    # Get devices
    FAISS_DEVICE = get_torch_devices()[0]
    INFERENCE_DEVICE = get_torch_devices()[1:]

    # Flag to control whether to force re-run the pipeline without caching
    FORCE = False

    reporter.set(
        "create_task_type_index.datadreamer_output",
        "create_task_type_index_datadreamer_output",
    )
    datadreamer_output_dir = get_persistent_dir(
        "create_task_type_index_datadreamer_output",
        "create_task_type_index.datadreamer_output",
    )
    faiss_output_dir = get_persistent_dir(
        "create_task_type_index_faiss_output",
        "create_task_type_index.datadreamer_output",
    )

    with DataDreamer(datadreamer_output_dir, log_date=True, log_level=logging.DEBUG):
        # Get all templates
        templates_dataset = HFHubDataSource(
            "Get FineTemplates Dataset (Clean)",
            "fineinstructions/finetemplates",
            revision="da7b725f7c1248f8c632d7d53c94109ae5dadbfe",
            split="full",
            force=FORCE,
        )

        # Configuration
        limit = None
        n_total = templates_dataset.output.num_rows  # Total number of vectors
        train_total = limit if limit is not None else min(n_total, 15000000)
        d = 384  # Vector dimension
        m = 24  # Number of sub-vectors
        nbits = 8  # Bits per sub-vector
        nlist = min(
            65536, n_total // 40
        )  # Number of Voronoi cells (coarse quantizer clusters)
        batch_size = (
            min(20000, limit) if limit is not None else 20000
        )  # Batch size for adding vectors
        embed_batch_size = 1024
        index_file = os.path.join(faiss_output_dir, "faiss_ivfpq.index")

    with DataDreamer(":memory:", log_date=True, log_level=logging.DEBUG):
        # Create a embedder
        embedder = ParallelEmbedder(
            *[
                SentenceTransformersEmbedder(
                    "BAAI/bge-small-en-v1.5",
                    device=inf_device,
                    revision="5c38ec7c405ec4b44b94cc5a9bb96e735b38267a",
                )
                for inf_device in INFERENCE_DEVICE
            ]
        )

        # Create iterator from embedder output
        embeddings_iter = iter(
            embedder.run(
                texts=(
                    r["task_type_open"] + "\n\n" + r["template"]
                    for r in templates_dataset.output.dataset
                ),
                truncate=True,
                batch_size=embed_batch_size,
                progress_interval=60,
                return_generator=True,
                total_num_texts=n_total,
            )
        )

        if limit is not None:
            embeddings_iter = islice(embeddings_iter, limit * 5)

        # Get two iterators
        embeddings_iter_train, embeddings_iter_add = tee(embeddings_iter, 2)

        # Initialize GPU resources
        gpu_ids = [FAISS_DEVICE.index]

        # Create coarse quantizer
        quantizer = faiss.IndexFlat(d, faiss.METRIC_INNER_PRODUCT)

        # Create IVFPQ index
        print(
            f"IVFPQ index with {d} dimensions, {n_total} vectors --- {nlist} cells, {m} sub-vectors, and {nbits} bits..."
        )
        index = faiss.IndexIVFPQ(
            quantizer, d, nlist, m, nbits, faiss.METRIC_INNER_PRODUCT
        )

        # Move index to multiple GPUs
        index = faiss.index_cpu_to_gpus_list(index=index, gpus=gpu_ids)

        # Fetch vectors and accumulate until we have at least 15 million
        retrieved_vectors = []
        print("Retrieving vectors...")
        while (len(retrieved_vectors) * batch_size) < train_total:
            batch = list(islice(embeddings_iter_train, batch_size))
            if len(batch) > 0:
                retrieved_vectors.append(batch)
            else:
                break

        # Convert to NumPy array for training
        retrieved_vectors = np.vstack(retrieved_vectors).astype(np.float32)

        # Train the index with 15M vectors
        print(f"Training index on {retrieved_vectors.shape} vectors...")
        index.train(retrieved_vectors)
        del retrieved_vectors
        print("Training complete.")

        # Add vectors in batches
        print("Adding vectors in batches...")
        i = 0
        while True:
            vectors = list(islice(embeddings_iter_add, batch_size))
            if vectors == []:
                break
            batch_size_actual = len(vectors)
            index.add(np.vstack(vectors).astype(np.float32))
            print(f"Added {i + batch_size_actual}/{n_total} vectors")
            i += batch_size_actual

        # Move index back to CPU before saving
        index = faiss.index_gpu_to_cpu(index)

        # Save index to disk
        print(f"Writing index to {index_file}...")
        faiss.write_index(index, index_file)
        print(f"Index saved with {index.ntotal} vectors.")

        # Upload to repo
        if limit is None:
            print("Uploading index...")
            api = HfApi()
            api.upload_file(
                path_or_fileobj=index_file,
                path_in_repo="faiss_index/finetemplates_task_type.index",
                repo_id="fineinstructions/finetemplates",
                repo_type="dataset",
            )
            print("Done uploading.")

        DOC_1 = """Write me a clinical note for a patient with Budd-Chiari Syndrome."""

        DOC_2 = """Predict the structure of a protein given the amino acid sequence."""

        DOC_3 = """Show me how to write a Python script that reads a CSV file and prints the first 10 rows."""

        DOC_4 = (
            """Show me how to solve a quadratic equation using the quadratic formula."""
        )

        print("Testing nearest neighbor search...")

        def nn(text, k=100, print_results=True):
            embeddings = np.vstack(
                embedder.run(texts=[text], truncate=True, batch_size=1)
            )
            distances, indices = index.search(embeddings, k)
            distances, indices = distances[0], indices[0]
            print("================================================================")
            print("DOC: ", text)
            print("Number of retrieves results:", len(distances))
            if print_results:
                print(
                    ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
                )
                for rank, (d, i) in enumerate(zip(distances, indices)):
                    print(
                        "--------------------------------------------------------------"
                    )
                    print("RANK:", rank)
                    print("SIM:", d)
                    print("IDX:", i)
                    print(
                        "TASK TYPE:",
                        templates_dataset.output.dataset[i.item()]["task_type_open"],
                    )
                    print(
                        "TEMPLATE:",
                        templates_dataset.output.dataset[i.item()]["template"],
                    )

        print(time())
        nn(DOC_1)
        nn(DOC_2)
        nn(DOC_3)
        nn(DOC_4)
        print(time())

        # Measure time to retrieve full results in sorted order
        print("Retrieving full results in sorted order...")
        start_time = time()
        index.nprobe = nlist  # Set number of Voronoi cells to search
        nn(DOC_1, k=n_total, print_results=False)
        end_time = time()
        print(
            f"Time taken to retrieve full results: {end_time - start_time:.2f} seconds"
        )


__all__ = ["create_task_type_index"]
