import os
from itertools import islice, tee
from time import time

import faiss
import numpy as np
from datadreamer import DataDreamer
from datadreamer.embedders import ParallelEmbedder, SentenceTransformersEmbedder
from datadreamer.steps import HFHubDataSource
from huggingface_hub import HfApi


def create_template_index(ctx):
    from ....project import get_persistent_dir, get_torch_devices, reporter

    # Get devices
    FAISS_DEVICE = get_torch_devices()[0]
    INFERENCE_DEVICE = get_torch_devices()[1:]

    # Flag to control whether to force re-run the pipeline without caching
    FORCE = False

    reporter.set(
        "create_template_index.datadreamer_output",
        "create_template_index_datadreamer_output",
    )
    datadreamer_output_dir = get_persistent_dir(
        "create_template_index_datadreamer_output",
        "create_template_index.create_template_index_datadreamer_output",
    )
    faiss_output_dir = get_persistent_dir(
        "create_template_index_faiss_output",
        "create_template_index.create_template_index_faiss_output",
    )

    with DataDreamer(datadreamer_output_dir, log_date=True):
        # Get all templates
        templates_dataset = HFHubDataSource(
            "Get FineTemplates Dataset (Clean)",
            "fineinstructions/finetemplates",
            revision="ce8055adca7048499c8c9dc696f3222bc11a8883",
            split="full",
            force=FORCE,
        )

        # Configuration
        limit = None
        n_total = templates_dataset.output.num_rows  # Total number of vectors
        train_total = limit if limit is not None else min(n_total, 15000000)
        d = 1024  # Vector dimension
        m = 32  # Number of sub-vectors
        nbits = 8  # Bits per sub-vector
        nlist = min(
            65536, n_total // 40
        )  # Number of Voronoi cells (coarse quantizer clusters)
        batch_size = (
            min(20000, limit) if limit is not None else 20000
        )  # Batch size for adding vectors
        embed_batch_size = 32
        index_file = os.path.join(faiss_output_dir, "faiss_ivfpq.index")

    with DataDreamer(":memory:", log_date=True):
        # Create a embedder
        embedder = ParallelEmbedder(
            *[
                SentenceTransformersEmbedder(
                    "fineinstructions/instruction_template_retrieval_embedding",
                    device=inf_device,
                    revision="db4efbde126216250ffa5a356663fc7da3bf7856",
                )
                for inf_device in INFERENCE_DEVICE
            ]
        )

        # Create iterator from embedder output
        embeddings_iter = iter(
            embedder.run(
                texts=(
                    r["compatible_document_description"]
                    for r in templates_dataset.output.dataset
                ),
                truncate=True,
                batch_size=embed_batch_size,
                progress_interval=60,
                return_generator=True,
                total_num_texts=n_total,
            )
        )

        if limit is not None:
            embeddings_iter = islice(embeddings_iter, limit * 5)

        # Get two iterators
        embeddings_iter_train, embeddings_iter_add = tee(embeddings_iter, 2)

        # Initialize GPU resources
        gpu_ids = [FAISS_DEVICE.index]

        # Create coarse quantizer
        quantizer = faiss.IndexFlat(d, faiss.METRIC_INNER_PRODUCT)

        # Create IVFPQ index
        print(
            f"IVFPQ index with {d} dimensions, {n_total} vectors --- {nlist} cells, {m} sub-vectors, and {nbits} bits..."
        )
        index = faiss.IndexIVFPQ(
            quantizer, d, nlist, m, nbits, faiss.METRIC_INNER_PRODUCT
        )

        # Move index to multiple GPUs
        index = faiss.index_cpu_to_gpus_list(index=index, gpus=gpu_ids)

        # Fetch vectors and accumulate until we have at least 15 million
        retrieved_vectors = []
        print("Retrieving vectors...")
        while (len(retrieved_vectors) * batch_size) < train_total:
            batch = list(islice(embeddings_iter_train, batch_size))
            if len(batch) > 0:
                retrieved_vectors.append(batch)
            else:
                break

        # Convert to NumPy array for training
        retrieved_vectors = np.vstack(retrieved_vectors).astype(np.float32)

        # Train the index with 15M vectors
        print(f"Training index on {retrieved_vectors.shape} vectors...")
        index.train(retrieved_vectors)
        del retrieved_vectors
        print("Training complete.")

        # Add vectors in batches
        print("Adding vectors in batches...")
        i = 0
        while True:
            vectors = list(islice(embeddings_iter_add, batch_size))
            if vectors == []:
                break
            batch_size_actual = len(vectors)
            index.add(np.vstack(vectors).astype(np.float32))
            print(f"Added {i + batch_size_actual}/{n_total} vectors")
            i += batch_size_actual

        # Move index back to CPU before saving
        index = faiss.index_gpu_to_cpu(index)

        # Save index to disk
        print(f"Writing index to {index_file}...")
        faiss.write_index(index, index_file)
        print(f"Index saved with {index.ntotal} vectors.")

        # Upload to repo
        print("Uploading index...")
        api = HfApi()
        api.upload_file(
            path_or_fileobj=index_file,
            path_in_repo="faiss_index/finetemplates.index",
            repo_id="fineinstructions/finetemplates",
            repo_type="dataset",
        )
        print("Done uploading.")

        DOC_1 = """Discover the cosmos! Each day a different image or photograph of our fascinating universe is featured, along with a brief explanation written by a professional astronomer.
2010 August 12
Explanation: Each August, as planet Earth swings through dust trailing along the orbit of periodic comet Swift-Tuttle, skygazers can enjoy the Perseid Meteor Shower. The shower should build to its peak now, best seen from later tonight after moonset, until dawn tomorrow morning when Earth moves through the denser part of the wide dust trail. But shower meteors have been spotted for many days, like this bright Perseid streaking through skies near Lake Balaton, Hungary on August 8. In the foreground is the region's Church of St. Andrew ruin, with bright Jupiter dominating the sky to its right. Two galaxies lie in the background of the wide-angle, 3 frame panorama; our own Milky Way's luminous arc, and the faint smudge of the more distant Andromeda Galaxy just above the ruin's leftmost wall. If you watch for Perseid meteors tonight, be sure and check out the early evening sky show too, featuring bright planets and a young crescent Moon near the western horizon after sunset.
Authors & editors:
Jerry Bonnell (UMCP)
NASA Official: Phillip Newman Specific rights apply.
A service of: ASD at NASA / GSFC
& Michigan Tech. U."""

        DOC_2 = """Question: How is bipolar disorder different from unipolar depression or 'regular' depression?
Answer: Both bipolar disorder and major depression are typically associated with depressive episodes. So both illnesses are accompanied by depressions. The difference is that in bipolar disorder people also have periods of elevation -- or severe irritability. We call these manic or hypomanic episodes.
"""

        DOC_3 = """Yesterday’s House passage of cap-and-trade legislation designed to confront climate change is a landmark achievement, the first tangible step taken by the country that emits more greenhouse gas per capita than anyone in the world.
The bill itself still faces a tough test in the Senate. Passage is far from assured, and without similar actions by other major emitting countries, it won’t mean much. But it does finally demonstrate to the rest of the world that the United States is prepared to do its part, which puts the pressure on them to follow suit.
The bill itself, the product of a thousand political compromises, also isn’t perfect. But it also isn’t what its hysterical opponents claim it is. As Bryan Walsh acknowledges in Time:
… critics have vastly overstated the likely cost. In fact, they’re all but lying. During the House debate, Republican whip Eric Cantor, using numbers from an American Petroleum Institute study, said that the bill would eventually cost more than $3,000 per family per year — but those numbers assume that billions of tons worth of inexpensive carbon offsets won’t be available under the bill, which would significantly inflate the overall cost. That’s not going to happen. A more reliable study from the nonpartisan Congressional Budget Office forecast that the bill would cost the average U.S. household $175 in higher energy costs annually by 2020 — and other studies estimate that the energy-efficiency provisions in the bill might even save Americans money over time.
When opponents are forced to lie so blatantly — in this case exaggerating the likely cost 17 times over — they don’t have much of an honest argument."""

        DOC_4 = """The significance of Alabama Unionists during the Civil War and Reconstruction has long been a subject of study among scholars. Largely centered in northern Alabama and to a lesser degree in the southeast region and in Montgomery and Mobile, Unionists were important both militarily and politically. Until recently, however, the details of this phenomenon have remained less well known, largely because the term Unionist (both then and now) has been used to refer to a range of different individuals and positions.
In the broadest sense, Unionist has meant any white person who opposed secession (including those who later supported the Confederacy) and those who came to support the Union during the war despite having originally supported the Confederacy. This broad definition includes a very wide range of Alabamians—from the most well-to-do planters who ultimately become officers in the Confederate Army to the subsistence farmer who deserted the southern cause midway through the war. It is also possible to define Unionism more narrowly, confining the label to those individuals who resisted both secession and the Confederacy during the war. Such unconditional loyalists probably represented no more than 15 percent of Alabama's adult white population. They were mostly nonslaveholding farmers (though a small minority owned slaves) living in the northern third of the state. A few Unionists also lived in the piney woods and coastal plain further south. In many respects, these men and women were very much like their neighbors who supported the Confederate cause. The reasons they remained loyal to the Union were also quite diverse. Many saw secession as illegal, whereas others felt that it would dishonor the American Revolution and their own ancestors. Still others were certain that secession would end in political or military disaster. Many were influenced by the respected figures in their families or neighborhoods.
Unionism in Alabama arose under the pressures of the presidential election of 1860. Nine months before, the state legislature had directed that, in the event of a Republican's election, a state secession convention would be called. By directly linking the presidential election to secession, the legislature fostered a political atmosphere that was particularly hostile to Unionists. Newspaper editorials and participants at community meetings condemned as traitors those who canvassed for Illinois senator Stephen Douglas, the nominee of the regular Democratic Party, rather than the southern-rights Democratic nominee, John Breckinridge. In the election, fully 80 percent of Alabama's eligible voters participated, giving Breckinridge a substantial victory, with 54 percent of the vote. John Bell, the Constitutional Union candidate who was supported by a number of Alabamians hostile to secession, received 31 percent of the vote. Douglas, the candidate most associated with a strongly Unionist position, polled slightly more than 15 percent. Republican Abraham Lincoln was not even on the ballot in Alabama.
As promised, Alabama secessionists called a convention in the wake of Lincoln's election. The campaign for convention delegates provoked heated and sometimes violent debates among neighbors, forcing many to defend their positions in public. Of the 100 delegates elected, 53 were secessionists and 47 were cooperationists, a term that refers to the delegates' desire to secede only in "cooperation" with other southern states. In fact, the men elected on this platform represented a wide range of ideas about if, when, and under what circumstances to cooperate with secession and included a minority faction—probably less than one-third (the vast majority of them from the northern third of the state)—of unconditional Unionists who opposed secession outright.
These delegates convened in Montgomery on January 7, 1861, and debated secession for four days. On January 11, 1861, the convention passed Alabama's Ordinance of Secession by a vote of 61 to 39. Many of those who voted against the ordinance, however, ultimately did support secession, and four immediately reversed themselves and signed with the majority. Among the opposition, 33 delegates subsequently signed the "Address to the People of Alabama," in which they pledged to consult with their supporters and then act on their wishes. Ten signatories of the address signed the ordinance to satisfy their constituents. Other delegates who rejected the ordinance eventually took active part in the war. Only three signers—Henry C. Sanford of Cherokee County, Elliot P. Jones of Fayette County, and Robert Guttery of Walker County—never signed the ordinance and maintained their Unionism throughout the war. Only two wartime Unionists—R. S. Watkins of Franklin County and Christopher C. Sheats of Winston County—signed neither the "Address" nor the Ordinance of Secession.
Most of the men and women who supported the Union after Alabama's secession faced great difficulties. Many were ostracized and ridiculed by neighbors, called before community vigilance committees for questioning and intimidation, or actually harmed for endorsing the Union. Such treatment was most commonly meted out to those who publicly asserted their views; those who kept quiet and did not interfere with volunteering were often left alone during the first year of the war. After Confederate conscription began in April 1862, however, community tolerance of Unionists waned. Individuals who resisted the draft, for whatever reason, were subject to arrest and imprisonment. Family members who supported resisters were frequently threatened with violence or exile by conscript cavalry who hoped to pressure men to come in from the woods or mountains and surrender. In addition, it was not at all uncommon for the families of Unionists to be targeted for punitive foraging or arson by Confederate forces or local conscript cavalry.
After the Union Army invaded Alabama in early 1862, Unionists had more opportunities to flee behind Union lines for safety and the possibility of employment as soldiers, spies, or laborers. Most well known of Alabama's Union troops was the First Alabama Cavalry, U.S.A., organized in late 1862 by Brig. Gen. Grenville M. Dodge, stationed at Corinth, Mississippi. The regiment served mostly in northern Alabama, western Tennessee, and northeastern Mississippi, though it marched with Gen. William Tecumseh Sherman to Savannah in 1864. Alabama Unionists also joined other federal regiments, particularly those from Tennessee, Indiana, Illinois, and Ohio. Those who remained at home, both within Union-occupied territory and behind Confederate lines, also actively assisted Union forces as spies and guides. In some cases, they collaborated with local African Americans (most often their own slaves) to aid and abet the Union Army or pro-Union men in their neighborhoods. Moreover, African Americans from Alabama also crossed the Union lines to serve as laborers and soldiers, and after the Emancipation Proclamation went into effect in 1863, many were inducted into United States Colored Troops regiments. Almost 5,000 African Americans, or 6 percent of Alabama's black male population between the ages of 18 and 45, volunteered in the Union ranks.
As was the case throughout the South, by the midpoint of the war Alabama's original Unionists were increasingly joined in their dissent by deserters from the Confederate Army, mostly men whose families were struggling at home without their labor. Disillusioned by the realities of warfare, angered by the inequities of service under laws exempting slaveowners and selected professionals, such Alabamians generally wanted the war to end more than they desired Union victory, though some did cross lines and join the Union army rather than desert and avoid service altogether. A small peace movement also emerged at this time among men who had originally opposed secession but later supported the state.
After the war, Unionists continued to struggle politically and socially, for their wartime activities had alienated them from
their now-defeated neighbors. Most eagerly joined the Union League and the Republican Party. Some wartime Unionists helped reintroduce the Methodist-Episcopal Church (as contrasted with the Methodist-Episcopal Church, South) to northern Alabama, finding there a more hospitable environment
for worship. Many campaigned strenuously to convince the president and Congress to limit the political rights of former Confederates.
They also sought positions of local and state authority for others who had supported the Union during the war. At this point,
a number of men who had originally opposed secession but supported the state in 1861, as well as citizens who had become disillusioned
with the war, also moved to the fore of political life in Alabama. These moderates were, in general, encouraged by Pres. Andrew Johnson, who appointed such men to
positions of political authority in the immediate post-war provisional governments he established. The Republican Party in
Alabama was populated by such individuals, as well as core Unionists who had served in the Union Army or otherwise actively
resisted the Confederacy. Both groups were referred to by their Democratic opponents as sc alawags.
Under Congressional Reconstruction (1867-74) wartime loyalists gained greater political power than they had under Presidential Reconstruction, taking leading roles in the constitutional convention of 1867, the Freedmen's Bureau, and the Republican-dominated state legislature. Most also supported, though sometimes reluctantly, voting rights for African Americans as a means to gain political power over former Confederates. For their continued association with northern Republicans and support for African American equality, white Unionists were targeted for intimidation and physical violence by the Ku Klux Klan and other anti-Reconstruction vigilantes. As elsewhere in the South, Alabama Unionists and their Republican allies (white and black, northern and southern) received little in the way of federal assistance to defend against the onslaught of violence. As their party was overwhelmed by the Democratic opposition, Unionists retreated from the forefront of state politics, though those in communities with substantial loyalist populations continued in positions of local political leadership well into the late nineteenth century.
Barney, William L. The Secessionist Impulse: Alabama and Mississippi in 1860. Princeton: Princeton University Press, 1974.
Fitzgerald, Michael W. The Union League Movement in the Deep South: Politics and Agri cultural Change During Reconstruction. Baton Rouge: Louisiana State University Press, 1989.
Mills, Gary B. Southern Loyalists in the Civil War: The Southern Claims Commission. A Composite Directory of Case Files Created by the U.S. Commissioner of Claims, 1871-1880, including those appealed to the War Claims Committee of the U.S. House of Representatives and the U.S. Court of Claims. Baltimore: Genealogical Publishing Company, Inc. 1994.
Rogers, William Warren, Jr. The Confederate Home Front: Montgomery During the Civil War. Tuscaloosa: The University of Alabama Press, 1999.
Storey, Margaret M. Loyalty and Loss: Alabama's Unionists in the Civil War and Reconstruction. Baton Rouge: Louisiana State University Press, 2004.
Margaret M. Storey
Published December 14, 2007
Last updated October 3, 2011"""

        def nn(text):
            embeddings = np.vstack(
                embedder.run(texts=[text], truncate=True, batch_size=1)
            )
            k = 10
            distances, indices = index.search(embeddings, k)
            distances, indices = distances[0], indices[0]
            print("================================================================")
            print("DOC: ", text)
            print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
            for rank, (d, i) in enumerate(zip(distances, indices)):
                print("RANK:", rank)
                print("SIM:", d)
                print("IDX:", i)
                print("TEMPLATE:", templates_dataset.output.dataset[i.item()])

        print(time())
        nn(DOC_1)
        nn(DOC_2)
        nn(DOC_3)
        nn(DOC_4)
        print(time())


__all__ = ["create_template_index"]
