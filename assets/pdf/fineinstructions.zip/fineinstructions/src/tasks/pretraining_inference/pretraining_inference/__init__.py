import gc
import hashlib
import io
import itertools
import logging
import os
import random
import re
import sys
import threading
from functools import partial
from time import sleep, time

import click
import torch
from datadreamer import DataDreamer
from datadreamer.embedders import ParallelEmbedder
from datadreamer.llms import ParallelLLM
from datadreamer.steps import DataSource, HFHubDataSource, zipped
from datadreamer.utils.fs_utils import rm_dir, safe_fn
from datasets import Dataset, disable_caching, load_dataset
from datasets.exceptions import DatasetNotFoundError
from huggingface_hub import (
    HfApi,
    RepoCard,
    create_repo,
    hf_hub_download,
    list_repo_files,
    snapshot_download,
    upload_file,
)
from huggingface_hub.errors import RepositoryNotFoundError

from .custom_datadreamer_modules import (
    CoverageEmbeddingRetriever,
    CoverageSentenceTransformersEmbedder,
)
from .file_semaphore import FileSemaphore
from .prefetch_iterator import PrefetchIterator
from .processing import create_instantiation_prompts, explode_output_into_columns
from .sync_cache import (
    attach_sigterm_signal,
    create_handle,
    detach_sigterm_signal,
    initial_sync_on_load,
    remove_sigterm_signal,
)
from .vllm import VLLM

upload_semaphore = FileSemaphore(
    "upload_pretraining_inference_semaphore", max_acquire=5
)
upload_queue = []


def get_dataset_config_names(repo_id, repo_type="dataset"):
    return sorted(
        {
            p.split("/")[0]
            for p in list_repo_files(repo_id, repo_type=repo_type)
            if re.fullmatch(r"\d+", p.split("/")[0])
        }
    )


def upload_shard(ds, i, total_shards, repo_id, repo_type="dataset"):
    while True:
        try:
            try:
                create_repo(repo_id=repo_id, repo_type=repo_type, exist_ok=True)
            except Exception:
                pass

            buffer = io.BytesIO()
            ds.to_parquet(buffer)
            buffer.seek(0)

            upload_file(
                path_or_fileobj=buffer,
                # path_in_repo=f"data/train-{i:05d}-of-{total_shards:05d}.parquet",
                path_in_repo=f"{i}/train-00000-of-00001.parquet",
                repo_id=repo_id,
                repo_type=repo_type,
            )
            break
        except Exception as e:
            print(f"Error uploading file {i}: {str(e)}")
            sleep(3)


def document_and_template_generator(
    documents_and_templates_dataset, templates_dataset_rows
):
    def _document_and_template_generator(
        documents_and_templates_dataset, templates_dataset_rows
    ):
        indices = [
            row["results"]["indices"][:6]
            for row in documents_and_templates_dataset.output.dataset
        ]
        indices = list(set((itertools.chain.from_iterable(indices))))
        templates_dataset_rows_subset = templates_dataset_rows.select(
            indices, keep_in_memory=True
        )
        templates_dataset_rows_subset_dict = dict(
            zip(indices, templates_dataset_rows_subset)
        )
        del templates_dataset_rows_subset
        for row in documents_and_templates_dataset.output:
            for chunk_idx, idx in zip(
                row["results"]["chunks"][:6], row["results"]["indices"][:6]
            ):
                yield {
                    **row,
                    "chunk_idx": chunk_idx,
                    **templates_dataset_rows_subset_dict[idx],
                }

    return partial(
        _document_and_template_generator,
        documents_and_templates_dataset=documents_and_templates_dataset,
        templates_dataset_rows=templates_dataset_rows,
    )


@upload_semaphore.guard(timeout=180)
def try_upload(dataset, target_name, shard_idx, TOTAL_NUM_SHARDS):
    start_time = time()
    # Disable YAML validation
    HfApi._validate_yaml = lambda *args, **kwargs: print(
        "Skipping YAML README.md validation logic...", file=sys.stderr
    )
    RepoCard.validate = lambda *args, **kwargs: print(
        "Skipping YAML README.md validation logic...", file=sys.stderr
    )

    # Actual upload logic
    # dataset.push_to_hub(target_name, config_name=str(shard_idx), max_shard_size="5GB")
    upload_shard(dataset, shard_idx, TOTAL_NUM_SHARDS, target_name, repo_type="dataset")
    print(f"Uploaded: {shard_idx}")
    return time() - start_time


def upload_queue_handler():
    print("Launching upload queue handler...")
    global upload_queue
    while True:
        while len(upload_queue) == 0:
            sleep(1)
        try:
            (
                dataset,
                target_name,
                shard_idx,
                cache_dir,
                shared_cache_dir,
                TOTAL_NUM_SHARDS,
            ) = upload_queue.pop(0)
        except Exception:
            print("Exiting upload queue handler...")
            break
        start_time = time()
        upload_time = 0
        while True:
            try:
                upload_time = try_upload(
                    dataset, target_name, shard_idx, TOTAL_NUM_SHARDS
                )
                break
            except Exception as e:
                print(f"Error uploading {shard_idx}: {str(e)}")
                if "Too Many Requests" in str(e):
                    random_jitter_wait = int(random.uniform(15, 50))
                    print(f"Rate limit hit. Waiting {random_jitter_wait} seconds...")
                    sleep(random_jitter_wait)
                continue
        idle_time = time() - start_time - upload_time
        print(
            f"Upload for shard {shard_idx} completed in {upload_time:.2f} seconds. "
            f"Upload for shard {shard_idx} idle time: {idle_time:.2f} seconds."
        )
        print("Deleting cache directory...")
        try:
            rm_dir(cache_dir)
            print("Cache directory deleted.")
        except Exception as e:
            print(
                f"Error deleting cache directory (don't worry we'll just ignore this) {cache_dir}: {str(e)}"
            )
        try:
            if os.path.exists(shared_cache_dir):
                rm_dir(shared_cache_dir)
                print("Shared cache directory deleted.")
        except Exception as e:
            print(
                f"Error deleting shared cache directory (don't worry we'll just ignore this) {cache_dir}: {str(e)}"
            )
        remove_sigterm_signal(create_handle(cache_dir, shared_cache_dir))


@click.option(
    "--dataset", "-d", type=str, required=True, help="The dataset to process."
)
@click.option(
    "--shards", "-s", type=str, required=True, help="The range of shards to process."
)
@click.option(
    "--ebz",
    type=int,
    default=72,
    show_default=True,
    help="The batch size for embedding.",
)
@click.option(
    "--rbz",
    type=int,
    default=512,
    show_default=True,
    help="The batch size for retrieval.",
)
@click.option(
    "--ibz",
    type=int,
    default=20,
    show_default=True,
    help="The max_num_seqs for VLLM when performing instantiations.",
)
@click.option(
    "--iseqlen",
    type=int,
    default=11504,
    show_default=True,
    help="The max_num_batched_tokens for VLLM when performing instantiations.",
)
@click.option(
    "--templatetrunc",
    type=int,
    default=2500,
    show_default=True,
    help="The max chars allowed in a template before truncation.",
)
@click.option(
    "--doctrunc",
    type=int,
    default=12000,
    show_default=True,
    help="The max chars allowed in a document before truncation.",
)
@click.option(
    "--maxtokens",
    type=int,
    default=1000,
    show_default=True,
    help="The max tokens allowed to be output for inference decoding.",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="If set, perform a small dry run (first 10,000 rows) to test the end-to-end script.",
)
@click.option(
    "--no-upload",
    is_flag=True,
    default=False,
    help="If set, don't upload the dataset to the HF hub.",
)
# H100 args: ./run.sh  pretraining-inference --dataset fineinstructions-pretraining/nemotron_actual_1T --shards 0-1 --ebz 120 --rbz 2048 --ibz 60 --iseqlen 11504 --templatetrunc 2500 --doctrunc 12000 --maxtokens 1000
def pretraining_inference(  # noqa: C901
    ctx,
    dataset,
    shards,
    ebz,
    rbz,
    ibz,
    iseqlen,
    templatetrunc,
    doctrunc,
    maxtokens,
    dry_run,
    no_upload,
):
    from ....project import get_persistent_dir, get_torch_devices, reporter

    # Initialize CUDA early as possible to detect CUDA issues on the node
    torch._C._cuda_init()
    GPU_MEMORY_UTILIZATION = 0.90

    # Get attempt number
    attempt_num = int(os.environ.get("FINEINSTRUCTION_INFERENCE_ATTEMPT", "1"))
    if attempt_num > 1:
        ibz = max(int(ibz - (10 * (attempt_num - 1))), 1)
        GPU_MEMORY_UTILIZATION = max(0.90 - (0.05 * (attempt_num - 1)), 0.50)

    # Set truncation limit
    TEMPLATE_TRUNCATION_LIMIT = templatetrunc
    DOC_TRUNCATION_LIMIT = doctrunc

    # Start upload thread
    upload_thread = threading.Thread(target=upload_queue_handler)
    upload_thread.start()

    # Get scratch dir
    SCRATCH_DIR = os.environ.get("PROJECT_SCRATCH_DATA", None)
    if SCRATCH_DIR is not None:
        SCRATCH_DIR = os.path.join(
            SCRATCH_DIR, os.environ.get("PROJECT_SCRATCH_DATA_VERSION", "1")
        )
        scratch_dir_snapshot_download_kwargs = {
            "cache_dir": os.path.join(SCRATCH_DIR, "huggingface_cache")
        }
        scratch_dir_sentence_transformers_kwargs = {
            "cache_folder": os.path.join(SCRATCH_DIR, "huggingface_cache")
        }
        scratch_dir_vllm_kwargs = {
            "download_dir": os.path.join(SCRATCH_DIR, "huggingface_cache")
        }
    else:
        scratch_dir_snapshot_download_kwargs = {}
        scratch_dir_sentence_transformers_kwargs = {}
        scratch_dir_vllm_kwargs = {}

    # Get source and target dataset names
    source_name = dataset
    TARGET_NAME = source_name.replace("actual", "fineinstructions") + "_raw_bin"
    assert source_name != TARGET_NAME

    # Model name
    print("Pre-download necessary resources...")
    MODEL_NAME = "fineinstructions/template_instantiator"
    MODEL_REVISION = "763961cf996dd81727ceff46b1feaedab9e97ae1"
    while True:
        try:
            snapshot_download(
                repo_id=MODEL_NAME,
                revision=MODEL_REVISION,
                **scratch_dir_snapshot_download_kwargs,
            )
            snapshot_download(
                repo_id="fineinstructions/instruction_template_retrieval_embedding",
                revision="1d2f2e33b9d5f6fe250478af8b05e6d8c2038731",
                **scratch_dir_snapshot_download_kwargs,
            )
            snapshot_download(
                repo_id="fineinstructions/finetemplates",
                revision="da7b725f7c1248f8c632d7d53c94109ae5dadbfe",
                repo_type="dataset",
            )
            load_dataset(
                "fineinstructions/finetemplates",
                revision="da7b725f7c1248f8c632d7d53c94109ae5dadbfe",
                split="full",
            )
            hf_hub_download(
                "fineinstructions/finetemplates",
                "faiss_index/reweighting_stats.pkl",
                revision="da7b725f7c1248f8c632d7d53c94109ae5dadbfe",
                repo_type="dataset",
                **scratch_dir_snapshot_download_kwargs,
            )
            hf_hub_download(
                "fineinstructions/finetemplates",
                "faiss_index/finetemplates.index",
                revision="da7b725f7c1248f8c632d7d53c94109ae5dadbfe",
                repo_type="dataset",
                **scratch_dir_snapshot_download_kwargs,
            )
            break
        except Exception as e:
            print(f"Error pre-downloading resources: {str(e)}")
            print("Retrying in random jittered time...")
            random_jitter_wait = int(random.uniform(15, 50))
            print(f"Waiting {random_jitter_wait} seconds...")
            sleep(random_jitter_wait)
            continue
    gc.collect()
    print("Done with pre-download.")

    # Get devices
    INFERENCE_DEVICE = get_torch_devices()

    # Process shards
    while True:
        try:
            TOTAL_NUM_SHARDS = (
                max([int(s) for s in get_dataset_config_names(source_name)]) + 1
            )
            BIN_SIZE = 500
            TOTAL_NUM_BINS = (TOTAL_NUM_SHARDS + 1) // BIN_SIZE
            break
        except Exception as e:
            print(f"Error getting total number of shards. Retrying...{e}")
            continue
    shards = shards.replace(" ", "").lower()
    if shards == "all":
        shards = "0-" + str(TOTAL_NUM_SHARDS)
    shard_ranges = shards.split(",")
    shards_to_run = []
    for shard_range in shard_ranges:
        shard_start_idx = shard_range.split("-")[0]
        shard_end_idx = (
            shard_range.split("-")[1]
            if len(shard_range.split("-")) > 1
            else str(int(shard_range.split("-")[0]) + 1)
        )
        for shard_idx in range(int(shard_start_idx), int(shard_end_idx)):
            shards_to_run.append(shard_idx)
    del shard_idx, shard_range, shard_start_idx, shard_end_idx

    # Check what shards are already processed
    config_names = []
    for bin_idx in range(TOTAL_NUM_BINS + 1):
        while True:
            try:
                config_names += get_dataset_config_names(
                    TARGET_NAME.replace("_bin", f"_{bin_idx}")
                )
                break
            except (DatasetNotFoundError, RepositoryNotFoundError):
                config_names += []
                break
            except Exception as e:
                print(f"Error checking if shards exists. Retrying...{e}")
                sleep(10)
                continue
    shards_to_run = [s for s in shards_to_run if str(s) not in config_names]

    # Setup DataDreamer
    reporter.set(
        "pretraining_inference.datadreamer_output",
        "pretraining_inference.datadreamer_output",
    )
    datadreamer_output_dir = get_persistent_dir(
        "datadreamer_output", "pretraining_inference.datadreamer_output"
    )

    cache_key = f"pretraining_inference_{source_name}_{MODEL_REVISION}__{iseqlen}_{templatetrunc}_{doctrunc}_{maxtokens}"
    cache_key = hashlib.sha256(cache_key.encode()).hexdigest()
    for output_term in [sys.stderr, sys.stdout]:
        # Do the prints below to each terminal
        print("ATTEMPT:", attempt_num, file=output_term)
        print("CACHE KEY:", cache_key, file=output_term)
        print("INFERENCE DEVICE:", INFERENCE_DEVICE, file=output_term)
        print(
            "TEMPLATE_TRUNCATION_LIMIT: ", TEMPLATE_TRUNCATION_LIMIT, file=output_term
        )
        print("DOC_TRUNCATION_LIMIT: ", DOC_TRUNCATION_LIMIT, file=output_term)
        print("MAX_NEW_TOKENS: ", maxtokens, file=output_term)
        print("BZs: ", ebz, rbz, ibz, iseqlen, GPU_MEMORY_UTILIZATION, file=output_term)
    os.environ["VLLM_DO_NOT_TRACK"] = "1"
    os.environ["DO_NOT_TRACK"] = "1"
    os.environ["VLLM_NO_USAGE_STATS"] = "1"
    # os.environ["VLLM_ATTENTION_BACKEND"] = "FLASHINFER"
    os.environ["VLLM_FLASHINFER_FORCE_TENSOR_CORES"] = "1"
    os.environ["HF_HUB_DOWNLOAD_TIMEOUT"] = "120"

    with DataDreamer(":memory:", log_date=True, log_level=logging.DEBUG):
        # Get all templates
        while True:
            try:
                templates_dataset = HFHubDataSource(
                    "Get Templates Dataset",
                    "fineinstructions/finetemplates",
                    revision="da7b725f7c1248f8c632d7d53c94109ae5dadbfe",
                    split="full",
                )
                break
            except ValueError as e:
                print(
                    f"Error loading HF fineinstructions/finetemplates: {str(e)}, retrying..."
                )
                sleep(3)
        templates_dataset_rows = templates_dataset.output.dataset

    # Process each shard
    disable_caching()
    for current_shard_idx in shards_to_run:
        shared_cache_dir = os.path.join(
            datadreamer_output_dir,
            ".cache",
            safe_fn(str(current_shard_idx)),
            safe_fn(cache_key),
        )
        if SCRATCH_DIR is not None:
            cache_dir = os.path.join(
                SCRATCH_DIR,
                ".cache",
                safe_fn(str(current_shard_idx)),
                safe_fn(cache_key),
            )
        else:
            cache_dir = shared_cache_dir

        initial_sync_on_load(cache_dir, shared_cache_dir)
        attach_sigterm_signal(cache_dir, shared_cache_dir)

        current_bin_idx = current_shard_idx // BIN_SIZE
        target_name = TARGET_NAME.replace("_bin", f"_{current_bin_idx}")
        print(f"Processing shard #{current_shard_idx}/{TOTAL_NUM_SHARDS}...")

        # Check if shard exists
        should_skip = False
        while True:
            try:
                if str(current_shard_idx) in get_dataset_config_names(target_name):
                    print(f"Shard {current_shard_idx} already exists. Skipping...")
                    should_skip = True
                else:
                    should_skip = False
                break
            except (DatasetNotFoundError, RepositoryNotFoundError):
                should_skip = False
                break
            except Exception as e:
                print(f"Error checking if shard exists. Retrying...{e}")
                sleep(10)
                continue
        if should_skip:
            continue

        with DataDreamer(":memory:", log_date=True, log_level=logging.DEBUG):
            # Get shard
            while True:
                try:
                    documents_shard = HFHubDataSource(
                        f"Get Pre-Training Documents for shard {current_shard_idx}",
                        source_name,
                        data_files=f"{current_shard_idx}/train-*.parquet",
                        split="train",
                    )
                    break
                except ValueError as e:
                    print(f"Error loading HF {source_name}: {str(e)}, retrying...")
                    sleep(3)
            shard_len = len(documents_shard.output.dataset)
            if dry_run:
                documents_shard = documents_shard.take(10000)
            documents_shard = documents_shard.map(
                lambda row: {"text_trunc": row["text"][:DOC_TRUNCATION_LIMIT]},
                name=f"Shorten documents for shard {current_shard_idx}",
                lazy=False,
                total_num_rows=shard_len,
            )

            # Get "text" column
            documents = documents_shard.select_columns(
                ["text_trunc"],
                name=f"Select 'text_trunc' column for shard {current_shard_idx}",
                lazy=True,
            )

            # Create a retriever
            embedder = ParallelEmbedder(
                *[
                    CoverageSentenceTransformersEmbedder(
                        "fineinstructions/instruction_template_retrieval_embedding",
                        revision="1d2f2e33b9d5f6fe250478af8b05e6d8c2038731",
                        device=d,
                        dtype="bfloat16",
                        cache_folder_path=cache_dir,
                        **scratch_dir_sentence_transformers_kwargs,
                    )
                    for d in get_torch_devices()[1:]
                ]
            )
            query_embeddings = embedder.run(
                [
                    row["text_trunc"]
                    for row in documents.output["text_trunc"].dataset.to_list()
                ],
                truncate=True,
                batch_size=ebz,
                return_generator=True,
                force=False,
            )
            retriever = CoverageEmbeddingRetriever(
                texts=DataSource("Dummy Templates", data=[{"template": ""}])
                .take(1)
                .output["template"],
                embedder=embedder,
                index_batch_size=1,
                truncate=True,
                device=get_torch_devices()[0:1],
                cache_folder_path=cache_dir,
                **scratch_dir_snapshot_download_kwargs,
            )
            query_embeddings = PrefetchIterator(
                slow_iter=query_embeddings, max_prefetch=(10 * rbz)
            )
            most_compatible_templates = [
                row
                for row in retriever.run(
                    query_embeddings,
                    k=2047,
                    batch_size=rbz,
                    return_generator=False,
                    force=False,
                )
            ]
            most_compatible_templates = DataSource(
                "Get Most Compatible Templates",
                data={"results": most_compatible_templates},
            )

            # Combine documents and templates
            documents_and_templates = zipped(
                documents_shard,
                most_compatible_templates,
                name="Combine documents + templates",
                lazy=False,
            )
            embedder.unload_model()
            retriever.index[0].proxy.unload()
            retriever_process = retriever.index[0].process

            del documents_shard, embedder, retriever
            gc.collect()
            try:
                retriever_process.kill()
                print("Cleanly killed retriever process.", file=sys.stderr)
            except Exception as e:
                print(
                    f"Couldn't cleanly kill retriever process (already killed, safe to ignore): {e}",
                    file=sys.stderr,
                )
                pass

            # 6 rows per document for each retrieved template
            documents_and_templates_iterator = list(
                document_and_template_generator(
                    documents_and_templates, templates_dataset_rows
                )()
            )
            del (
                documents,
                query_embeddings,
                most_compatible_templates,
                documents_and_templates,
            )
            gc.collect()

            # Create prompts
            instantiation_prompts = [
                create_instantiation_prompts(
                    DOC_TRUNCATION_LIMIT, TEMPLATE_TRUNCATION_LIMIT, row
                )["prompt"]
                for row in documents_and_templates_iterator
            ]
            instantiation_prompts_sort_results = sorted(
                enumerate(instantiation_prompts), key=lambda x: len(x[1]), reverse=True
            )
            sorted_indices, instantiation_prompts = zip(
                *instantiation_prompts_sort_results
            )
            del instantiation_prompts_sort_results

            # Generate instantiations
            torch.cuda.empty_cache()
            INSTANTIATION_BATCH_SIZE = 18000
            RESET_VLLM_EVERY_N_BATCHES = (
                1  # https://github.com/vllm-project/vllm/issues/16050
            )
            OUTER_INSTANTIATION_BATCH_SIZE = (
                INSTANTIATION_BATCH_SIZE
                * RESET_VLLM_EVERY_N_BATCHES
                * len(INFERENCE_DEVICE)
            )
            instantiations = []
            for i in range(
                0, len(instantiation_prompts), OUTER_INSTANTIATION_BATCH_SIZE
            ):
                instantiation_prompts_batch = instantiation_prompts[
                    i : i + OUTER_INSTANTIATION_BATCH_SIZE
                ]
                if len(instantiation_prompts_batch) > 0:
                    instantiator_model = ParallelLLM(
                        *[
                            VLLM(
                                cache_folder_path=cache_dir,
                                model_name=MODEL_NAME,
                                revision=MODEL_REVISION,
                                device=inf_device,
                                tensor_parallel_size=1,
                                dtype=torch.bfloat16,
                                disable_log_stats=True,
                                enable_chunked_prefill=False,
                                enable_prefix_caching=False,
                                enforce_eager=False,
                                disable_custom_all_reduce=False,
                                gpu_memory_utilization=GPU_MEMORY_UTILIZATION,
                                max_model_len=11500,
                                max_num_seqs=ibz,
                                max_num_batched_tokens=iseqlen,
                                **scratch_dir_vllm_kwargs,
                            )
                            for inf_device in INFERENCE_DEVICE
                        ]
                    )
                    instantiations += instantiator_model.run(
                        instantiation_prompts_batch,
                        batch_size=INSTANTIATION_BATCH_SIZE,
                        temperature=0.0,
                        top_p=0.0,
                        max_new_tokens=maxtokens,
                        force=False,
                        return_generator=False,
                    )
                    for im_llm in instantiator_model.llms:
                        im_llm.unload_model()
                    del instantiator_model
                    gc.collect()
                    torch.cuda.empty_cache()

            # Restore original order
            instantiation_prompts_original_order = [None] * len(instantiation_prompts)
            instantiations_original_order = [None] * len(instantiations)
            for o_idx, sorted_idx in enumerate(sorted_indices):
                instantiation_prompts_original_order[
                    sorted_idx
                ] = instantiation_prompts[o_idx]
                instantiations_original_order[sorted_idx] = instantiations[o_idx]
            instantiation_prompts = instantiation_prompts_original_order
            instantiations = instantiations_original_order
            del (
                instantiation_prompts_original_order,
                instantiations_original_order,
                sorted_indices,
            )

            print("Exploding output into columns...", file=sys.stderr)
            instantiations_data = [
                {"prompts": prompt, "instantiation_object": obj}
                for prompt, obj in zip(instantiation_prompts, instantiations)
            ]

            transformed_instantiations = []
            for row in instantiations_data:
                transformed = explode_output_into_columns(row)
                transformed_instantiations.append(transformed)

            del instantiation_prompts, instantiations, instantiations_data
            gc.collect()

            print("Combine with metadata...", file=sys.stderr)
            selected_docs = [
                {
                    **(
                        {"warc_record_id": row["warc_record_id"]}
                        if "warc_record_id" in row
                        else {}
                    ),
                    "text": (
                        (row["text"].encode("utf-8", errors="replace").decode("utf-8"))
                        if isinstance(row["text"], str)
                        else row["text"]
                    ),
                    "token_count": row["token_count"],
                    "template_id": row["template_id"],
                }
                for row in documents_and_templates_iterator
            ]
            del documents_and_templates_iterator
            gc.collect()

            combined = []
            for doc, inst in zip(selected_docs, transformed_instantiations):
                merged = {**doc, **inst}
                combined.append(merged)
            del transformed_instantiations, selected_docs
            gc.collect()

            print("Filter failed outputs...", file=sys.stderr)
            filtered_combined = [
                row
                for row in combined
                if row.get("instantiated_instruction") is not None
                and row.get("answer") is not None
            ]

            del combined
            gc.collect()

            print("Build dataset to upload...", file=sys.stderr)
            combined = Dataset.from_list(filtered_combined)

            del filtered_combined
            gc.collect()

        with DataDreamer(
            datadreamer_output_dir, log_date=True, log_level=logging.DEBUG
        ):
            if not no_upload:
                while True:
                    try:
                        upload_queue.append(
                            (
                                combined,
                                target_name,
                                current_shard_idx,
                                cache_dir,
                                shared_cache_dir,
                                TOTAL_NUM_SHARDS,
                            )
                        )
                        break
                    except Exception as e:
                        print(f"Error uploading: {e}")
                        sleep(10)
                        continue

    # Exit the upload queue
    upload_queue.append(None)
    while upload_thread.is_alive():
        print("Waiting for uploads...")
        sleep(1)
    try:
        detach_sigterm_signal()
    except Exception as e:
        print(f"Error detaching SIGTERM signal: {e}", file=sys.stderr)
        pass
    print("All uploads done.")


__all__ = ["pretraining_inference"]
