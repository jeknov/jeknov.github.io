import queue
import threading


class PrefetchIterator:
    def __init__(self, slow_iter, max_prefetch=10):
        self._iter = iter(slow_iter)
        self._queue = queue.Queue(max_prefetch)
        self._sentinel = object()
        self._exception = None
        self._done = False

        self._thread = threading.Thread(target=self._worker)
        self._thread.daemon = True
        self._thread.start()

    def _worker(self):
        try:
            for item in self._iter:
                self._queue.put(item)
        except Exception as e:
            self._exception = e
        finally:
            self._queue.put(self._sentinel)

    def __iter__(self):
        return self

    def __next__(self):
        if self._done:
            raise StopIteration
        item = self._queue.get()
        if item is self._sentinel:
            self._done = True
            if self._exception:
                raise self._exception
            raise StopIteration
        return item
