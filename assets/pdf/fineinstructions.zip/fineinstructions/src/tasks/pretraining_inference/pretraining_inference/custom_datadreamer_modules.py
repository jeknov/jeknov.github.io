import concurrent.futures
import gc
import itertools
import os
import pickle
import socket
import tempfile
from functools import cache, cached_property
from random import Random

import numpy as np
import torch
from datadreamer.embedders import SentenceTransformersEmbedder
from datadreamer.retrievers import EmbeddingRetriever
from datadreamer.utils.background_utils import (
    dill_serializer,
    proxy_resource_in_background,
)
from datadreamer.utils.import_utils import (
    ignore_faiss_warnings,
    ignore_transformers_warnings,
)
from filelock import FileLock
from huggingface_hub import hf_hub_download
from sqlitedict import SqliteDict

from .pooling_coverage import use_gaussian_coverage_pooling

with ignore_transformers_warnings():
    from sentence_transformers import SentenceTransformer

with ignore_faiss_warnings():
    import faiss

coverage_chunks = 5
sigma = 0.05
alpha = 1.0
score_threshold = 0.865


class CoverageSentenceTransformersEmbedder(SentenceTransformersEmbedder):
    @cached_property
    def model(self) -> SentenceTransformer:
        return use_gaussian_coverage_pooling(
            SentenceTransformersEmbedder.model.func(self),
            coverage_chunks=coverage_chunks,
            sigma=sigma,
            alpha=alpha,
        )

    @cached_property
    def dims(self) -> int:
        return SentenceTransformersEmbedder.dims.func(self) * coverage_chunks

    @torch.no_grad()
    def _run_batch(self, *args, **kwargs) -> list[np.ndarray]:
        kwargs["normalize_embeddings"] = False
        return SentenceTransformersEmbedder._run_batch(self, *args, **kwargs)


@cache
def load_reweighting_stats():
    # Load resampling stats
    pkl_lock = FileLock(
        os.path.join(tempfile.gettempdir(), "fi-faiss_reweighting.flock")
    )
    with pkl_lock:
        pkl_path = hf_hub_download(
            "fineinstructions/finetemplates",
            "faiss_index/reweighting_stats.pkl",
            revision="da7b725f7c1248f8c632d7d53c94109ae5dadbfe",
            repo_type="dataset",
            cache_dir=cache_dir,
        )
    with open(pkl_path, "rb") as reweighting_stats_fp:
        reweighting_stats = pickle.load(reweighting_stats_fp)

    resampling_weights = reweighting_stats["resampling_weights"]
    template_variable_count_mapping = reweighting_stats[
        "template_variable_count_mapping"
    ]
    return resampling_weights, template_variable_count_mapping


def _reweight_and_filter(inp, k=None, reweight=True):
    if reweight:
        inp0, inp = itertools.tee(inp)
        first_row = next(inp0)
        r = Random(first_row[1].item())
        epsilon = 0.05
        bucket = first_row[1]
        items = []
        weights = []
        for i, s in inp:
            if abs(bucket - s.item()) <= epsilon:
                items.append((i, s))
                weights.append(
                    load_reweighting_stats()[0][load_reweighting_stats()[1][i.item()]]
                )
            else:
                break
        if len(items) > 0:
            return [
                x
                for x in r.choices(
                    items, weights=weights, k=(len(items) if k is None else k)
                )
                if x[1] >= score_threshold
            ]
        else:
            return []
    else:
        return list(inp)


def _reweight_filter_and_dedup(args):
    indices_per_chunk, scores_per_chunk = args
    new_scores_per_chunk = []
    new_indices_per_chunk = []
    for indices, scores in zip(indices_per_chunk, scores_per_chunk):
        output = _reweight_and_filter(zip(indices, scores), reweight=True)
        if len(output) == 0:
            output = _reweight_and_filter(zip(indices, scores), reweight=False)
        if len(output) == 0:
            indices, scores = [], []
        else:
            output = list(zip(*output))
            indices, scores = list(output[0]), list(output[1])
        new_indices_per_chunk.append(indices)
        new_scores_per_chunk.append(scores)
    rows_per_chunk = [
        [{"chunk": chunk_idx, "index": i.item()} for i, s in zip(indices, scores)]
        for chunk_idx, (indices, scores) in enumerate(
            zip(new_indices_per_chunk, new_scores_per_chunk)
        )
    ]
    skip = set()
    seen = set()
    true_coverage_chunks = coverage_chunks + 1
    num_to_keep = true_coverage_chunks**2
    flattened_rows = []
    chunk_rows = []
    index_rows = []
    for chunk_idx in itertools.cycle(range(true_coverage_chunks)):
        if len(flattened_rows) >= num_to_keep:
            break
        if len(skip) == true_coverage_chunks:
            break
        if chunk_idx in skip:
            continue
        found = False
        for row in rows_per_chunk[chunk_idx]:
            if row["index"] not in seen:
                found = True
                seen.add(row["index"])
                flattened_rows.append(row)
                chunk_rows.append(row["chunk"])
                index_rows.append(row["index"])
                break
        if not found:
            skip.add(chunk_idx)
    assert len(index_rows) == len(chunk_rows)
    return index_rows[:num_to_keep], chunk_rows[:num_to_keep]


cache_dir = None


class CoverageEmbeddingRetriever(EmbeddingRetriever):
    def __init__(self, *args, **kwargs):
        global cache_dir
        # Call super's __init__()
        if "cache_dir" in kwargs:
            cache_dir = kwargs.pop("cache_dir")
            self.cache_dir = cache_dir
        else:
            cache_dir = None
            self.cache_dir = None
        super().__init__(*args, **kwargs)

    @cached_property
    def index(self):  # noqa: C901
        class FAISSIndexResource:
            def __init__(self_resource) -> None:
                global cache_dir
                cache_dir = self.cache_dir
                import threading
                import time
                from datetime import datetime

                if "seas.upenn.edu" in socket.gethostname():
                    threading.Thread(
                        target=lambda: [
                            print(
                                "FAISS process is alive",
                                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            )
                            or time.sleep(10)
                            for _ in iter(int, 1)
                        ],
                        daemon=True,
                    ).start()
                faiss_index_lock = FileLock(
                    os.path.join(tempfile.gettempdir(), "fi-faiss_index.flock")
                )
                with faiss_index_lock:
                    faiss_index_path = hf_hub_download(
                        "fineinstructions/finetemplates",
                        "faiss_index/finetemplates.index",
                        revision="da7b725f7c1248f8c632d7d53c94109ae5dadbfe",
                        repo_type="dataset",
                        cache_dir=cache_dir,
                    )
                index = faiss.read_index(
                    faiss_index_path, faiss.IO_FLAG_MMAP | faiss.IO_FLAG_READ_ONLY
                )
                index.nprobe = 150
                if self.device is not None:  # pragma: no cover
                    index = faiss.index_cpu_to_gpus_list(index=index, gpus=self.device)
                index_lookup = SqliteDict(
                    ":memory:", tablename="lookup", journal_mode="WAL", autocommit=False
                )
                self_resource.index = index
                self_resource.index_lookup = index_lookup
                self_resource.executor = concurrent.futures.ProcessPoolExecutor(
                    max_workers=os.cpu_count()
                )

            @dill_serializer
            def search(self_resource, vecs, *args, **kwargs) -> None:
                global cache_dir
                cache_dir = self.cache_dir
                returned_coverage_chunks = coverage_chunks + 1
                vecs = vecs.reshape(-1, vecs.shape[1] // (returned_coverage_chunks))
                vecs = np.vstack(vecs)
                scores_batch, indices_batch = self_resource.index.search(
                    vecs, *args, **kwargs
                )
                scores_per_input, indices_per_input = (
                    [
                        scores_batch[i : i + returned_coverage_chunks]
                        for i in range(0, len(scores_batch), returned_coverage_chunks)
                    ],
                    [
                        indices_batch[i : i + returned_coverage_chunks]
                        for i in range(0, len(indices_batch), returned_coverage_chunks)
                    ],
                )
                results_per_input = list(
                    self_resource.executor.map(
                        _reweight_filter_and_dedup,
                        zip(indices_per_input, scores_per_input),
                    )
                )
                return results_per_input

            def decode(self_resource, *args, **kwargs):
                return self_resource.index_lookup.decode(*args, **kwargs)

            def select(self_resource, *args, **kwargs):
                return self_resource.index_lookup.conn.select(*args, **kwargs)

            def unload(self_resource, *args, **kwargs):
                self_resource.index = None
                gc.collect()

        env = os.environ.copy()
        faiss_resource = proxy_resource_in_background(
            FAISSIndexResource, env=env, run_in_background=True
        )
        return (faiss_resource, faiss_resource)

    def _run_batch(self, max_length_func, inputs, k: int = 5, batch_size=4, **kwargs):
        queries = inputs
        final_kwargs = self.kwargs.copy()
        final_kwargs.update(kwargs)
        queries_embedded = np.vstack(queries)
        index, _ = self.index
        results_per_query = index.proxy.search(queries_embedded, k=k)
        return [
            {"indices": index_rows, "chunks": chunk_rows}
            for index_rows, chunk_rows in results_per_query
        ]
