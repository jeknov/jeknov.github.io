import json
import re
import string


def create_instantiation_prompts(doc_truncation_limit, template_truncation_limit, row):
    extra_limit = doc_truncation_limit - len(row["text_trunc"])
    input_json = json.dumps(
        {
            "instruction_template": row["template"][
                : (template_truncation_limit + extra_limit)
            ],
            "document": row["text_trunc"],
        },
        indent=2,
    )
    return {"prompt": input_json}


def expand(document, text):
    text = re.sub(
        r"<excerpt>(.*?)<\.\.\.([^>]{1}?)(.*?)</excerpt>",
        r"<excerpt>\1<...>\2\3</excerpt>",
        text,
    )  # Fix broken ellipsis
    excerpt_pattern = r"<excerpt>(.*?)<\.\.\.>(.*?)</excerpt>"
    matches = re.findall(excerpt_pattern, text, flags=re.DOTALL)
    replacements = {}
    for prefix, suffix in matches:
        orig_prefix, orig_suffix = prefix, suffix
        prefix_pre = ""
        while True:
            match = re.search(
                re.escape(prefix) + r"(.*?)" + re.escape(suffix),
                document,
                flags=re.DOTALL,
            )
            try:
                if match:
                    replacements[
                        f"<excerpt>{orig_prefix}<...>{orig_suffix}</excerpt>"
                    ] = prefix_pre + match.group(0)
                    break
                else:
                    if prefix not in document and len(prefix.split(" ")) > 1:
                        if prefix_pre == "":
                            prefix = (
                                prefix[:-1]
                                if prefix and prefix[-1] in string.punctuation
                                else prefix
                            )
                        prefix_pre = prefix.split(" ")[0] + " "
                        prefix = " ".join(prefix.split(" ")[1:])
                        continue
                    if suffix not in document and len(suffix.split(" ")) > 1:
                        suffix = " ".join(suffix.split(" ")[1:])
                        continue
                    return None
            except Exception:
                return None
    for old, new in replacements.items():
        text = text.replace(old, new)
    if "<...>" in text or "<excerpt" in text or "</excerpt" in text:
        return None
    return text


def explode_output_into_columns(row):
    output = {"instantiated_instruction": None, "answer": None}
    try:
        extracted_output = json.loads(row["instantiation_object"])
        if isinstance(extracted_output, dict):
            output.update(extracted_output)
    except json.JSONDecodeError:
        pass
    if output["instantiated_instruction"] is None:
        output["answer"] = None
    if output["answer"] is None:
        output["instantiated_instruction"] = None

    clean_unicode = lambda x: (  # noqa: E731
        (x.encode("utf-8", errors="replace").decode("utf-8"))
        if isinstance(x, str)
        else x
    )
    return {
        "instantiated_instruction": (
            clean_unicode(
                expand(
                    json.loads(row["prompts"])["document"],
                    str(output["instantiated_instruction"]),
                )
            )
            if output["answer"]
            else None
        ),
        "answer": (
            clean_unicode(
                expand(json.loads(row["prompts"])["document"], str(output["answer"]))
            )
            if output["answer"]
            else None
        ),
    }
