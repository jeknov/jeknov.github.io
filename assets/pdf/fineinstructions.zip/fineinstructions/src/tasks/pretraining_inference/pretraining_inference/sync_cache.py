import shutil
import signal
import sys
from concurrent.futures import ThreadPoolExecutor, wait
from datetime import datetime
from pathlib import Path
from typing import Dict, List

# Store all attached cache pairs
_attached_cache_pairs: List[Dict] = []

# Global thread pool (created lazily when SIGTERM handler is attached)
_thread_pool: ThreadPoolExecutor = None


def _log(msg: str):
    """Log to stderr with cache sync prefix."""
    print(f"[CACHE SYNC ROUTINE] {msg}", file=sys.stderr, flush=True)


def _dir_is_empty_or_missing(path_str: str) -> bool:
    path = Path(path_str)
    return not path.exists() or not any(path.iterdir())


def _atomic_copy(src: Path, dst: Path):
    """Copy a file to a temporary .synctmp file and atomically rename it."""
    tmp_path = dst.with_suffix(dst.suffix + ".synctmp")
    shutil.copy2(src, tmp_path)  # copy metadata too
    tmp_path.replace(dst)  # atomic replace


def _copy_dir(src_str: str, dst_str: str):
    global _thread_pool
    if _thread_pool is None:
        _thread_pool = ThreadPoolExecutor(max_workers=16)
    src = Path(src_str)
    dst = Path(dst_str)

    if _dir_is_empty_or_missing(src_str):
        _log(f"Skipping copy: source {src} missing or empty.")
        return

    dst.mkdir(parents=True, exist_ok=True)

    futures = []
    for item in src.iterdir():
        s = item
        d = dst / item.name
        if s.is_dir():
            _copy_dir(str(s), str(d))
        else:
            futures.append(_thread_pool.submit(_atomic_copy, s, d))

    if futures:
        wait(futures)

    # Write sync timestamp
    try:
        ts_file = dst / "last_sync_at.txt"
        ts_file.write_text(
            "Last sync at: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "\n",
            encoding="utf-8",
        )
    except Exception as e:
        _log(f"Failed to write last_sync_at.txt in {dst}: {e}")

    _log(f"Updated {dst} with contents from {src}")


def initial_sync_on_load(cache_dir: str, shared_cache_dir: str):
    """On startup: sync shared cache → local cache."""
    if Path(cache_dir).resolve() != Path(shared_cache_dir).resolve():
        _log(f"Syncing shared cache → local cache: {shared_cache_dir} → {cache_dir}")
        _copy_dir(shared_cache_dir, cache_dir)


def _sigterm_handler(signum, frame):
    """Internal handler that iterates over all attached cache pairs."""
    _log(f"SIGTERM signal ({signum}) received. Syncing caches...")
    for pair in _attached_cache_pairs:
        cache_dir = pair["cache_dir"]
        shared_cache_dir = pair["shared_cache_dir"]
        if Path(cache_dir).resolve() != Path(shared_cache_dir).resolve():
            _log(
                f"Preemption signal received. Syncing local cache → shared cache: {cache_dir} → {shared_cache_dir}"
            )
            _copy_dir(cache_dir, shared_cache_dir)
    sys.exit(0)


def create_handle(cache_dir: str, shared_cache_dir: str) -> Dict:
    """Create a handle for the cache pair."""
    return {"cache_dir": cache_dir, "shared_cache_dir": shared_cache_dir}


def attach_sigterm_signal(cache_dir: str, shared_cache_dir: str):
    """Attach a new cache pair to the global SIGTERM handler."""
    global _thread_pool
    if _thread_pool is None:
        _thread_pool = ThreadPoolExecutor(max_workers=16)

    pair = create_handle(cache_dir, shared_cache_dir)
    _attached_cache_pairs.append(pair)

    # Attach the global handler if not already attached
    if signal.getsignal(signal.SIGTERM) != _sigterm_handler:
        signal.signal(signal.SIGTERM, _sigterm_handler)
    _log(f"Attached SIGTERM sync for: {cache_dir} ↔ {shared_cache_dir}")

    return pair  # handle used for removal


def remove_sigterm_signal(handle):
    """Remove a previously attached cache pair from the SIGTERM handler."""
    if handle in _attached_cache_pairs:
        _attached_cache_pairs.remove(handle)
        _log(
            f"Removed SIGTERM sync for: {handle['cache_dir']} ↔ {handle['shared_cache_dir']}"
        )


def detach_sigterm_signal():
    global _thread_pool
    signal.signal(signal.SIGTERM, signal.SIG_DFL)
    if _thread_pool is not None:
        _thread_pool.shutdown(wait=True)
        _thread_pool = None
