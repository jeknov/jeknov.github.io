import gc
import logging
import os
import sys
import tempfile
import time
from contextlib import nullcontext
from functools import cached_property, partial
from time import sleep
from typing import Any, Callable, Generator, Iterable

import torch
from datadreamer import DataDreamer
from datadreamer.llms.hf_transformers import CachedTokenizer, HFTransformers
from datadreamer.llms.llm import DEFAULT_BATCH_SIZE, _check_temperature_and_top_p
from datadreamer.logging import logger as datadreamer_logger
from datadreamer.utils.arg_utils import AUTO, Default
from datadreamer.utils.background_utils import (
    RunIfTimeout,
    dill_serializer,
    proxy_resource_in_background,
)
from datadreamer.utils.device_utils import get_device_env_variables, is_cpu_device
from datadreamer.utils.fs_utils import safe_fn
from datadreamer.utils.hf_model_utils import get_tokenizer
from datadreamer.utils.import_utils import (
    ignore_tqdm,
    ignore_transformers_warnings,
    import_module,
)
from datasets.fingerprint import Hasher
from filelock import FileLock
from huggingface_hub.errors import HfHubHTTPError
from tenacity import (
    after_log,
    before_sleep_log,
    retry,
    retry_if_exception_type,
    wait_exponential,
)

with ignore_transformers_warnings():
    from transformers import PreTrainedTokenizer

import psutil


def kill_children():
    parent = psutil.Process(os.getpid())
    for child in parent.children(recursive=True):
        try:
            child.kill()
            print(f"Exiting child process {child.pid}", file=sys.stderr)
        except Exception as e:
            print(f"Failed to kill child process {child.pid}: {e}", file=sys.stderr)


class VLLM(HFTransformers):  # pragma: no cover
    def __init__(
        self,
        model_name: str,
        chat_prompt_template: None | str | Default = AUTO,
        system_prompt: None | str | Default = AUTO,
        revision: None | str = None,
        trust_remote_code: bool = False,
        device: None | int | str | torch.device | list[int | str | torch.device] = None,
        dtype: None | str | torch.dtype = None,
        quantization: None | str = None,
        swap_space: int = 1,
        cache_folder_path: None | str = None,
        **kwargs,
    ):
        device = (
            [device] if not isinstance(device, list) else device  # type:ignore[list-item]
        )
        super().__init__(
            model_name=model_name,
            chat_prompt_template=chat_prompt_template,
            system_prompt=system_prompt,
            revision=revision,
            trust_remote_code=trust_remote_code,
            device=device,
            dtype=dtype,
            cache_folder_path=cache_folder_path,
            **kwargs,
        )
        self.device = (
            [self.device] if not isinstance(self.device, list) else self.device  # type:ignore[list-item]
        )
        self.quantization = quantization
        if self.quantization is None and "-awq" in model_name.lower():
            self.quantization = "awq"
        self.swap_space = swap_space

    @cached_property
    def retry_wrapper(self):
        # Create a retry wrapper function
        tenacity_logger = self.get_logger(key="retry", verbose=True, log_level=None)

        from requests.exceptions import ConnectionError, HTTPError, Timeout

        @retry(
            retry=retry_if_exception_type(Timeout),
            wait=wait_exponential(multiplier=1, min=10, max=60),
            before_sleep=before_sleep_log(tenacity_logger, logging.INFO),
            after=after_log(tenacity_logger, logging.INFO),
            reraise=True,
        )
        @retry(
            retry=retry_if_exception_type(ConnectionError),
            wait=wait_exponential(multiplier=1, min=10, max=60),
            before_sleep=before_sleep_log(tenacity_logger, logging.INFO),
            after=after_log(tenacity_logger, logging.INFO),
            reraise=True,
        )
        @retry(
            retry=retry_if_exception_type(HTTPError),
            wait=wait_exponential(multiplier=1, min=10, max=60),
            before_sleep=before_sleep_log(tenacity_logger, logging.INFO),
            after=after_log(tenacity_logger, logging.INFO),
            reraise=True,
        )
        @retry(
            retry=retry_if_exception_type(HfHubHTTPError),
            wait=wait_exponential(multiplier=1, min=10, max=60),
            before_sleep=before_sleep_log(tenacity_logger, logging.INFO),
            after=after_log(tenacity_logger, logging.INFO),
            reraise=True,
        )
        def _retry_wrapper(func, *args, **kwargs):
            return func(*args, **kwargs)

        _retry_wrapper.__wrapped__.__module__ = None  # type: ignore[attr-defined]
        _retry_wrapper.__wrapped__.__qualname__ = f"{self.__class__.__name__}.run"  # type: ignore[attr-defined]
        return _retry_wrapper

    @cached_property
    def model(self) -> Any:
        env = os.environ.copy()
        assert isinstance(self.device, list)
        if len(self.device) == 1 and is_cpu_device(self.device[0]):
            env["VLLM_TARGET_DEVICE"] = "cpu"
            env.update(get_device_env_variables([]))
        else:
            env.update(get_device_env_variables(self.device))
        kwargs = self.kwargs.copy()
        tensor_parallel_size = kwargs.pop("tensor_parallel_size", len(self.device))

        class LLMResource:
            def __init__(self_resource):
                # Disable VLLM loggers
                if DataDreamer.initialized() and not DataDreamer.ctx.hf_log:
                    vllm_logging = import_module("vllm.logger")
                    _old_init_logger = vllm_logging.init_logger

                    def _monkey_patch_init_logger(*args, **kwargs):
                        logger = _old_init_logger(*args, **kwargs)
                        logger.level = logging.ERROR
                        return logger

                    vllm_logging.init_logger = _monkey_patch_init_logger  # type:ignore[attr-defined]
                    logging.getLogger("vllm.engine.llm_engine").level = logging.ERROR
                    logging.getLogger("vllm.config").level = logging.ERROR
                    logging.getLogger(
                        "vllm.distributed.parallel_state"
                    ).level = logging.ERROR

                # Load model
                log_if_timeout = RunIfTimeout(
                    partial(
                        lambda self: self.get_logger(
                            key="model", log_level=datadreamer_logger.level
                        ).info("Loading..."),
                        self,
                    ),
                    timeout=10.0,
                )
                LLM = import_module("vllm").LLM
                with (
                    ignore_tqdm()
                    if datadreamer_logger.level > logging.DEBUG
                    else nullcontext()
                ):
                    db_lock = FileLock(
                        os.path.join(tempfile.gettempdir(), "fi-vllm.flock")
                    )
                    db_initilized = os.path.join(
                        tempfile.gettempdir(), "fi-vllm-v1.done"
                    )
                    self.get_logger(
                        key="model", log_level=datadreamer_logger.level
                    ).info(f"Waiting for model to be loaded... from PID: {os.getpid()}")

                    def init_model():
                        if not hasattr(self_resource, "model"):
                            self_resource.model = self.retry_wrapper(
                                func=(
                                    lambda: LLM(
                                        model=self.model_name,
                                        trust_remote_code=self.trust_remote_code,
                                        dtype=str(self.dtype).replace("torch.", "")
                                        if self.dtype is not None
                                        else "auto",
                                        quantization=self.quantization,
                                        revision=self.revision,
                                        swap_space=self.swap_space,
                                        tensor_parallel_size=tensor_parallel_size,
                                        **kwargs,
                                    )
                                )
                            )
                            open(db_initilized, "a").close()
                            self.get_logger(
                                key="model", log_level=datadreamer_logger.level
                            ).info(f"VLLM Loaded. PID: {os.getpid()}")

                    with db_lock:
                        if not os.path.exists(db_initilized):
                            init_model()
                        else:
                            self.get_logger(
                                key="model", log_level=datadreamer_logger.level
                            ).info(
                                f"Another process already intialized VLLM. PID: {os.getpid()}"
                            )
                    init_model()

                # Finished loading
                log_if_timeout.stop(
                    partial(
                        lambda self: self.get_logger(
                            key="model", log_level=datadreamer_logger.level
                        ).info("Finished loading."),
                        self,
                    )
                )

            @dill_serializer
            def get_generated_texts_batch(self_resource, *args, **kwargs):
                outputs = self.retry_wrapper(
                    self_resource.model.generate, *args, **kwargs
                )
                generated_texts_batch = [
                    [o.text for o in batch.outputs] for batch in outputs
                ]
                return generated_texts_batch

        return proxy_resource_in_background(LLMResource, env=env)

    @cached_property
    def tokenizer(self) -> PreTrainedTokenizer:
        while True:
            try:
                return get_tokenizer(
                    model_name=self.model_name,
                    revision=self.revision,
                    trust_remote_code=self.trust_remote_code,
                )
            except HfHubHTTPError as e:
                print("Error loading tokenizer, retrying...", e)
                sleep(3)

    def _is_batch_size_exception(self, e: BaseException) -> bool:
        # TODO (fix later if vLLM updates):
        # This is not possible with VLLM yet (detect when CUDA OOM)
        return False

    @torch.no_grad()
    def _run_batch(  # noqa: C901
        self,
        cached_tokenizer: CachedTokenizer,
        max_length_func: Callable[[list[str]], int],
        inputs: list[str],
        max_new_tokens: None | int = None,
        temperature: float = 1.0,
        top_p: float = 0.0,
        n: int = 1,
        stop: None | str | list[str] = None,
        repetition_penalty: None | float = None,
        logit_bias: None | dict[int, float] = None,
        batch_size: int = DEFAULT_BATCH_SIZE,
        seed: None | int = None,
        **kwargs,
    ) -> list[str] | list[list[str]]:
        prompts = inputs
        assert (
            logit_bias is None
        ), f"`logit_bias` is not supported for {type(self).__name__}"
        assert seed is None, f"`seed` is not supported for {type(self).__name__}"

        SamplingParams = import_module("vllm").SamplingParams

        # Check max_new_tokens (NOTE: SLOW DISABLING FOR PRETRAINING_INFERENCE)
        # max_new_tokens = _check_max_new_tokens_possible(
        #     self=self,
        #     max_length_func=max_length_func,
        #     prompts=prompts,
        #     max_new_tokens=max_new_tokens,
        # )

        # Set temperature and top_p
        temperature, top_p = _check_temperature_and_top_p(
            temperature=temperature,
            top_p=top_p,
            supports_zero_temperature=False,
            supports_zero_top_p=False,
        )

        # Generate
        sampling_params = SamplingParams(
            n=n,
            presence_penalty=(
                repetition_penalty if repetition_penalty is not None else 0.0
            ),
            temperature=temperature,
            top_p=top_p,
            stop=stop,
            max_tokens=max_new_tokens,
            **kwargs,
        )
        start_time = time.time()
        try:
            generated_texts_batch = self.model.proxy.get_generated_texts_batch(
                prompts,
                sampling_params,
                use_tqdm=(datadreamer_logger.level <= logging.DEBUG),
            )
        except Exception as e:
            if "OutOfMemoryError" in str(e):
                import traceback

                new_error = RuntimeError(
                    f"torch.OutOfMemoryError: {str(self.device)} after {int(time.time() - start_time)} second(s)"
                )
                traceback.print_exception(
                    type(new_error), new_error, new_error.__traceback__
                )
                try:
                    kill_children()
                except Exception as e:
                    print(f"Failed to kill child processes: {e}", file=sys.stderr)
                os._exit(95)  # Exit with a specific code to indicate OOM
                raise new_error from e
            raise e

        # Post-process and return
        if n == 1:
            return [batch[0] for batch in generated_texts_batch]
        else:
            return generated_texts_batch

    def run(
        self,
        prompts: Iterable[str],
        max_new_tokens: None | int = None,
        temperature: float = 1.0,
        top_p: float = 0.0,
        n: int = 1,
        stop: None | str | list[str] = None,
        repetition_penalty: None | float = None,
        logit_bias: None | dict[int, float] = None,
        batch_size: int = DEFAULT_BATCH_SIZE,
        batch_scheduler_buffer_size: None | int = None,
        adaptive_batch_size: bool = False,
        seed: None | int = None,
        progress_interval: None | int = 60,
        force: bool = False,
        cache_only: bool = False,
        verbose: None | bool = None,
        log_level: None | int = None,
        total_num_prompts: None | int = None,
        return_generator: bool = False,
        **kwargs,
    ) -> Generator[str | list[str], None, None] | list[str | list[str]]:
        return super().run(
            prompts=prompts,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            top_p=top_p,
            n=n,
            stop=stop,
            repetition_penalty=repetition_penalty,
            logit_bias=logit_bias,
            batch_size=batch_size,
            batch_scheduler_buffer_size=batch_scheduler_buffer_size,
            adaptive_batch_size=adaptive_batch_size,
            seed=seed,
            progress_interval=progress_interval,
            force=force,
            cache_only=cache_only,
            verbose=verbose,
            log_level=log_level,
            total_num_prompts=total_num_prompts,
            return_generator=return_generator,
            **kwargs,
        )

    @cached_property
    def citation(self) -> None | list[str]:
        citations = super().citation or []
        citations.append(
            """
@inproceedings{kwon2023efficient,
  title={Efficient Memory Management for Large Language Model Serving with PagedAttention},
  author={Woosuk Kwon and Zhuohan Li and Siyuan Zhuang and Ying Sheng and Lianmin"""
            """ Zheng and Cody Hao Yu and Joseph E. Gonzalez and Hao Zhang and Ion Stoica},
  booktitle={Proceedings of the ACM SIGOPS 29th Symposium on Operating Systems Principles},
  year={2023}
}
            """.strip()
        )
        return citations

    @property
    def version(self) -> float:
        return 1.0

    @cached_property
    def _cache_name(self) -> None | str:
        names = [safe_fn(self.model_name, allow_slashes=False)]
        if self.revision:
            names.append(self.revision)
        names.append(str(self.dtype))
        to_hash: list[Any] = []
        if self.quantization is not None:  # pragma: no cover
            to_hash.append(self.quantization)
        if len(to_hash) > 0:  # pragma: no cover
            names.append(Hasher.hash(to_hash))
        return "_".join(names)

    def unload_model(self):
        # Delete cached model and tokenizer
        if "model" in self.__dict__:
            del self.__dict__["model"]
        if "tokenizer" in self.__dict__:
            del self.__dict__["tokenizer"]

        # Garbage collect
        gc.collect()

    def __getstate__(self):  # pragma: no cover
        state = super().__getstate__()

        # Remove cached model or tokenizer before serializing
        state.pop("retry_wrapper", None)
        state.pop("model", None)
        state.pop("tokenizer", None)

        return state


__all__ = ["VLLM"]
