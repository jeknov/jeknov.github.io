import json
import os
import time

from filelock import FileLock


class FileSemaphore:
    def __init__(self, name: str, max_acquire: int, dir: str = "/tmp/semaphores"):
        self.name = name
        self.max_acquire = max_acquire

        os.makedirs(dir, exist_ok=True)

        self.lockfile = os.path.join(dir, f"{name}.lock")
        self.counterfile = os.path.join(dir, f"{name}.json")
        self.lock = FileLock(self.lockfile)

        self._init_counter_file()

    def _init_counter_file(self):
        with self.lock:
            if not os.path.exists(self.counterfile):
                self._write_counter(0)
            else:
                try:
                    count = self._read_counter()
                    if not isinstance(count, int) or not (
                        0 <= count <= self.max_acquire
                    ):
                        raise ValueError
                except Exception:
                    print("[FileSemaphore] Corrupted counter file. Resetting to 0.")
                    self._write_counter(0)

    def _read_counter(self):
        try:
            with open(self.counterfile, "r") as f:
                data = json.load(f)
            return data.get("count", 0)
        except Exception:
            print("[FileSemaphore] Failed to read counter file. Returning 0.")
            return 0

    def _write_counter(self, count: int):
        try:
            with open(self.counterfile, "w") as f:
                json.dump({"count": count}, f)
        except Exception as e:
            print(f"[FileSemaphore] Failed to write counter: {e}")

    def acquire(self, timeout=None, poll_interval=0.1):
        start_time = time.time()
        while True:
            with self.lock:
                count = self._read_counter()
                if not isinstance(count, int) or count < 0 or count > self.max_acquire:
                    print(
                        "[FileSemaphore] Invalid counter detected during acquire. Resetting."
                    )
                    count = 0

                if count < self.max_acquire:
                    self._write_counter(count + 1)
                    return  # Successfully acquired

            if timeout is not None and (time.time() - start_time) >= timeout:
                print("[FileSemaphore] Timeout during acquire. Giving up.")
                raise TimeoutError("Upload semaphore acquire timed out.")
            time.sleep(poll_interval)

    def release(self):
        with self.lock:
            count = self._read_counter()
            if not isinstance(count, int):
                print("[FileSemaphore] Invalid counter during release. Resetting.")
                self._write_counter(0)
                return

            if count <= 0:
                print("[FileSemaphore] Counter already at 0 during release. Skipping.")
                return

            self._write_counter(count - 1)

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()

    def guard(self, timeout=None, poll_interval=0.1):
        """Returns a decorator that wraps a function with this semaphore."""

        def decorator(func):
            def wrapper(*args, **kwargs):
                self.acquire(timeout=timeout, poll_interval=poll_interval)
                try:
                    return func(*args, **kwargs)
                finally:
                    self.release()

            return wrapper

        return decorator
