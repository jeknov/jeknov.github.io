import sys

from datasets import concatenate_datasets, get_dataset_split_names, load_dataset

from ..mine_real_queries import clean_rows


def flatten_real_queries(ctx):
    dataset_name = "fineinstructions/real_queries_raw"
    split_names = get_dataset_split_names(dataset_name)
    splits = []
    for split_name in split_names:
        print(f"Processing {split_name}...", file=sys.stderr)
        dataset = load_dataset("fineinstructions/real_queries_raw", split=split_name)
        dataset = dataset.map(
            lambda x: {**x, "source_name": split_name},  # noqa: B023
            desc=f"Adding source name {split_name}...",
            num_proc=10,
        )
        dataset = dataset.filter(
            lambda x: x["language"] == "en",
            desc=f"Filtering {split_name} to English queries...",
            num_proc=10,
        )
        splits.append(dataset)

    flattened_queries = concatenate_datasets(splits)
    flatten_queries_cleaned = clean_rows(flattened_queries, "query")
    flatten_queries_cleaned.push_to_hub(
        "fineinstructions/real_queries", split="full", max_shard_size="500MB"
    )


__all__ = ["flatten_real_queries"]
