import importlib
import pkgutil
import warnings


def list_module_objects(package_name):
    try:
        # Import the base package
        package = importlib.import_module(package_name)
    except ImportError as e:
        print(f"Error importing package: {e}")
        return []

    # Get the package path and name
    package_path = package.__path__ if hasattr(package, "__path__") else None
    if package_path is None:
        print(f"{package_name} is not a package")
        return []

    # Recursively discover and import all modules
    module_objects = []
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for module_info in pkgutil.walk_packages(package_path, package_name + "."):
            try:
                module = importlib.import_module(module_info.name)
                module_objects.append(module)
            except ImportError as e:
                print(f"Failed to import {module_info.name}: {e}")

    return module_objects


def extract_prompt_templates_from_langchain():
    """
    Extracts templates from modules in the given package.

    Args:
        package_name (str): The name of the package to inspect.

    Returns:
        dict: A dictionary mapping object names (module_name + variable_name) to their values.
    """
    package_name = "langchain"
    modules = list_module_objects(package_name)
    template_dict = {}

    for module in modules:
        module_vars = list(vars(module))
        for var_name in module_vars:
            value = getattr(module, var_name)
            if (
                var_name.lower().endswith("_template")
                and isinstance(value, str)
                and "{" in value
                and "function" not in value
                and "scratchpad}" not in value
                and "line_template" not in var_name
                and "HUMAN_MESSAGE_TEMPLATE" not in var_name
            ):
                key = f"{module.__name__}.{var_name}"
                template_dict[key] = value.lstrip()

    return template_dict


LANGCHAIN_PROMPT_LIBRARY_RAW = extract_prompt_templates_from_langchain()
LANGCHAIN_PROMPT_LIBRARY = []
for key, value in sorted(
    LANGCHAIN_PROMPT_LIBRARY_RAW.items(), key=lambda item: len(item[1]), reverse=True
):
    LANGCHAIN_PROMPT_LIBRARY.append({"source": key, "prompt": value})
