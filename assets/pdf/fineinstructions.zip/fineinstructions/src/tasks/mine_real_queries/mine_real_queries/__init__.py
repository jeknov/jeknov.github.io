import json
import logging
import os
import pickle
import random
import re
import sys
from collections import OrderedDict, defaultdict
from glob import glob
from statistics import mean

import torch
from datasets import (
    Dataset,
    concatenate_datasets,
    get_dataset_config_names,
    get_dataset_split_names,
    load_dataset,
)
from datasets.fingerprint import Hasher
from langcodes import Language
from langdetect import LangDetectException, detect
from loguru import logger
from openai import OpenAI, OpenAIError
from tenacity import after_log, before_sleep_log, retry, stop_never, wait_exponential

from .anthropic_extractor import ANTHROPIC_PROMPT_LIBRARY
from .langchain_extractor import LANGCHAIN_PROMPT_LIBRARY

# Setup
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY", "fake-key"))
logger = logging.getLogger(__name__)  # noqa: F811
global_custom_cache_dir = None
pipe = None


# Helper clean functions
@retry(
    stop=stop_never,
    wait=wait_exponential(multiplier=3, min=60, max=60),
    retry=(
        lambda retry_state: isinstance(retry_state.outcome.exception(), OpenAIError)
    ),
    before_sleep=before_sleep_log(logger, logging.INFO),
    after=after_log(logger, logging.INFO),
)
def _moderate(texts):
    response = client.moderations.create(model="omni-moderation-latest", input=texts)
    return [r.categories.dict() for r in response.results]


def moderate(texts):
    return _moderate(texts)


def filter_fn(batch):
    texts = batch["query"]
    # Create a unique hash for the current batch of texts
    hash_key = Hasher.hash([t[0:5] for t in texts])
    assert global_custom_cache_dir is not None
    cache_file = os.path.join(global_custom_cache_dir, "moderation", f"{hash_key}.pkl")

    # Check if cached result exists
    if os.path.exists(cache_file):
        with open(cache_file, "rb") as f:
            return pickle.load(f)

    # Otherwise, compute the filter result
    responses = moderate(texts)
    bad_content = [any(r.values()) for r in responses]
    result = [not is_bad for is_bad in bad_content]

    # Save the result to the cache
    with open(cache_file, "wb") as f:
        pickle.dump(result, f)

    return result


def clean_rows(dataset, column_name):
    seen = set()

    def dedup_fn(batch):
        mask = []
        for value, query in zip(batch[column_name], batch["query"]):
            if value in seen or query is None or len(query) == 0 or len(query) <= 15:
                mask.append(False)
            else:
                seen.add(value)
                mask.append(True)
        # Filter the batch based on the mask
        return {k: [v for v, m in zip(batch[k], mask) if m] for k in batch.keys()}

    return dataset.map(dedup_fn, batched=True, batch_size=50000, desc="De-duplicating")


def group_by_unique(dataset, column_name):
    seen = set()

    def group_fn(batch):
        value = batch[column_name][0]
        if value in seen:
            return {k: [] for k in batch.keys()}
        seen.add(value)
        return batch

    return dataset.map(
        group_fn, batched=True, batch_size=1, desc="Grouping by unique value"
    )


def moderate_rows(dataset):
    return dataset.filter(
        filter_fn,
        batched=True,
        batch_size=10000,
        desc="Filtering with OpenAI moderation",
    )


def natural_language_name_lookup(langname):
    try:
        return Language.find(langname).to_tag()
    except LookupError:
        return None


def language_detect(text):
    try:
        return detect(text)
    except LangDetectException:
        return None


def mine_real_queries(ctx):  # noqa: C901
    global global_custom_cache_dir
    from ....project import get_persistent_dir, reporter

    # Setup logger for tenacity
    logging.basicConfig(level=logging.INFO)

    # Define the custom cache directory in the current local directory
    reporter.set("mine_real_queries.hf_cache", "1")
    custom_cache_dir = get_persistent_dir("hf_cache", "mine_real_queries.hf_cache")
    global_custom_cache_dir = custom_cache_dir
    os.makedirs(custom_cache_dir, exist_ok=True)
    os.makedirs(os.path.join(custom_cache_dir, "moderation"), exist_ok=True)
    os.environ["HF_DATASETS_CACHE"] = custom_cache_dir

    # Datasets
    datasets = {
        "wildchat": {
            "name": "allenai/WildChat-1M",
            "revision": "7d6490e462285cf85d91eabea0f9a954fbddcd1f",
            "split": "train",
            "skip": True,
            "push": True,
        },
        "lmsys_chat": {
            "name": "lmsys/lmsys-chat-1m",
            "revision": "200748d9d3cddcc9d782887541057aca0b18c5da",
            "split": "train",
            "skip": True,
            "push": True,
        },
        "lmsys_chatbot_arena_conversations": {
            "name": "lmsys/chatbot_arena_conversations",
            "revision": "1b6335d42a1d2c7e34870c905d03ab964f7f2bd8",
            "split": "train",
            "skip": True,
            "push": True,
        },
        "oasst1": {
            "name": "OpenAssistant/oasst1",
            "revision": "fdf72ae0827c1cda404aff25b6603abec9e3399b",
            "split": "train",
            "skip": True,
            "push": True,
        },
        "HuggingFaceH4_no_robots": {
            "name": "HuggingFaceH4/no_robots",
            "revision": "e6f9a4ac5c37faeb744ba9ecf0473184d7f8105b",
            "split": "train",
            "skip": True,
            "push": True,
        },
        "HelpSteer": {
            "name": "nvidia/HelpSteer2",
            "revision": "990b2711a36180dd19d9c94b8627844866f8982a",
            "split": "train",
            "skip": True,
            "push": True,
        },
        "dolly": {
            "name": "databricks/databricks-dolly-15k",
            "revision": "bdd27f4d94b9c1f951818a7da7fd7aeea5dbff1a",
            "split": "train",
            "skip": True,
            "push": True,
        },
        "reddit_qa": {
            "name": "nreimers/reddit_question_best_answers",
            "revision": "c4821b678115e52620027e77f76919953581236c",
            "split": "train",
            "moderate": True,
            "skip": True,
            "push": True,
        },
        "stackexchange": {
            "name": "ArmelR/stack-exchange-instruction",
            "revision": "3e463817c02767cd64d9ad0276c6d291c7f120aa",
            "skip": True,
            "push": True,
        },
        "gooaq": {
            "name": "sentence-transformers/gooaq",
            "revision": "b089f728748a068b7bc5234e5bcf5b25e3c8279c",
            "split": "train",
            "skip": True,
            "push": True,
        },
        "sharelm": {
            "name": "shachardon/ShareLM",
            "revision": "6880ecc2f34e8bdd71ce39a4845e4d426d549653",
            "split": "train",
            "moderate": True,
            "skip": True,
            "push": True,
        },
        "expertqa": {
            "name": "cmalaviya/expertqa",
            "revision": "8115f49f1b3abe69a3e2eeab1a3c31ef9b838145",
            "subset": "lfqa_random",
            "split": "train",
            "skip": True,
            "push": True,
        },
        "icliniq": {
            "name": "lavita/medical-qa-datasets",
            "revision": "59d48e2739fff1de8803ee59b97547ad51846650",
            "subset": "chatdoctor-icliniq",
            "split": "test",
            "skip": True,
            "push": True,
        },
        "healthcaremagic": {
            "name": "lavita/medical-qa-datasets",
            "revision": "59d48e2739fff1de8803ee59b97547ad51846650",
            "subset": "chatdoctor_healthcaremagic",
            "split": "train",
            "skip": True,
            "push": True,
        },
        "awesome_chatgpt_prompts": {
            "name": "fka/awesome-chatgpt-prompts",
            "revision": "68ba7694e23014788dcc8ab5afe613824f45a05c",
            "split": "train",
            "skip": True,
            "push": True,
        },
        "anthropic": {"list": ANTHROPIC_PROMPT_LIBRARY, "skip": True, "push": True},
        "langchain": {
            "list": LANGCHAIN_PROMPT_LIBRARY,
            "instantiate": True,
            "skip": True,
            "push": True,
        },
        "naturalinstructions": {
            "name": "Muennighoff/natural-instructions",
            "revision": "a29a9757125f4bb1c26445ad0d2ef7d9b2cc9c4c",
            "split": "train",
            "group_by": "task_name",
            "skip": True,
            "push": True,
        },
        "p3": {
            "name": "bigscience/P3",
            "revision": "db485208b9f41d46c1d0975202328d08f8199046",
            "split": "train",
            "group_by": "subset",
            "skip": True,
            "push": True,
        },
        "bbh": {
            "name": "lukaemon/bbh",
            "revision": "2ae1a82e7907ca4447874ede02df3289f94ecce8",
            "split": "test",
            "group_by": "subset",
            "skip": True,
            "push": True,
        },
        "flanv2": {
            "name": "nguyenthanhdo/FLANv2-without-T0",
            "revision": "8e6b798d910a9532007f51999e16f2355377d8a0",
            "skip": True,
            "push": True,
        },
    }

    # Loop through all datasets
    all_datasets = OrderedDict()
    new_schema = ["query", "language", "source", "metadata"]
    for dataset_name, dataset_metadata in datasets.items():
        if dataset_metadata["skip"]:
            continue

        if "list" in dataset_metadata:
            dataset = Dataset.from_list(dataset_metadata["list"])
        elif dataset_name == "stackexchange":
            parquet_files = glob(
                os.path.join(
                    os.path.join(
                        custom_cache_dir, dataset_metadata["name"].split("/")[1]
                    ),
                    "**/*.parquet",
                ),
                recursive=True,
            )
            parquet_files = [
                f
                for f in parquet_files
                if (
                    "train-00010-of-00014-978b4abf2ae22787.parquet" not in f
                    and "train-00003-of-00014-94c640cd4c5999cc.parquet" not in f
                )
            ]  # Remove unsafe files
            dataset = load_dataset(  # Load from disk manually since this dataset is not downloadable due to unsafe files detected by HF virus scanner
                "parquet", data_files=parquet_files, cache_dir=custom_cache_dir
            )["train"]
        elif dataset_name == "flanv2":
            split_names = get_dataset_split_names(
                dataset_metadata["name"],
                revision=dataset_metadata["revision"],
                trust_remote_code=True,
            )
            subsets = []
            for sn in split_names:
                print(f"Processing split: {sn}", file=sys.stderr)
                subset = load_dataset(
                    dataset_metadata["name"],
                    split=sn,
                    revision=dataset_metadata["revision"],
                    cache_dir=custom_cache_dir,
                    trust_remote_code=True,
                ).map(
                    lambda x, idx: {
                        **x,
                        "source": sn
                        + " (index: "
                        + str(idx)
                        + ", "
                        + x["_task_name"]
                        + ", "
                        + x["_template_type"]
                        + ")",
                        "group_by": x["_task_name"] + x["_template_type"],
                    },
                    with_indices=True,
                    desc=f"Adding source {dataset_name}/{sn}",
                )
                subset = group_by_unique(subset, "group_by")
                subsets.append(subset)
            dataset = concatenate_datasets(subsets)
        elif (
            "group_by" in dataset_metadata and dataset_metadata["group_by"] == "subset"
        ):
            config_names = get_dataset_config_names(
                dataset_metadata["name"],
                revision=dataset_metadata["revision"],
                trust_remote_code=True,
            )
            subsets = []
            for cn in config_names:
                subset = Dataset.from_list(
                    list(
                        load_dataset(
                            dataset_metadata["name"],
                            cn,
                            split=dataset_metadata["split"],
                            revision=dataset_metadata["revision"],
                            cache_dir=custom_cache_dir,
                            streaming=True,
                            trust_remote_code=True,
                        ).take(1)
                    )
                ).map(
                    lambda x: {**x, "subset_name": cn},
                    desc=f"Adding subset name {dataset_name}",
                )
                subsets.append(subset)
            dataset = concatenate_datasets(subsets)
        elif "subset" in dataset_metadata:
            dataset = load_dataset(
                dataset_metadata["name"],
                dataset_metadata["subset"],
                split=dataset_metadata["split"],
                revision=dataset_metadata["revision"],
                cache_dir=custom_cache_dir,
                num_proc=10,
            )
        else:
            dataset = load_dataset(
                dataset_metadata["name"],
                split=dataset_metadata["split"],
                revision=dataset_metadata["revision"],
                cache_dir=custom_cache_dir,
                num_proc=(
                    64
                    if dataset_name in ["stackexchange", "naturalinstructions"]
                    else 10
                ),
            )
            if "group_by" in dataset_metadata:
                dataset = group_by_unique(dataset, dataset_metadata["group_by"])

        if dataset_name == "wildchat":

            def preprocess_function(row, index):
                return {
                    "query": row["conversation"][0]["content"].strip(),
                    "language": natural_language_name_lookup(row["language"]),
                    "source": dataset_metadata["name"],
                    "metadata": json.dumps(
                        {"conversation_hash": row["conversation_hash"]}, indent=2
                    ),
                }

        if dataset_name == "lmsys_chat":

            def preprocess_function(row, index):
                query = row["conversation"][0]["content"].strip()
                bad_content = any(
                    (list(row["openai_moderation"][0]["categories"].values()))
                )
                return {
                    "query": query if not bad_content else None,
                    "language": natural_language_name_lookup(row["language"]),
                    "source": dataset_metadata["name"],
                    "metadata": json.dumps(
                        {"conversation_id": row["conversation_id"]}, indent=2
                    ),
                }

        if dataset_name == "lmsys_chatbot_arena_conversations":

            def preprocess_function(row, index):
                query = row["conversation_a"][0]["content"].strip()
                bad_content = any(
                    (list(row["openai_moderation"]["categories"].values()))
                )
                return {
                    "query": query if not bad_content else None,
                    "language": natural_language_name_lookup(row["language"]),
                    "source": dataset_metadata["name"],
                    "metadata": json.dumps(
                        {"question_id": row["question_id"]}, indent=2
                    ),
                }

        if dataset_name == "oasst1":

            def preprocess_function(row, index):
                query = row["text"].strip()
                labels = (
                    dict(zip(row["labels"]["name"], row["labels"]["value"]))
                    if row["labels"] is not None
                    else {}
                )
                labels_default = defaultdict(lambda: 0)
                labels_default.update(labels)
                bad_content = (
                    row["synthetic"]
                    or row["deleted"]
                    or row["role"] != "prompter"
                    or row["parent_id"] is not None
                    or row["review_count"] < 3
                    or (
                        mean(
                            labels_default[k]
                            for k in [
                                "lang_mismatch",
                                "pii",
                                "not_appropriate",
                                "hate_speech",
                                "spam",
                                "toxicity",
                                "violence",
                            ]
                        )
                        > 0.1
                        or labels_default["quality"] < 0.7
                    )
                )

                return {
                    "query": query if not bad_content else "",
                    "language": row["lang"],
                    "source": dataset_metadata["name"],
                    "metadata": json.dumps({"message_id": row["message_id"]}, indent=2),
                }

        if dataset_name == "HuggingFaceH4_no_robots":

            def preprocess_function(row, index):
                return {
                    "query": row["prompt"].strip(),
                    "language": "en",
                    "source": dataset_metadata["name"],
                    "metadata": json.dumps({"prompt_id": row["prompt_id"]}, indent=2),
                }

        if dataset_name == "HelpSteer":

            def preprocess_function(row, index):
                return {
                    "query": row["prompt"].strip(),
                    "language": "en",
                    "source": dataset_metadata["name"],
                    "metadata": json.dumps({"index": index}, indent=2),
                }

        if dataset_name == "dolly":
            dolly_random = random.Random(42)

            def preprocess_function(row, index):
                return {
                    "query": (
                        (row["context"].strip() + "\n\n" + row["instruction"].strip())
                        if dolly_random.randint(0, 1)
                        else (
                            row["instruction"].strip() + "\n\n" + row["context"].strip()
                        )
                    )
                    if row["context"] is not None and len(row["context"].strip()) > 0
                    else row["instruction"].strip(),
                    "language": "en",
                    "source": dataset_metadata["name"],
                    "metadata": json.dumps({"index": index}, indent=2),
                }

        if dataset_name == "reddit_qa":

            def preprocess_function(row, index):
                text = row["title"] + " " + row["body"]
                text_lower = text.lower()
                bad_content = (
                    any(text_lower.startswith(banned) for banned in ["ask"])
                    or len(text) > 1000
                    or any(
                        banned in text_lower
                        for banned in [
                            "reddit",
                            "http",
                            "r/",
                            "anyone",
                            "someone",
                            "else",
                            "you",
                            "your",
                            "edit",
                            "hey",
                            "upvote",
                            "downvote",
                            "[",
                            "]",
                            "post",
                            "thread",
                            "giveaway",
                            "title",
                            "fellow",
                        ]
                    )
                    or any(banned in text for banned in ["AMA", "DAE", "Discuss."])
                    or not any(
                        required in text_lower
                        for required in [
                            "?",
                            "who ",
                            "what ",
                            "why ",
                            "when ",
                            "where ",
                            "which ",
                            "does ",
                            "do ",
                            "any ",
                        ]
                    )
                )

                return {
                    "query": text if not bad_content else None,
                    "language": language_detect(text) if not bad_content else None,
                    "source": dataset_metadata["name"],
                    "metadata": json.dumps({"index": index}, indent=2),
                }

        if dataset_name == "stackexchange":

            def preprocess_function(row, index):
                return {
                    "query": row["question"].strip(),
                    "language": "en",
                    "source": dataset_metadata["name"],
                    "metadata": json.dumps({"qid": row["qid"]}, indent=2),
                }

        if dataset_name == "gooaq":

            def preprocess_function(row, index):
                return {
                    "query": row["question"].strip(),
                    "language": "en",
                    "source": dataset_metadata["name"],
                    "metadata": json.dumps({"index": index}, indent=2),
                }

        if dataset_name == "sharelm":

            def preprocess_function(row, index):
                text = row["conversation"][0]["content"].strip()
                bad_content = (
                    "sharelm-" not in row["source"]
                    and "CollectiveCognition" not in row["source"]
                )

                return {
                    "query": text if not bad_content else "",
                    "language": language_detect(text) if not bad_content else "",
                    "source": dataset_metadata["name"],
                    "metadata": json.dumps(
                        {"conversation_id": row["conversation_id"]}, indent=2
                    ),
                }

        if dataset_name == "expertqa":

            def preprocess_function(row, index):
                return {
                    "query": row["question"].strip(),
                    "language": "en",
                    "source": dataset_metadata["name"],
                    "metadata": json.dumps({"example_id": row["example_id"]}, indent=2),
                }

        if dataset_name == "icliniq" or dataset_name == "healthcaremagic":

            def preprocess_function(row, index):
                text = re.sub(
                    r"^(hi\s*doctor|hello\s*doctor)\s*[.,;!?]*\s*",
                    "",
                    row["input"],
                    flags=re.IGNORECASE,
                )
                return {
                    "query": text.strip(),
                    "language": language_detect(text),
                    "source": dataset_metadata["name"]
                    + "("
                    + dataset_metadata["subset"]
                    + ")",
                    "metadata": json.dumps({"index": index}, indent=2),
                }

        if dataset_name == "awesome_chatgpt_prompts":

            def preprocess_function(row, index):
                return {
                    "query": row["prompt"].strip(),
                    "language": language_detect(row["prompt"]),
                    "source": dataset_metadata["name"],
                    "metadata": json.dumps({"index": index}, indent=2),
                }

        if dataset_name == "anthropic":

            def preprocess_function(row, index):
                return {
                    "query": row["prompt"].strip(),
                    "language": language_detect("en"),
                    "source": dataset_name,
                    "metadata": json.dumps({"source": row["source"]}, indent=2),
                }

        if dataset_name == "langchain":

            def preprocess_function(row, index):
                return {
                    "query": row["prompt"].strip(),
                    "language": "en",
                    "source": dataset_name,
                    "metadata": json.dumps({"source": row["source"]}, indent=2),
                }

        if dataset_name == "naturalinstructions":
            ni_random = random.Random(42)

            def preprocess_function(row, index):
                return {
                    "query": (
                        (row["inputs"].strip() + "\n\n" + row["definition"].strip())
                        if ni_random.randint(0, 1)
                        else (
                            row["definition"].strip() + "\n\n" + row["inputs"].strip()
                        )
                    )
                    if row["inputs"] is not None and len(row["inputs"].strip()) > 0
                    else row["definition"].strip(),
                    "language": language_detect(row["definition"]),
                    "source": dataset_metadata["name"],
                    "metadata": json.dumps({"id": row["id"]}, indent=2),
                }

        if dataset_name == "p3":

            def preprocess_function(row, index):
                return {
                    "query": row["inputs_pretokenized"].strip(),
                    "language": language_detect(row["inputs_pretokenized"]),
                    "source": dataset_metadata["name"],
                    "metadata": json.dumps(
                        {"subset_name": row["subset_name"]}, indent=2
                    ),
                }

        if dataset_name == "bbh":

            def preprocess_function(row, index):
                return {
                    "query": row["input"].strip(),
                    "language": language_detect(row["input"]),
                    "source": dataset_metadata["name"],
                    "metadata": json.dumps(
                        {"subset_name": row["subset_name"]}, indent=2
                    ),
                }

        if dataset_name == "flanv2":

            def preprocess_function(row, index):
                text = row["messages"][0]["content"].strip()
                return {
                    "query": text,
                    "language": "en",
                    "source": dataset_metadata["name"],
                    "metadata": json.dumps({"source": row["source"]}, indent=2),
                }

        processed_dataset = dataset.map(
            preprocess_function,
            with_indices=True,
            num_proc=10,
            desc=f"Processing {dataset_name}",
            remove_columns=sorted(
                list(set(dataset.column_names).difference(new_schema))
            ),
        )

        # Add to all datasets
        if dataset_metadata.get("instantiate", False):
            from transformers import pipeline

            def instantiate_function(row, index):
                global pipe
                if not pipe:
                    pipe = pipeline(
                        "text-generation",
                        model="Qwen/Qwen2.5-72B-Instruct",
                        max_new_tokens=10000,
                        do_sample=False,
                        device_map="auto",
                    )
                starter = (
                    row["query"][: row["query"].find("{")]
                    if "{" in row["query"]
                    else row["query"]
                )
                messages = [
                    {
                        "role": "user",
                        "content": (
                            f"""
1. Output The *Entire* Prompt Template With Instructions & Few-Shot Examples: Output the prompt template *exactly* (character-by-character), keep all instructions / few-shot examples in your output that might be provided in the prompt template when responding.

2. Instantiate Variables: Somewhere in the template, there will be variables (like {{variable_name}}). Please "instantiate" the variables with something highly realistic (realistic in both length and content) of how someone might use the prompt template. Only replace the variables with highly realistic (realistic in both length and content) data.

3. Do not Respond: The end of the prompt template might end with prompt for completion like "Answer:". DO NOT fill in the answer. This should be the prompt only, *not* the prompt and response.

4. Return Format: Return just the "instantiated" prompt template between two "=======================" horizontal rules with nothing else in your response.

5. Realistic Instantiation: Make sure to instantiate each variable ({{variable_name}}) in the template with extremely lengthy, long, realistic content if the variable requires it (documentation, database rows, document, essay, article, context, document summary, etc.).

7. Do not Repeat Few-Shot Examples: Do not copy the few-shot examples to instantiate the variables.

=======================
{row["query"]}
=======================
                            """
                        ).strip(),
                    },
                    {
                        "role": "assistant",
                        "content": "Sure, here's the instantiated prompt template, with the variables replaced with new, unrepeated, realistic content:\n\n=======================\n"
                        + starter,
                    },
                ]
                tokenized = pipe.tokenizer.apply_chat_template(
                    messages,
                    continue_final_message=True,
                    padding=True,
                    truncation=True,
                    return_attention_mask=True,
                    return_tensors="pt",
                ).to(pipe.model.device)
                attention_mask = torch.ones_like(tokenized, dtype=tokenized.dtype)
                response = pipe.tokenizer.decode(
                    pipe.model.generate(
                        input_ids=tokenized,
                        attention_mask=attention_mask,
                        max_new_tokens=10000,
                        do_sample=False,
                        temperature=1.0,
                        top_p=1.0,
                        top_k=None,
                        pad_token_id=pipe.tokenizer.eos_token_id,
                    ).cpu()[0]
                )
                response = (
                    (
                        "Sure, here's the instantiated prompt template, with the variables replaced with realistic content:\n\n=======================\n"
                        + response[response.rfind(starter) :]
                    )
                    if starter in response
                    else ""
                )
                response = (
                    "\n".join(
                        re.findall(
                            r"=======================\n(.*?)\n=======================",
                            response,
                            re.DOTALL,
                        )
                    )
                    or response
                )
                response = re.sub(r"\{[\w]+\}", "", response)
                response = response.strip()
                row["query"] = response
                return row

            processed_dataset = processed_dataset.map(
                instantiate_function,
                with_indices=True,
                num_proc=1,
                desc=f"Instantiating {dataset_name}",
            )

        cleaned = clean_rows(processed_dataset, "query")
        if dataset_metadata.get("moderate", False):
            print("Moderating...", file=sys.stderr)
            cleaned = moderate_rows(cleaned)
        print(
            f"Collected {len(cleaned)} total row(s) from {dataset_name}",
            file=sys.stderr,
        )
        all_datasets[dataset_name] = cleaned

    # Print preview
    print(
        json.dumps(
            list(all_datasets.values())[-1]
            .take(min(50, len(list(all_datasets.values())[-1])))
            .to_list(),
            indent=2,
        )
    )

    # Push to hub
    for dataset_name, dataset_metadata in datasets.items():
        if dataset_metadata["skip"] or not dataset_metadata["push"]:
            continue

        all_datasets[dataset_name].push_to_hub(
            "fineinstructions/real_queries_raw",
            split=dataset_name,
            max_shard_size="500MB",
        )


__all__ = ["mine_real_queries"]
