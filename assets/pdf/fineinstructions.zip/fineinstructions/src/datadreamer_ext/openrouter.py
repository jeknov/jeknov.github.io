import functools
import json
import logging
import signal
from functools import cached_property
from typing import Generator
from unittest.mock import patch

import openai
import ring
from datadreamer.llms import OpenAI
from datadreamer.llms.openai import OpenAIException
from datadreamer.utils.hf_hub_utils import (
    get_citation_info,
    get_license_info,
    get_model_card_url,
)
from datadreamer.utils.hf_model_utils import (
    HF_TRANSFORMERS_CITATION,
    get_config,
    get_model_max_context_length,
    get_tokenizer,
)
from tenacity import (
    after_log,
    before_sleep_log,
    retry,
    retry_if_exception_type,
    stop_any,
    wait_exponential,
)
from transformers import PreTrainedTokenizer


class TimeoutError(Exception):
    pass


def timeout(seconds: int):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            def _handle_timeout(signum, frame):
                raise TimeoutError(
                    f"Function '{func.__name__}' timed out after {seconds} seconds"
                )

            old_handler = signal.signal(signal.SIGALRM, _handle_timeout)
            signal.alarm(seconds)
            try:
                return func(*args, **kwargs)
            finally:
                signal.alarm(0)  # cancel alarm
                signal.signal(signal.SIGALRM, old_handler)

        return wrapper

    return decorator


class OpenRouter(OpenAI):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.revision = None
        if "meta-llama/llama-3.3" in self.model_name.lower():
            self.ungated_model_name = "meta-llama/Llama-3.2-1B-Instruct"
        else:
            self.ungated_model_name = self.model_name
        self.config = get_config(
            model_name=self.ungated_model_name,
            revision=self.revision,
            trust_remote_code=True,
        )
        self.revision = None

    @cached_property
    def retry_wrapper(self):
        # Create a retry wrapper function
        tenacity_logger = self.get_logger(key="retry", verbose=True, log_level=None)

        @retry(
            retry=retry_if_exception_type(json.decoder.JSONDecodeError),
            wait=wait_exponential(multiplier=1, min=3, max=3),
            before_sleep=before_sleep_log(tenacity_logger, logging.INFO),
            after=after_log(tenacity_logger, logging.INFO),
            stop=stop_any(lambda _: not self.retry_on_fail),  # type: ignore[arg-type]
            reraise=True,
        )
        @retry(
            retry=retry_if_exception_type(TimeoutError),
            wait=wait_exponential(multiplier=1, min=3, max=3),
            before_sleep=before_sleep_log(tenacity_logger, logging.INFO),
            after=after_log(tenacity_logger, logging.INFO),
            stop=stop_any(lambda _: not self.retry_on_fail),  # type: ignore[arg-type]
            reraise=True,
        )
        @retry(
            retry=retry_if_exception_type(openai.RateLimitError),
            wait=wait_exponential(multiplier=1, min=10, max=60),
            before_sleep=before_sleep_log(tenacity_logger, logging.INFO),
            after=after_log(tenacity_logger, logging.INFO),
            stop=stop_any(lambda _: not self.retry_on_fail),  # type: ignore[arg-type]
            reraise=True,
        )
        @retry(
            retry=retry_if_exception_type(openai.InternalServerError),
            wait=wait_exponential(multiplier=1, min=3, max=3),
            before_sleep=before_sleep_log(tenacity_logger, logging.INFO),
            after=after_log(tenacity_logger, logging.INFO),
            stop=stop_any(lambda _: not self.retry_on_fail),  # type: ignore[arg-type]
            reraise=True,
        )
        @retry(
            retry=retry_if_exception_type(openai.APIError),
            wait=wait_exponential(multiplier=1, min=3, max=3),
            before_sleep=before_sleep_log(tenacity_logger, logging.INFO),
            after=after_log(tenacity_logger, logging.INFO),
            stop=stop_any(lambda _: not self.retry_on_fail),  # type: ignore[arg-type]
            reraise=True,
        )
        @retry(
            retry=retry_if_exception_type(OpenAIException),
            wait=wait_exponential(multiplier=1, min=3, max=3),
            before_sleep=before_sleep_log(tenacity_logger, logging.INFO),
            after=after_log(tenacity_logger, logging.INFO),
            stop=stop_any(lambda _: not self.retry_on_fail),  # type: ignore[arg-type]
            reraise=True,
        )
        @retry(
            retry=retry_if_exception_type(openai.APIConnectionError),
            wait=wait_exponential(multiplier=1, min=3, max=3),
            before_sleep=before_sleep_log(tenacity_logger, logging.INFO),
            after=after_log(tenacity_logger, logging.INFO),
            stop=stop_any(lambda _: not self.retry_on_fail),  # type: ignore[arg-type]
            reraise=True,
        )
        def _retry_wrapper(func, **kwargs):
            try:
                response = func(**kwargs)
            except Exception as e:
                if str("""specify "prompt"'""") in str(e):
                    pass
                raise e
            if (
                response.choices is None
                or response.choices == []
                or response.choices[0].message.content is None
            ):
                raise OpenAIException(
                    f"OpenRouter experienced an error: {str(response)}"
                )
            return response

        _retry_wrapper.__wrapped__.__module__ = None  # type: ignore[attr-defined]
        _retry_wrapper.__wrapped__.__qualname__ = f"{self.__class__.__name__}.run"  # type: ignore[attr-defined]
        return _retry_wrapper

    @cached_property
    def tokenizer(self) -> PreTrainedTokenizer:
        while True:
            try:
                return get_tokenizer(
                    model_name=self.ungated_model_name,
                    revision=self.revision,
                    trust_remote_code=True,
                )
            except Exception as e:
                logger = self.get_logger(key="retry", verbose=True, log_level=None)
                logger.info(f"Retrying get_tokenizer {e}...")

    @ring.lru(maxsize=128)
    def get_max_context_length(self, max_new_tokens: int) -> int:
        estimate = (
            get_model_max_context_length(
                model_name=self.ungated_model_name, config=self.config
            )
            - 2000
        )
        return estimate - max_new_tokens

    def _get_max_output_length(self) -> None | int:
        return None

    @ring.lru(maxsize=5000)
    def count_tokens(self, value: str) -> int:
        return len(self.tokenizer.encode(value))

    def run(
        self, *args, **kwargs
    ) -> Generator[str | list[str], None, None] | list[str | list[str]]:
        with patch("datadreamer.llms.openai._is_chat_model", lambda model_name: True):
            return super().run(*args, **kwargs)

    def _run_batch(self, *args, **kwargs) -> list[str] | list[list[str]]:
        with patch("datadreamer.llms.openai._is_chat_model", lambda model_name: True):
            return super()._run_batch(*args, **kwargs)

    @cached_property
    def model_card(self) -> None | str:
        return get_model_card_url(self.ungated_model_name)

    @cached_property
    def license(self) -> None | str:
        return get_license_info(
            self.ungated_model_name, repo_type="model", revision=self.revision
        )

    @cached_property
    def citation(self) -> None | list[str]:
        model_citations = get_citation_info(
            self.model_name, repo_type="model", revision=self.revision
        )
        citations = []
        citations.append(HF_TRANSFORMERS_CITATION)
        if isinstance(model_citations, list):
            citations.extend(model_citations)
        return citations
