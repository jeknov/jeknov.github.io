#!/bin/bash

if [ "$PROJECT_SKIP_INSTALL_REQS" != "1" ]; then
    # Install GPU version of FAISS
    pip3 uninstall -y faiss-cpu faiss-gpu 1>/dev/null 2>/dev/null
    pip3 install 'https://github.com/kyamagu/faiss-wheels/releases/download/v1.7.3/faiss_gpu-1.7.3-cp311-cp311-manylinux_2_17_x86_64.manylinux2014_x86_64.whl'
fi
