import click

from . import project
from .project.builtin_tasks import register_builtin_tasks
from .tasks.create_template_index.create_task_type_index import create_task_type_index
from .tasks.create_template_index.create_template_index import create_template_index
from .tasks.data_tasks.dclm import process_dclm
from .tasks.data_tasks.find_gold_examples import find_gold_examples
from .tasks.data_tasks.fineweb_edu import process_fineweb_edu
from .tasks.data_tasks.ipt import process_ipt
from .tasks.data_tasks.longform import process_longform
from .tasks.data_tasks.nemotron import process_nemotron
from .tasks.data_tasks.token_for_token import process_token_for_token
from .tasks.doc_to_instruction.instantiation_subsample import (
    instantiation_subsample,
    instantiation_subsample_2,
    instantiation_subsample_3,
)
from .tasks.doc_to_instruction.train_instantiator import (
    train_instantiator,
    train_instantiator_2,
)
from .tasks.doc_to_template.calibration_v2 import calibration_v2
from .tasks.doc_to_template.doc_to_description import doc_to_description
from .tasks.doc_to_template.train_matcher import train_matcher
from .tasks.doc_to_template.train_matcher_v2 import train_matcher_v2
from .tasks.mine_real_queries.flatten_real_queries import flatten_real_queries
from .tasks.mine_real_queries.mine_real_queries import mine_real_queries
from .tasks.posttrain.train_sft import train_sft
from .tasks.pretraining_inference.pretraining_inference import pretraining_inference
from .tasks.train_query_genericizer.genericize_queries import genericize_queries
from .tasks.train_query_genericizer.genericize_queries_subsample import (
    genericize_queries_subsample,
)
from .tasks.train_query_genericizer.stratify_real_queries import stratify_real_queries
from .tasks.train_query_genericizer.train_query_genericizer import (
    train_query_genericizer,
)


# Register main
@click.group()
@click.pass_context
@click.option(
    "--local_rank", type=int, required=False, hidden=True
)  # DeepSpeed passes this when used
def _main(*args, **kwargs):
    # Run init
    project.init()


# Register built-in tasks
register_builtin_tasks(_main)

# Register tasks
_main.command()(click.pass_context(mine_real_queries))
_main.command()(click.pass_context(flatten_real_queries))
_main.command()(click.pass_context(stratify_real_queries))
_main.command()(click.pass_context(genericize_queries_subsample))
_main.command()(click.pass_context(train_query_genericizer))
_main.command()(click.pass_context(genericize_queries))
_main.command()(click.pass_context(doc_to_description))
_main.command()(click.pass_context(train_matcher))
_main.command()(click.pass_context(create_template_index))
_main.command()(click.pass_context(calibration_v2))
_main.command()(click.pass_context(train_matcher_v2))
_main.command()(click.pass_context(instantiation_subsample))
_main.command()(click.pass_context(instantiation_subsample_2))
_main.command()(click.pass_context(instantiation_subsample_3))
_main.command()(click.pass_context(train_instantiator))
_main.command()(click.pass_context(train_instantiator_2))
_main.command()(click.pass_context(process_nemotron))
_main.command()(click.pass_context(process_ipt))
_main.command()(click.pass_context(process_longform))
_main.command()(click.pass_context(pretraining_inference))
_main.command()(click.pass_context(process_token_for_token))
_main.command()(click.pass_context(find_gold_examples))
_main.command()(click.pass_context(create_task_type_index))
_main.command()(click.pass_context(process_fineweb_edu))
_main.command()(click.pass_context(process_dclm))
_main.command()(click.pass_context(train_sft))
