# FineInstructions

You can run the project like so (`pip` requirements are automatically installed on first install). Please use Python 3.11 (can be installed using `pyenv`):

```bash
export PROJECT_DATA='/project_data'  # Set to a path that can be used for large data storage and downloads
export PROJECT_DATA_OUTPUT_PERSISTENT_DATA='/project_data/persistent_data'  # Set to a path that can be used for large data storage and downloads (can be a subfolder of PROJECT_DATA)
export HUGGING_FACE_HUB_TOKEN="hf_XXXXXXX"  # Set HF Token for downloads and uploads
./run -h # This will run the help CLI command, or you can run any other CLI command
```